﻿/********************************************************************************************************************************
 * Sl.No |Tracking No.        |               Description                                                    |   Date       |Author
 * 1.   | 2150/Ex:2254        |Staging based on concentration rate                                          | 16-Jun-2016   |Sushin
 ********************************************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.Common;
using System.Data;
using iPAS_PreWeighService_DAL;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Common;
using System.Globalization;
using iPAS_PreWeighService.iPAS_SyncDataService;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Reflection;
using System.Runtime.Remoting.Messaging;

namespace iPAS_PreWeighService
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class PreweighService : IPreweighService
    {
        delegate void CreateTransferOrder(Database db, int siteID, string processOrder, int userID);
        delegate void SyncMissingPartsInfo();
        delegate void KitLabel(Database db, KitLabelInfo kitLabelInfo, PrintPreweighLabel printKitLabelInfo, string userName, string fileName);

        #region Common
        public List<UserProductionLines> GetUserProductionLines(int siteID, int accessLevelID, int userID)
        {
            IDataReader dataReaderPLines = null;
            UserProductionLines userPLineInfo = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                List<UserProductionLines> productionList = new List<UserProductionLines>();

                dataReaderPLines = PreweighDAL.GetUserProductionLines(db, siteID, accessLevelID, userID);

                while (dataReaderPLines.Read())
                {
                    userPLineInfo = new UserProductionLines();
                    userPLineInfo.ProductionID = Common.GetSafeInt32(dataReaderPLines, "FPLINEID");
                    userPLineInfo.ProductionLineName = Common.GetSafeString(dataReaderPLines, "FPLINE");
                    productionList.Add(userPLineInfo);
                }

                dataReaderPLines.Close();
                return productionList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Error while fetching user production lines", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "UserID: " + userID.ToString() + "; SiteID: " + siteID);
                throw;
            }
            finally
            {
                if (dataReaderPLines != null && !dataReaderPLines.IsClosed)
                    dataReaderPLines.Close();
            }
        }

        public PlantPickKitProcess GetPickKitProcess(BasicParam basicParam)
        {
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                string pickKitProcess = PreweighDAL.GetPickKitProcess(db, basicParam.SiteID);

                if (Convert.ToChar(pickKitProcess) == Convert.ToChar(PlantPickKitProcess.Picking_Kitting_Seperate))
                    return PlantPickKitProcess.Picking_Kitting_Seperate;
                else
                    return PlantPickKitProcess.Picking_Kitting_Together;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while checking pick-kit process", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "UerID:" + basicParam.UserID + "; SiteID: " + basicParam.SiteID);
                throw;
            }
        }

        public PlantSettings GetPlantSettings(int siteID)
        {
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                return Common.GetPlantSettings(db, siteID);
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while checking pick-kit process", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + siteID);
                throw;
            }
        }
        #endregion

        #region Calendar

        public int GetServerCurrentDate(int siteID)
        {
            return Common.GetServerCurrentDate(siteID);
        }

        public DayProcessOrderList GetStagingProcessOrderForDayView(POFilterInfo filterInfo)
        {
            IDataReader dataReaderProcessOrder = null;
            DayProcessOrderList dayProcessOrderList = new DayProcessOrderList();
            try
            {

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                int currentDate = filterInfo.CurrentDate;
                DateTime dateTimeCurrent;
                DateTime.TryParseExact(currentDate.ToString(), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out dateTimeCurrent);

                if (filterInfo.CalendarMode == DisplayMode.NextDay)
                    dateTimeCurrent = dateTimeCurrent.AddDays(1);
                else if (filterInfo.CalendarMode == DisplayMode.PrevDay)
                    dateTimeCurrent = dateTimeCurrent.AddDays(-1);

                Int32.TryParse(dateTimeCurrent.ToString("yyyyMMdd"), out currentDate);

                int productionLineID = 0;
                Int32.TryParse(filterInfo.PlineID, out productionLineID);

                int displayType = 1;          //Planner view
                if (filterInfo.DisplayType == DisplayType.ScheduledView)
                    displayType = 2;          //Operator view

                dataReaderProcessOrder = PreweighDAL.GetStagingProcessOrderForDayView(db, filterInfo.SiteID, currentDate, filterInfo.UserID, filterInfo.AccessLevelID, productionLineID, displayType, filterInfo.PageIndex, filterInfo.PageSize);

                while (dataReaderProcessOrder.Read())
                {
                    if (dayProcessOrderList.TotalCount == 0)
                    {
                        dayProcessOrderList.TotalCount = Common.GetSafeInt32(dataReaderProcessOrder, "FCOUNT");
                    }

                    int rowIndex = Common.GetSafeInt32(dataReaderProcessOrder, "FROWINDEX");

                    dayProcessOrderList.LastRowIndex = rowIndex; //Always consider last rowindex for handling paging

                    string processOrder = Common.GetSafeString(dataReaderProcessOrder, "FAUFNR");

                    //Check whether staging is required for the PO. There should be atleast one item for staging
                    if (PreweighDAL.GetStagingRequiredMaterialsForPO(db, filterInfo.SiteID, processOrder) == 0)
                    {
                        dayProcessOrderList.TotalCount--;
                        continue;
                    }

                    POBasicHeaderInfo headerInfo = new POBasicHeaderInfo();
                    headerInfo.RowIndex = rowIndex;
                    headerInfo.ProcessOrderNumber = processOrder;
                    headerInfo.BatchNumber = Common.GetSafeString(dataReaderProcessOrder, "FCHARG");
                    headerInfo.MaterialNumber = Common.GetSafeString(dataReaderProcessOrder, "FMATNR");
                    headerInfo.MaterialDescription = Common.GetSafeString(dataReaderProcessOrder, "FIDHDESC");
                    //Quality status - > approved or rejected
                    headerInfo.POQIStatus = Common.GetQualityStatus(Common.GetSafeString(dataReaderProcessOrder, "FQISTATUS"));

                    string hdrStatus = Common.GetSafeString(dataReaderProcessOrder, "FHDRSTATUS");
                    headerInfo.Status = Common.GetProcessOrderStatus(hdrStatus);

                    headerInfo.ResourceName = Common.GetSafeString(dataReaderProcessOrder, "FCATEGORY");

                    if (Common.GetSafeString(dataReaderProcessOrder, "FISWORKRESOURCE") == "Y")
                    {
                        headerInfo.POType = ProcessOrderType.Repack;
                    }
                    else
                    {
                        string orderType = Common.GetSafeString(dataReaderProcessOrder, "FPOORDERTYPE");
                        headerInfo.POType = Common.GetProcessOrderOrderType(orderType, headerInfo.ResourceName);
                    }

                    int rmShortageCount = Common.GetSafeInt32(dataReaderProcessOrder, "FHASRMSHORTAGE");

                    if (rmShortageCount > 0)
                    {
                        headerInfo.HasRMShortage = true;
                    }

                    dayProcessOrderList.ProcessOrderList.Add(headerInfo);
                }

                dataReaderProcessOrder.Close();
                return dayProcessOrderList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Failed to fetch process orders for day view", "iPAS_PreWeighService",
                  System.Reflection.MethodBase.GetCurrentMethod().Name, "UserID: " + filterInfo.UserID + "; SiteID: " + filterInfo.SiteID + "; Currentdate: " + filterInfo.CurrentDate);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderProcessOrder != null && !dataReaderProcessOrder.IsClosed)
                    dataReaderProcessOrder.Close();
            }
        }

        public DateProcessOrderList GetStagingProcessOrderForMonthView(POFilterInfo filterInfo)
        {
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                int currentDate = filterInfo.CurrentDate;
                int monthStartDate = 0;
                int monthEndDate = 0;
                DateProcessOrderList dateProcessOrderList = new DateProcessOrderList();

                Common.GetMonthStartDateAndEndDate(currentDate, filterInfo.CalendarMode, ref monthStartDate, ref monthEndDate);

                int displayType = 1;          //Planner view
                if (filterInfo.DisplayType == DisplayType.ScheduledView)
                    displayType = 2;          //Operator view

                int plineID = 0;
                Int32.TryParse(filterInfo.PlineID, out plineID);

                DataTable dataTableProcessOrder = PreweighDAL.GetStagingProcessOrderForDateRange(db, filterInfo.SiteID, monthStartDate, monthEndDate, filterInfo.UserID, filterInfo.AccessLevelID, plineID, displayType, filterInfo.PageIndex, filterInfo.PageSize);
                DataTable distictDateTable = dataTableProcessOrder.DefaultView.ToTable(true, "FSTARTDATE");
                if (dataTableProcessOrder.Rows.Count > 0)
                {
                    int totalCount = 0;
                    int lastRowIndex = 0;
                    Int32.TryParse(dataTableProcessOrder.Rows[0]["FCOUNT"].ToString(), out totalCount);
                    Int32.TryParse(dataTableProcessOrder.Rows[dataTableProcessOrder.Rows.Count - 1]["FROWINDEX"].ToString(), out lastRowIndex);
                    dateProcessOrderList.TotalCount = totalCount;
                    dateProcessOrderList.LastRowIndex = lastRowIndex;
                }

                foreach (DataRow poRow in distictDateTable.Rows)
                {
                    DateProcessOrderInfo datePOInfo = new DateProcessOrderInfo();
                    string startDate = poRow["FSTARTDATE"].ToString();
                    int poDate = 0;
                    Int32.TryParse(startDate, out poDate);

                    datePOInfo.Date = poDate;
                    DataRow[] datePORows = dataTableProcessOrder.Select("FSTARTDATE = " + startDate);
                    foreach (DataRow dataRow in datePORows)
                    {
                        string processOrder = dataRow["FAUFNR"].ToString();
                        //Check whether staging is required for the PO. There should be atleast one item for staging
                        if (PreweighDAL.GetStagingRequiredMaterialsForPO(db, filterInfo.SiteID, processOrder) == 0)
                        {
                            continue;
                        }

                        POBasicHeaderInfo hdrInfo = new POBasicHeaderInfo();
                        hdrInfo.ProcessOrderNumber = processOrder;
                        hdrInfo.BatchNumber = dataRow["FCHARG"].ToString();
                        hdrInfo.MaterialNumber = dataRow["FMATNR"].ToString();
                        hdrInfo.MaterialDescription = dataRow["FIDHDESC"].ToString();
                        hdrInfo.ResourceName = dataRow["FCATEGORY"].ToString();
                        string hdrStatus = dataRow["FHDRSTATUS"].ToString();
                        hdrInfo.Status = Common.GetProcessOrderStatus(hdrStatus);
                        //Quality status - > approved or rejected
                        hdrInfo.POQIStatus = Common.GetQualityStatus(dataRow["FQISTATUS"].ToString());

                        if (dataRow["FISWORKRESOURCE"].ToString() == "Y")
                        {
                            hdrInfo.POType = ProcessOrderType.Repack;
                        }
                        else
                        {
                            string orderType = dataRow["FPOORDERTYPE"].ToString();
                            hdrInfo.POType = Common.GetProcessOrderOrderType(orderType, hdrInfo.ResourceName);
                        }
                        datePOInfo.PoInfo.Add(hdrInfo);
                    }

                    dateProcessOrderList.ListDatePO.Add(datePOInfo);
                }

                return dateProcessOrderList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Failed to fetch process orders for month view", "iPAS_PreWeighService",
                   System.Reflection.MethodBase.GetCurrentMethod().Name, "UserID: " + filterInfo.UserID + "; SiteID: " + filterInfo.SiteID + "; Currentdate: " + filterInfo.CurrentDate);

                throw new FaultException(ex.Message);
            }
        }

        public DateProcessOrderList GetStagingProcessOrderForWeekView(POFilterInfo filterInfo)
        {
            DataTable dataTableProcessOrder = new DataTable();
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                DateProcessOrderList dateProcessOrderList = new DateProcessOrderList();
                int currentDate = filterInfo.CurrentDate;
                int weekStartDate = 0;
                int weekEndDate = 0;

                Common.GetWeekStartDateAndEndDate(currentDate, filterInfo.CalendarMode, ref weekStartDate, ref weekEndDate);
                int displayType = 1;          //Planner view
                if (filterInfo.DisplayType == DisplayType.ScheduledView)
                    displayType = 2;          //Operator view

                int plineID = 0;
                Int32.TryParse(filterInfo.PlineID, out plineID);
                dataTableProcessOrder = PreweighDAL.GetStagingProcessOrderForDateRange(db, filterInfo.SiteID, weekStartDate, weekEndDate, filterInfo.UserID, filterInfo.AccessLevelID, plineID, displayType, filterInfo.PageIndex, filterInfo.PageSize);

                DataTable distictDateTable = dataTableProcessOrder.DefaultView.ToTable(true, "FSTARTDATE");
                if (dataTableProcessOrder.Rows.Count > 0)
                {
                    int totalCount = 0;
                    int lastRowIndex = 0;
                    Int32.TryParse(dataTableProcessOrder.Rows[0]["FCOUNT"].ToString(), out totalCount);
                    Int32.TryParse(dataTableProcessOrder.Rows[dataTableProcessOrder.Rows.Count - 1]["FROWINDEX"].ToString(), out lastRowIndex);
                    dateProcessOrderList.TotalCount = totalCount;
                    dateProcessOrderList.LastRowIndex = lastRowIndex;
                }

                foreach (DataRow poRow in distictDateTable.Rows)
                {
                    DateProcessOrderInfo datePOInfo = new DateProcessOrderInfo();
                    string startDate = poRow["FSTARTDATE"].ToString();
                    int poDate = 0;
                    Int32.TryParse(startDate, out poDate);

                    datePOInfo.Date = poDate;
                    DataRow[] datePORows = dataTableProcessOrder.Select("FSTARTDATE = " + startDate);
                    foreach (DataRow dataRow in datePORows)
                    {
                        string processOrder = dataRow["FAUFNR"].ToString();
                        //Check whether staging is required for the PO. There should be atleast one item for staging
                        if (PreweighDAL.GetStagingRequiredMaterialsForPO(db, filterInfo.SiteID, processOrder) == 0)
                        {
                            continue;
                        }

                        POBasicHeaderInfo hdrInfo = new POBasicHeaderInfo();
                        hdrInfo.ProcessOrderNumber = processOrder;
                        hdrInfo.BatchNumber = dataRow["FCHARG"].ToString();
                        hdrInfo.MaterialNumber = dataRow["FMATNR"].ToString();
                        hdrInfo.MaterialDescription = dataRow["FIDHDESC"].ToString();
                        hdrInfo.ResourceName = dataRow["FCATEGORY"].ToString();
                        string hdrStatus = dataRow["FHDRSTATUS"].ToString();
                        hdrInfo.Status = Common.GetProcessOrderStatus(hdrStatus);

                        //Quality status - > approved or rejected
                        hdrInfo.POQIStatus = Common.GetQualityStatus(dataRow["FQISTATUS"].ToString());

                        if (dataRow["FISWORKRESOURCE"].ToString() == "Y")
                        {
                            hdrInfo.POType = ProcessOrderType.Repack;
                        }
                        else
                        {
                            string orderType = dataRow["FPOORDERTYPE"].ToString();
                            hdrInfo.POType = Common.GetProcessOrderOrderType(orderType, hdrInfo.ResourceName);
                        }
                        datePOInfo.PoInfo.Add(hdrInfo);

                    }

                    dateProcessOrderList.ListDatePO.Add(datePOInfo);
                }

                return dateProcessOrderList;

            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Failed to fetch process orders for week view", "iPAS_PreWeighService",
                   System.Reflection.MethodBase.GetCurrentMethod().Name, "UserID: " + filterInfo.UserID + "; SiteID: " + filterInfo.SiteID + "; Currentdate: " + filterInfo.CurrentDate);

                throw new FaultException(ex.Message);
            }
        }

        public List<string> GetAllActiveResourcesForWeek(POFilterInfo filterInfo)
        {
            List<string> resourceNames = new List<string>();
            IDataReader readerResourceName = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                int weekStartDate = 0;
                int weekEndDate = 0;
                int displayType = 1;          //Planner view

                if (filterInfo.DisplayType == DisplayType.ScheduledView)
                    displayType = 2;          //Operator view

                Common.GetWeekStartDateAndEndDate(filterInfo.CurrentDate, filterInfo.CalendarMode, ref weekStartDate, ref weekEndDate);

                int plineID = 0;
                Int32.TryParse(filterInfo.PlineID, out plineID);

                readerResourceName = PreweighDAL.GetAllActiveResourcesForDateRange(db, filterInfo.SiteID, weekStartDate, weekEndDate, filterInfo.AccessLevelID, filterInfo.UserID, plineID, displayType);
                while (readerResourceName.Read())
                {
                    resourceNames.Add(Common.GetSafeString(readerResourceName, "FCATEGORY"));
                }
                readerResourceName.Close();

                return resourceNames;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "ManufacturingService.svc", "Failed while loading mixer names for resource view", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "SiteID: " + filterInfo.SiteID + " UserID: " + filterInfo.UserID);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (readerResourceName != null && !readerResourceName.IsClosed)
                {
                    readerResourceName.Close();
                }
            }
        }

        #endregion

        #region Reschedule
        public List<POBasicHeaderInfo> GetStagingProcessOrdersForReschedule(ReschedulePOFilterInfo filterInfo)
        {
            IDataReader dataReaderProcessOrder = null;
            List<POBasicHeaderInfo> lstPOList = new List<POBasicHeaderInfo>();

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                int fromDateRange = filterInfo.FromDateRange;
                int ToDateRange = filterInfo.ToDateRange;

                string sortField = string.Empty;
                if (filterInfo.SortType != null)
                    sortField = filterInfo.SortType.ToString();

                string searchProcessOrder = string.Empty;
                if (filterInfo.ProcessOrderSearch != null)
                    searchProcessOrder = filterInfo.ProcessOrderSearch.ToString();

                int displayType = 1;          //Planner view
                if (filterInfo.DisplayType == DisplayType.ScheduledView)
                    displayType = 2;          //Operator view

                dataReaderProcessOrder = PreweighDAL.GetAllStagingProcessOrderForDateRange(db, filterInfo.SiteID, fromDateRange, ToDateRange, filterInfo.UserID
                    , filterInfo.AccessLevelID, filterInfo.PlineID, filterInfo.PageStartIndex, filterInfo.PageSize, sortField, searchProcessOrder, displayType);

                int i = 0;
                while (dataReaderProcessOrder.Read())
                {
                    POBasicHeaderInfo hdrInfo = new POBasicHeaderInfo();
                    hdrInfo.ProcessOrderNumber = Common.GetSafeString(dataReaderProcessOrder, "FAUFNR");
                    hdrInfo.BatchNumber = Common.GetSafeString(dataReaderProcessOrder, "FCHARG");
                    hdrInfo.MaterialNumber = Common.GetSafeString(dataReaderProcessOrder, "FMATNR");
                    hdrInfo.MaterialDescription = Common.GetSafeString(dataReaderProcessOrder, "FIDHDESC");
                    hdrInfo.ResourceName = Common.GetSafeString(dataReaderProcessOrder, "FCATEGORY");
                    hdrInfo.ScheduledDate = Common.GetSafeInt32(dataReaderProcessOrder, "FSTARTDATE");

                    if (i == 0)
                    {
                        hdrInfo.TotalRecords = Common.GetSafeInt32(dataReaderProcessOrder, "FCOUNT");
                        i++;
                    }

                    hdrInfo.Status = Common.GetProcessOrderStatus(Common.GetSafeString(dataReaderProcessOrder, "FHDRSTATUS"));
                    hdrInfo.POQIStatus = Common.GetQualityStatus(Common.GetSafeString(dataReaderProcessOrder, "FQISTATUS"));

                    if (Common.GetSafeString(dataReaderProcessOrder, "FISWORKRESOURCE") == "Y")
                    {
                        hdrInfo.POType = ProcessOrderType.Repack;
                    }
                    else
                    {
                        string orderType = Common.GetSafeString(dataReaderProcessOrder, "FPOORDERTYPE");
                        hdrInfo.POType = Common.GetProcessOrderOrderType(orderType, hdrInfo.ResourceName);
                    }

                    lstPOList.Add(hdrInfo);
                }

                dataReaderProcessOrder.Close();

                return lstPOList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Failed to fetch process orders for rescheduling", "iPAS_PreWeighService",
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "UserID: " + filterInfo.UserID + "; SiteID: " + filterInfo.SiteID + "; Date From: " + filterInfo.FromDateRange + "; To: " + filterInfo.ToDateRange + "; PO: " + filterInfo.ProcessOrderSearch);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderProcessOrder != null && !dataReaderProcessOrder.IsClosed)
                    dataReaderProcessOrder.Close();
            }

        }

        public bool RescheduleProcessOrder(RescheduleProcessOrderInfo rescheduleInfo)
        {
            int createDate = 0;
            int createTime = 0;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, rescheduleInfo.SiteID, ref createDate, ref createTime);

                return RescheduleProcessOrders(db, rescheduleInfo, createDate, createTime);
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while rescheduling orders", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "UserID: " + rescheduleInfo.UserID + "; SiteID: " + rescheduleInfo.SiteID);
                throw new FaultException(ex.Message);
            }
        }

        private bool RescheduleProcessOrders(Database db, RescheduleProcessOrderInfo rescheduleInfo, int createDate, int createTime)
        {
            string processOrderNumbers = string.Empty;

            for (int i = 0; i < rescheduleInfo.ProcessOrderNumber.Count; i++)
            {
                processOrderNumbers = processOrderNumbers + "," + rescheduleInfo.ProcessOrderNumber[i].Trim().PadLeft(12, '0');
            }

            if (processOrderNumbers.Trim().Length > 0)
            {
                processOrderNumbers = processOrderNumbers.TrimStart(',');
            }

            if (rescheduleInfo.Displaytype == DisplayType.PlannerView)
            {
                PreweighDAL.UpdateProcessOrderPlannedDate(db, processOrderNumbers, rescheduleInfo.ChangeDate, rescheduleInfo.ChangedTime);
            }
            else
            {
                PreweighDAL.UpdateProcessOrderScheduledDate(db, processOrderNumbers, rescheduleInfo.ChangeDate, rescheduleInfo.ChangedTime);
            }

            for (int i = 0; i < rescheduleInfo.ProcessOrderNumber.Count; i++)
            {
                CommonDAL.LogProcessTransactionLog(db, rescheduleInfo.ProcessOrderNumber[i], ProcessTransactionLog.PO_ReSchedule.ToString()
               , "Process Order Rescheduled for staging to: " + rescheduleInfo.ChangeDate.ToString(), rescheduleInfo.UserID, createDate, createTime);
            }

            return true;
        }

        public List<string> CheckProcessOrderExists(POFilterInfo filterInfo, string processOrderNumber)
        {
            IDataReader dataReaderCheck = null;
            List<string> errorMessage = new List<string>();

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderCheck = PreweighDAL.CheckProcessOrderExists(db, filterInfo.SiteID, processOrderNumber, filterInfo.AccessLevelID, filterInfo.UserID);

                Common.SetCurrentThreadCulture(db, filterInfo.LanguageCode);

                if (dataReaderCheck.Read())
                {
                    string poMaterial = Common.GetSafeString(dataReaderCheck, "FMATNR");
                    string materialNumber = Common.GetSafeString(dataReaderCheck, "FIDHID");

                    string mixer = Common.GetSafeString(dataReaderCheck, "FRESOURCECODE");
                    string poMixer = Common.GetSafeString(dataReaderCheck, "FCATEGORY");

                    string type = Common.GetSafeString(dataReaderCheck, "FTYPE");
                    string poType = Common.GetSafeString(dataReaderCheck, "FAUART");

                    string poWERKS = Common.GetSafeString(dataReaderCheck, "FPOWERKS");
                    string sitePlantCode = Common.GetSafeString(dataReaderCheck, "FSAPPLANTCODE");
                    string isRepackResource = Common.GetSafeString(dataReaderCheck, "FISWORKRESOURCE");
                    int sopCount = Common.GetSafeInt32(dataReaderCheck, "FSOPCOUNT");
                    string bulkLink = Common.GetSafeString(dataReaderCheck, "FBULKLINK");

                    int userPline = 0;
                    if (filterInfo.AccessLevelID == 5)
                    {
                        userPline = Common.GetSafeInt32(dataReaderCheck, "FUSERPLINE");
                    }

                    string productionLine = Common.GetSafeString(dataReaderCheck, "FPLINE");

                    if (materialNumber.Length == 0)
                        errorMessage.Add(Language_Resources.Staging_Resource.doesNotExistsInMaterialMasterTable.Trim().Replace("[XXX]", poMaterial));

                    if (mixer.Length == 0)
                        errorMessage.Add(Language_Resources.Staging_Resource.doesNotExistsinMixerMasterTable.Trim().Replace("[XXX]", poMixer));

                    if (type.Length == 0)
                        errorMessage.Add(Language_Resources.Staging_Resource.isNotSetPleaseCheck.Trim().Replace("[XXX]", poType));
                    else
                    {

                        if (type == "F" && isRepackResource == "N" && (sopCount == 0 || (sopCount > 0 && bulkLink != "N")))
                        {
                            errorMessage.Add(Language_Resources.Staging_Resource.youCannotReschedulePackOffPO);
                        }
                    }

                    if (sitePlantCode.Length == 0)
                    {
                        errorMessage.Add(Language_Resources.Staging_Resource.butThisPlantCodeIsNotSetForThePlant.Trim().Replace("[XXX]", poWERKS));
                    }

                    if (mixer.Length > 0 && userPline == 0 && filterInfo.AccessLevelID == 5)
                    {
                        errorMessage.Add(Language_Resources.Staging_Resource.youDoNotHavePermissionToViewPO.Trim().Replace("[XXX]", productionLine));
                    }
                }
                else
                {
                    errorMessage.Add(Language_Resources.Staging_Resource.ProcessOrderDoesNotExistsInThesystem);
                }


                dataReaderCheck.Close();
                return errorMessage;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while checking rescheduling orders", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "Process Orders: " + processOrderNumber + "; UserID: " + filterInfo.UserID + "; SiteID: " + filterInfo.SiteID);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderCheck != null && !dataReaderCheck.IsClosed)
                    dataReaderCheck.Close();
            }
        }

        #endregion

        #region Incomplete
        public List<IncompletePOInfo> GetInCompletePOForToday(IncompletePOFilter filterInfo)
        {
            IDataReader dataReaderProcessOrder = null;
            List<IncompletePOInfo> lstPOList = new List<IncompletePOInfo>();

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                int currentDate = 0;
                int currentTime = 0;

                string sortField = string.Empty;
                if (filterInfo.SortType != null)
                    sortField = filterInfo.SortType.ToString();

                Common.GetCurrentSiteDateTime(db, filterInfo.SiteID, ref currentDate, ref currentTime);

                dataReaderProcessOrder = PreweighDAL.GetInCompletePOForToday(db, currentDate, filterInfo.SiteID, filterInfo.UserID, filterInfo.AccessLevelID, filterInfo.PlineID, filterInfo.PageStartIndex, filterInfo.PageSize, sortField, filterInfo.SelectedDate);

                int i = 0;
                while (dataReaderProcessOrder.Read())
                {
                    IncompletePOInfo hdrInfo = new IncompletePOInfo();
                    hdrInfo.ProcessOrderNumber = Common.GetSafeString(dataReaderProcessOrder, "FAUFNR");
                    hdrInfo.BatchNumber = Common.GetSafeString(dataReaderProcessOrder, "FCHARG");
                    hdrInfo.MaterialNumber = Common.GetSafeString(dataReaderProcessOrder, "FMATNR");
                    hdrInfo.MaterialDescription = Common.GetSafeString(dataReaderProcessOrder, "FIDHDESC");
                    hdrInfo.Category = Common.GetSafeString(dataReaderProcessOrder, "FCATEGORY");

                    hdrInfo.StartDate = Common.GetSafeInt32(dataReaderProcessOrder, "FSTARTDATE");
                    hdrInfo.Scheduled = Common.GetSafeInt32(dataReaderProcessOrder, "FSCHDLDATE");

                    if (i == 0)
                    {
                        hdrInfo.TotalRecords = Common.GetSafeInt32(dataReaderProcessOrder, "FCOUNT");
                        i++;
                    }

                    hdrInfo.Status = Common.GetProcessOrderStatus(Common.GetSafeString(dataReaderProcessOrder, "FHDRSTATUS"));

                    lstPOList.Add(hdrInfo);
                }

                dataReaderProcessOrder.Close();

                return lstPOList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Failed to fetch in-complete process order list", "iPAS_PreWeighService",
                   System.Reflection.MethodBase.GetCurrentMethod().Name, "UserID: " + filterInfo.UserID + "; SiteID: " + filterInfo.SiteID);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderProcessOrder != null && !dataReaderProcessOrder.IsClosed)
                    dataReaderProcessOrder.Close();
            }
        }

        public bool RescheduleProcessOrdersForSelectedDate(BasicParam basicParam, int selectedDate, int pLineID)
        {
            int createDate = 0;
            int createTime = 0;

            List<string> processOrderList = new List<string>();
            IDataReader dataReaderProcessOrders = null;
            RescheduleProcessOrderInfo rescheduleInfo = new RescheduleProcessOrderInfo();
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, rescheduleInfo.SiteID, ref createDate, ref createTime);

                dataReaderProcessOrders = PreweighDAL.GetInCompletePOForToday(db, createDate, basicParam.SiteID, basicParam.UserID, basicParam.AccessLevelID, pLineID, 0, 0, string.Empty, selectedDate);
                while (dataReaderProcessOrders.Read())
                {
                    processOrderList.Add(Common.GetSafeString(dataReaderProcessOrders, "FAUFNR"));
                }
                dataReaderProcessOrders.Close();

                if (processOrderList.Count > 0)
                {
                    rescheduleInfo.ChangeDate = createDate;
                    rescheduleInfo.ChangedTime = createTime;
                    rescheduleInfo.UserID = basicParam.UserID;
                    rescheduleInfo.SiteID = basicParam.SiteID;
                    rescheduleInfo.ProcessOrderNumber = processOrderList;
                    rescheduleInfo.Displaytype = DisplayType.ScheduledView;

                    RescheduleProcessOrders(db, rescheduleInfo, createDate, createTime);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while rescheduling process orders for selected date", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, " UserID: " + basicParam.UserID + "; SiteID: " + basicParam.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderProcessOrders != null && !dataReaderProcessOrders.IsClosed)
                    dataReaderProcessOrders.Close();
            }
        }

        #endregion

        #region ViewPreweighProcessOrder

        public ProcessOrderHdrInfo GetCompleteProcessOrderInfo(ProcessOrderAccessInfo processOrderInfo)
        {
            IDataReader dataReaderPOInfo = null;
            IDataReader dataReaderArchievePOInfo = null;
            bool isPicking = false;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                ProcessOrderHdrInfo poHeaderInfo = null;
                DataTable dtBatchBinInfo;

                PlantSettings plantSetting = Common.GetPlantSettings(db, processOrderInfo.SiteID);
                OrderPLineSettings plineSettings = Common.GetProductionLineSettings(db, processOrderInfo.SiteID, processOrderInfo.ProcessOrder);

                if (processOrderInfo.IsPOHistoryArchive == true)
                {
                    if (CommonDAL.CheckProcessOrderExistsInArchieve(db, processOrderInfo.ProcessOrder))
                    {
                        if (plantSetting.BatchDeterminationLogic == PlantBatchLogic.TRBased)
                        {
                            //Pick by TRBased
                            dataReaderArchievePOInfo = PreweighDAL.GetCompleteProcessOrderInfo_TRBased(db, processOrderInfo.SiteID, processOrderInfo.ProcessOrder, true);
                            dtBatchBinInfo = PreweighDAL.GetPOBatchBinInfo_TRBased(db, processOrderInfo.ProcessOrder, true);
                        }
                        else
                        {
                            //BatchDeterminationLogic == REAL TIME (MES PROPOSES BATCH)
                            if (processOrderInfo.POProcess == POProcess.Picking || plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Together)
                            {
                                //Picking
                                isPicking = true;
                                dataReaderArchievePOInfo = PreweighDAL.GetCompleteProcessOrderInfo_RealTime(db, processOrderInfo.SiteID, processOrderInfo.ProcessOrder, isPicking, plantSetting.PickKitProcess.ToString(), true);
                                dtBatchBinInfo = PreweighDAL.GetPOBatchBinInfo_PickPO_RealTime(db, processOrderInfo.ProcessOrder, true);
                            }
                            else
                            {
                                //Kitting
                                isPicking = false;
                                dataReaderArchievePOInfo = PreweighDAL.GetCompleteProcessOrderInfo_RealTime(db, processOrderInfo.SiteID, processOrderInfo.ProcessOrder, isPicking, plantSetting.PickKitProcess.ToString(), true);
                                dtBatchBinInfo = PreweighDAL.GetPOBatchBinInfo_KitPO_RealTime(db, processOrderInfo.ProcessOrder, false);

                                //Select reserved quantity info.
                                DataTable dtReservedBatchInfo = PreweighDAL.GetPOBatchBinInfo_KitPOReserve_RealTime(db, processOrderInfo.ProcessOrder, false);
                                dtBatchBinInfo.Merge(dtReservedBatchInfo);
                            }
                        }

                        //CR-2150 - Jun 14,2016 -siraj - display icons for concentration rate enabled materials, pre-process materials; PlineSetting object is passed
                        poHeaderInfo = ViewPreweighProcessOrderInfo(db, processOrderInfo.SiteID, processOrderInfo.ProcessOrder, dataReaderArchievePOInfo, dtBatchBinInfo, plantSetting
                            , processOrderInfo.POProcess, plineSettings, true);

                        if (dataReaderArchievePOInfo != null && !dataReaderArchievePOInfo.IsClosed)
                            dataReaderArchievePOInfo.Close();
                    }
                }

                if (poHeaderInfo == null)
                {
                    if (plantSetting.BatchDeterminationLogic == PlantBatchLogic.TRBased)
                    {
                        isPicking = true;
                        dataReaderPOInfo = PreweighDAL.GetCompleteProcessOrderInfo_TRBased(db, processOrderInfo.SiteID, processOrderInfo.ProcessOrder, false);
                        dtBatchBinInfo = PreweighDAL.GetPOBatchBinInfo_TRBased(db, processOrderInfo.ProcessOrder, false);
                    }
                    else
                    {
                        if (processOrderInfo.POProcess == POProcess.Picking || plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Together)
                        {
                            isPicking = true;
                            dataReaderPOInfo = PreweighDAL.GetCompleteProcessOrderInfo_RealTime(db, processOrderInfo.SiteID, processOrderInfo.ProcessOrder, isPicking, plantSetting.PickKitProcess.ToString(), false);
                            dtBatchBinInfo = PreweighDAL.GetPOBatchBinInfo_PickPO_RealTime(db, processOrderInfo.ProcessOrder, false);
                        }
                        else
                        {
                            isPicking = false;
                            dataReaderPOInfo = PreweighDAL.GetCompleteProcessOrderInfo_RealTime(db, processOrderInfo.SiteID, processOrderInfo.ProcessOrder, isPicking, plantSetting.PickKitProcess.ToString(), false);
                            dtBatchBinInfo = PreweighDAL.GetPOBatchBinInfo_KitPO_RealTime(db, processOrderInfo.ProcessOrder, false);

                            //Select reserved quantity info.
                            DataTable dtReservedBatchInfo = PreweighDAL.GetPOBatchBinInfo_KitPOReserve_RealTime(db, processOrderInfo.ProcessOrder, false);
                            dtBatchBinInfo.Merge(dtReservedBatchInfo);
                        }
                    }

                    //CR-2150 - Jun 14,2016 -siraj - display icons for concentration rate enabled materials, pre-process materials; PlineSetting object is passed
                    poHeaderInfo = ViewPreweighProcessOrderInfo(db, processOrderInfo.SiteID, processOrderInfo.ProcessOrder, dataReaderPOInfo, dtBatchBinInfo, plantSetting
                        , processOrderInfo.POProcess, plineSettings, false);

                    if (dataReaderPOInfo != null && !dataReaderPOInfo.IsClosed)
                        dataReaderPOInfo.Close();
                }

                return poHeaderInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching process order complete details", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "Process Order: " + processOrderInfo.ProcessOrder + "; UserID: " + processOrderInfo.UserID + "; SiteID: " + processOrderInfo.SiteID);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderArchievePOInfo != null && !dataReaderArchievePOInfo.IsClosed)
                    dataReaderArchievePOInfo.Close();

                if (dataReaderPOInfo != null && !dataReaderPOInfo.IsClosed)
                    dataReaderPOInfo.Close();
            }
        }

        private ProcessOrderHdrInfo ViewPreweighProcessOrderInfo(Database db, int siteID, string processOrder, IDataReader dataReaderPOInfo, DataTable dtBatchBinInfo
            , PlantSettings plantSetting, POProcess poProcess, OrderPLineSettings plineSettings, bool isFromArchieve)
        {
            try
            {
                int currentDate = 0;
                int currentTime = 0;
                decimal preweighedQty = 0;
                bool hasPreweighInCompleteMaterial = false;
                bool isQtyRechecked = false;

                int sopID = 0;
                int groupID = 0;
                bool maintainSameSOPForAll = false;
                bool processOrderStarted = false;
                string poMaterial = string.Empty;

                Common.GetCurrentSiteDateTime(db, siteID, ref currentDate, ref currentTime);

                ProcessOrderHdrInfo poHeaderInfo = null;
                List<ProcessOrderItemInfo> itemInfo = null;

                int i = 0;

                DataTable dtMissingMaterialListForPO = PreweighDAL.GetAllMissingMaterialListForProcessOrder(db, siteID, processOrder);

                //CR - 2150 - Jun 14th -siraj - display icons for concentration rate enabled materials, pre-process materials; 
                ManufactureDAL.GetSOPIDAndGroupIDInfo(db, siteID, processOrder, isFromArchieve, out poMaterial, out sopID, out groupID, out maintainSameSOPForAll, out processOrderStarted);

                while (dataReaderPOInfo.Read())
                {
                    #region POHeader
                    if (i == 0)
                    {
                        poHeaderInfo = new ProcessOrderHdrInfo();
                        itemInfo = new List<ProcessOrderItemInfo>();

                        poHeaderInfo.ProcessOrder = Common.GetSafeString(dataReaderPOInfo, "FAUFNR");
                        poHeaderInfo.Plant = Common.GetSafeString(dataReaderPOInfo, "FWERKS");
                        poHeaderInfo.Material = Common.GetSafeString(dataReaderPOInfo, "FMATNRPO");
                        poHeaderInfo.RecipeGroup = Common.GetSafeString(dataReaderPOInfo, "FRECIPEGROUP");
                        poHeaderInfo.BOM = Common.GetSafeString(dataReaderPOInfo, "FBOM");
                        poHeaderInfo.Recipe = Common.GetSafeString(dataReaderPOInfo, "FRECIPE");
                        poHeaderInfo.TotalQty = Common.GetSafeDecimal(dataReaderPOInfo, "FTOTALQTY");
                        poHeaderInfo.UOM = Common.GetSafeString(dataReaderPOInfo, "FMEINSPO");
                        poHeaderInfo.Description = Common.GetSafeString(dataReaderPOInfo, "FIDHDESCPO");
                        poHeaderInfo.Batch = Common.GetSafeString(dataReaderPOInfo, "FCHARGPO");
                        poHeaderInfo.AltBOM = Common.GetSafeString(dataReaderPOInfo, "FALTBOM");
                        poHeaderInfo.StartDate = Common.GetSafeInt32(dataReaderPOInfo, "FSTARTDATE");
                        poHeaderInfo.FinishDate = Common.GetSafeInt32(dataReaderPOInfo, "FFINISHDATE");
                        poHeaderInfo.Category = Common.GetSafeString(dataReaderPOInfo, "FCATEGORY");
                        poHeaderInfo.Status = Common.GetProcessOrderStatus(Common.GetSafeString(dataReaderPOInfo, "FHDRSTATUS"));
                        poHeaderInfo.QIStatus = Common.GetQualityStatus(Common.GetSafeString(dataReaderPOInfo, "FQISTATUS"));

                        poHeaderInfo.ScheduledDate = Common.GetSafeInt32(dataReaderPOInfo, "FSCHDLDATE");
                        poHeaderInfo.CurrentServerDate = currentDate;

                        poHeaderInfo.POPickingKittingProcess = plantSetting.PickKitProcess;
                        poHeaderInfo.PlantBatchDeterminationLogic = plantSetting.BatchDeterminationLogic;
                        poHeaderInfo.POProcess = poProcess;

                        string lastName = Common.GetSafeString(dataReaderPOInfo, "FLASTNAME");
                        string firstName = Common.GetSafeString(dataReaderPOInfo, "FFIRSTNAME");

                        poHeaderInfo.UserName = lastName.ToUpper() + " " + firstName.ToUpper();
                        poHeaderInfo.UserName = poHeaderInfo.UserName.TrimStart(' ');

                        if (plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Seperate)
                        {
                            if (poHeaderInfo.POProcess == POProcess.Picking)
                            {
                                poHeaderInfo.POPickOrKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(dataReaderPOInfo, "FPICKSTATUS"));
                                poHeaderInfo.ActualStartDate = Common.GetSafeInt32(dataReaderPOInfo, "FPREWEIGHACTSTRDATE");
                                poHeaderInfo.ActualStartTime = Common.GetSafeInt32(dataReaderPOInfo, "FPREWEIGHSTARTTIME");
                                poHeaderInfo.ActualFinishDate = Common.GetSafeInt32(dataReaderPOInfo, "FPICKINGENDDATE");
                                poHeaderInfo.ActualFinishTime = Common.GetSafeInt32(dataReaderPOInfo, "FPICKINGENDTIME");
                                isQtyRechecked = Common.GetSafeString(dataReaderPOInfo, "FPICKEXCEEDQTYCHECK") == "Y" ? true : false;
                            }
                            else
                            {
                                poHeaderInfo.POPickOrKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(dataReaderPOInfo, "FKITSTATUS"));
                                poHeaderInfo.ActualStartDate = Common.GetSafeInt32(dataReaderPOInfo, "FKITTINGSTARTDATE");
                                poHeaderInfo.ActualStartTime = Common.GetSafeInt32(dataReaderPOInfo, "FKITTINGSTARTTIME");
                                poHeaderInfo.ActualFinishDate = Common.GetSafeInt32(dataReaderPOInfo, "FKITTINGENDDATE");
                                poHeaderInfo.ActualFinishTime = Common.GetSafeInt32(dataReaderPOInfo, "FKITTINGENDTIME");
                                isQtyRechecked = Common.GetSafeString(dataReaderPOInfo, "FKITEXCEEDQTYCHECK") == "Y" ? true : false;
                            }
                        }
                        else
                        {
                            poHeaderInfo.POPickOrKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(dataReaderPOInfo, "FKITSTATUS"));
                            poHeaderInfo.ActualStartDate = Common.GetSafeInt32(dataReaderPOInfo, "FPREWEIGHACTSTRDATE");
                            poHeaderInfo.ActualStartTime = Common.GetSafeInt32(dataReaderPOInfo, "FPREWEIGHSTARTTIME");
                            poHeaderInfo.ActualFinishDate = Common.GetSafeInt32(dataReaderPOInfo, "FPREWEIGHACTFINDATE");
                            poHeaderInfo.ActualFinishTime = Common.GetSafeInt32(dataReaderPOInfo, "FPREWEIGHENDTIME");

                            isQtyRechecked = Common.GetSafeString(dataReaderPOInfo, "FKITEXCEEDQTYCHECK") == "Y" ? true : false;
                        }

                        if (poHeaderInfo.Description.Trim().Length == 0)
                            poHeaderInfo.MaterialDefinitionMissing = true;
                    }
                    #endregion

                    int tbNum = Common.GetSafeInt32(dataReaderPOInfo, "FTBNUM");
                    int tbPOS = Common.GetSafeInt32(dataReaderPOInfo, "FTBPOS");
                    string movInd = Common.GetSafeString(dataReaderPOInfo, "FMOVIND");
                    string itemBatch = Common.GetSafeString(dataReaderPOInfo, "FCHARG");
                    string isAddition = Common.GetSafeString(dataReaderPOInfo, "FISADDITION");
                    int stagingLineItm = Common.GetSafeInt32(dataReaderPOInfo, "FSTAGINGLINEITEM");     //if staging is not required then it will not exist in LDB1_PO_ITEMINFO table 

                    //Commented; as query returns only staging relevant items
                    //if ((tbNum > 0 && tbPOS > 0) || (movInd == string.Empty && itemBatch != string.Empty) || (movInd == "B") || (isAddition == "Y" && stagingLineItm > 0) || (movInd == string.Empty && plantSetting.BatchDeterminationLogic == PlantBatchLogic.RealTime))
                    //{
                    ProcessOrderItemInfo lineItem = new ProcessOrderItemInfo();

                    lineItem.LineItemNumber = Common.GetSafeInt32(dataReaderPOInfo, "FLINEITEM");
                    lineItem.MaterialNumber = Common.GetSafeString(dataReaderPOInfo, "FMATNR");
                    lineItem.Description = Common.GetSafeString(dataReaderPOInfo, "FIDHDESC");

                    lineItem.ReqQty = Common.GetSafeDecimal(dataReaderPOInfo, "FQTY");
                    lineItem.PreweighedQty = Common.GetSafeDecimal(dataReaderPOInfo, "FPREWEIGHQTY");
                    lineItem.UOM = Common.GetSafeString(dataReaderPOInfo, "FUOM");

                    lineItem.BatchNumber = itemBatch;
                    lineItem.TransferRequirementNumber = tbNum.ToString().PadLeft(10, '0');
                    lineItem.TransferReqItemNumber = tbPOS.ToString();

                    preweighedQty = preweighedQty + lineItem.PreweighedQty;

                    DataRow[] drMissingMaterial = dtMissingMaterialListForPO.Select(" FMATNR= '" + lineItem.MaterialNumber + "'");
                    if (drMissingMaterial.Count() > 0)
                    {
                        lineItem.HasMaterialShortage = true;
                    }

                    if (movInd == "B" && itemBatch == string.Empty && plantSetting.BatchDeterminationLogic == PlantBatchLogic.TRBased)
                    {
                        if (poHeaderInfo.BulkNotHavingBatch == string.Empty)
                        {
                            poHeaderInfo.BulkNotHavingBatch = lineItem.MaterialNumber;
                        }
                        else
                        {
                            poHeaderInfo.BulkNotHavingBatch = poHeaderInfo.BulkNotHavingBatch + ", " + lineItem.MaterialNumber;
                        }
                    }

                    string addition = Common.GetSafeString(dataReaderPOInfo, "FISADDITION"); ;
                    if (addition == "Y")
                        lineItem.IsAddition = true;
                    else
                        lineItem.IsAddition = false;

                    if (lineItem.Description.Trim().Length == 0)
                        poHeaderInfo.MaterialDefinitionMissing = true;

                    DataRow[] drBatchInfo = null;
                    if (plantSetting.BatchDeterminationLogic == PlantBatchLogic.RealTime)
                    {
                        if (poHeaderInfo.POProcess == POProcess.Picking)
                        {
                            lineItem.ItemPickOrKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(dataReaderPOInfo, "FITEMPICKSTATUS"));
                        }
                        else
                        {
                            lineItem.ItemPickOrKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(dataReaderPOInfo, "FITEMKITSTATUS"));
                        }
                        drBatchInfo = dtBatchBinInfo.Select(" FLINEITEM =" + lineItem.LineItemNumber);

                        if (hasPreweighInCompleteMaterial == false)
                        {
                            //Show Mark picking complete button if there are items with picking or kitting in progress or ( picking or kitting completed  status )
                            //The button should be enabled even after manufacture. because addition issued may need to be force staging complete
                            if (lineItem.ItemPickOrKitStatus == PickingOrKittingStatus.Started || (poHeaderInfo.POPickOrKitStatus != PickingOrKittingStatus.Completed && lineItem.ItemPickOrKitStatus == PickingOrKittingStatus.Completed))
                            {
                                hasPreweighInCompleteMaterial = true;
                            }
                        }
                    }
                    else
                    {
                        lineItem.Status = Common.GetProcessOrderItemStatus(Common.GetSafeString(dataReaderPOInfo, "FSTATUS"));
                        drBatchInfo = dtBatchBinInfo.Select(" FLINEITEM =" + lineItem.LineItemNumber + " AND FCHARG='" + itemBatch + "'");

                        if (hasPreweighInCompleteMaterial == false)
                        {
                            //Show Mark preweigh complete button if there are items with picking in progress or picking completed status (even if process order is moved to manufacture status)
                            if (lineItem.Status == ProcessOrderItemStatus.Staging_InProgress || (poHeaderInfo.Status != ProcessOrderStatus.Staging_Completed && lineItem.Status == ProcessOrderItemStatus.Staging_Completed))
                            {
                                hasPreweighInCompleteMaterial = true;
                            }
                        }
                    }

                    #region BatchPickedInfo
                    List<BatchInfo> batchInfoList = new List<BatchInfo>();
                    for (int row = 0; row < drBatchInfo.Length; row++)
                    {
                        BatchInfo batchInfo = new BatchInfo();
                        batchInfo.BatchNumber = drBatchInfo[row]["FCHARG"].ToString();
                        decimal qty = 0;

                        if (poHeaderInfo.POProcess == POProcess.Kitting)
                        {
                            decimal.TryParse(drBatchInfo[row]["FKITQTY"].ToString(), out qty);
                            batchInfo.QtyPicked = qty;
                            batchInfo.IsCompleted = drBatchInfo[row]["FCOMPLETED"].ToString().Trim() == "Y" ? true : false; //Assign completed status for picking if completed.
                        }
                        else
                        {
                            batchInfo.Bin = drBatchInfo[row]["FBINLOCATION"].ToString();
                            decimal.TryParse(drBatchInfo[row]["FPICKEDQTY"].ToString(), out qty);
                            batchInfo.QtyPicked = qty;
                        }

                        batchInfo.UOM = drBatchInfo[row]["FUOM"].ToString();

                        string lastName = drBatchInfo[row]["FLASTNAME"].ToString().ToUpper();
                        batchInfo.Pickedby = lastName + " " + drBatchInfo[row]["FFIRSTNAME"].ToString().ToUpper();

                        if (batchInfo.Pickedby != string.Empty)
                            lineItem.PickedBy = batchInfo.Pickedby.TrimStart(' ');

                        //batchInfo.TransferRequirementNumber = tbNum.ToString().PadLeft(10,'0');
                        //batchInfo.TransferRequirementItemNumber = tbPOS.ToString().PadLeft(4,'0');
                        //batchInfo.TransferOrderNum = drBatchInfo[row]["FTANUM"].ToString();
                        //batchInfo.TransferOrderItemNum = drBatchInfo[row]["FTAPOS"].ToString();

                        if (qty != 0)          //if staging is in-progress or completed, then show only those for which item is picked
                            batchInfoList.Add(batchInfo);
                    }

                    lineItem.BatchInfo = batchInfoList;
                    #endregion

                    //lineItem.DGClass = Common.GetSafeString(dataReaderPOInfo, "FDGCLASS");
                    lineItem.GHSInfo = iPAS_PalletInfo.PalletInfoBAL.GetMaterialGHSInfo(db, siteID, lineItem.MaterialNumber, true, false, false, true);

                    #region MaterialType
                    //CR - 2150 - Jun 14th-2016 -siraj - get the material type (pre process, concentration rate, complemantary material and kanban material
                    string itemPhaseNumber = Common.GetSafeString(dataReaderPOInfo, "FVORNR");
                    string itemStepNumber = Common.GetSafeString(dataReaderPOInfo, "FPOSNR");
                    bool isAdditionItem = isAddition == "Y" ? true : false;
                    lineItem.MaterialTypeInfo = Common.GetMaterialTypeInfo(db, siteID, processOrder, lineItem.MaterialNumber, itemPhaseNumber, itemStepNumber, sopID, plantSetting, plineSettings, isAdditionItem);
                    //CR-2150 - end
                    #endregion

                    itemInfo.Add(lineItem);

                    i++;
                    //}
                }

                if (itemInfo != null)
                    poHeaderInfo.MaterialItemInfo = itemInfo;

                if (poHeaderInfo != null)
                {
                    poHeaderInfo.HasPreweighInCompleteMaterial = hasPreweighInCompleteMaterial;
                    poHeaderInfo.PreweighedQuantity = preweighedQty;
                    if (preweighedQty == 0)
                    {
                        poHeaderInfo.IsNoItemPickOrKit = true;
                    }

                    //Check total raw material qty exceeds than total qty of PO
                    //Prince- Hide message raw material quantity exceeds if manufacturing is started-start
                    if (!isQtyRechecked && (poHeaderInfo.Status == ProcessOrderStatus.Not_Started || poHeaderInfo.Status == ProcessOrderStatus.Staging_InProgress))
                    {
                        poHeaderInfo.IsRMQtyExceedThanTotalQty = Common.IsTotalRMQtyExceedsPOQty(db, siteID, poHeaderInfo.ProcessOrder, poHeaderInfo.TotalQty, poHeaderInfo.UOM, plantSetting.SapAvailabilityStatus);
                    }
                    //Prince- Hide message raw material quantity exceeds if manufacturing is started-end
                }

                dataReaderPOInfo.Close();

                //CR - 2150 - Jun 23rd -siraj - display the icon for the pre-processing and concntrated material - start
                if (plantSetting.AdjustRMQtyBasedOnConcentrationRate)
                {
                    poHeaderInfo.IsEnabledConcentratedRate = true;
                }

                if (plantSetting.EnablePreProcessing)
                {
                    poHeaderInfo.IsEnabledPreProcessing = true;
                }
                //CR - 2150 - Jun 23rd -siraj - display icon for the material type - end


                return poHeaderInfo;
            }
            catch
            {
                throw;
            }
        }

        //No more used (was used in TR logic)
        public bool StartPreWeighProcess(int siteID, int userID, string processOrderNumber)
        {
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                if (CommonDAL.FindMissingMaterialDefinationCount(db, siteID, processOrderNumber, false) > 0)
                {
                    throw new Exception("Process order can't be started. Few raw material's defination is missing.");
                }

                string transferOrderNumber = CreateTransferOrderForProcessOrder(db, siteID, processOrderNumber, userID, false);
                if (transferOrderNumber == "-1")
                {
                    throw new Exception("Staging is not required for the process order");
                }

                return true;
            }
            catch (Exception ex)
            {
                //Common.LogException(ex, "PreWeighService", "Error while starting preweigh process", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                //   "Process Order: " + processOrderNumber);

                throw new FaultException(ex.Message);
            }
        }

        private static void Send(IAsyncResult ar)
        {
            string callerMethodName = string.Empty;
            try
            {
                AsyncResult result = (AsyncResult)ar;
                Type delegateType = result.AsyncDelegate.GetType();

                MethodInfo methodInfo = delegateType.GetMethod("EndInvoke");
                callerMethodName = methodInfo.DeclaringType.FullName;
                methodInfo.Invoke(result.AsyncDelegate, new object[] { ar });
            }
            catch (Exception ex)
            {
                Common.LogException(ex, callerMethodName, "Error occured in async call", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, string.Empty);
            }
        }

        //No more used (was used in TR logic)
        public static string CreateTransferOrderForProcessOrder(Database db, int siteID, string processOrder, int userID, bool packoffPO)
        {
            string transferOrderNumber = string.Empty;
            PlantSettings plantSetting = new PlantSettings();

            try
            {
                int currentDate = 0;
                int currentTime = 0;

                //First re-sync PO
                bool result = true;

                iPAS_SyncDataService.SyncDataServiceClient service = new iPAS_SyncDataService.SyncDataServiceClient();
                try
                {
                    bool output = service.SyncSingleProcessOrderInfo(siteID, userID, processOrder);
                    service.Close();
                    result = output;
                }
                catch
                {
                    service.Abort();
                    throw;
                }

                if (result == true)
                {
                    DataTable takDataTable = new DataTable();
                    DataTable msgDataTable = new DataTable();
                    DataTable tapDataTable = new DataTable();

                    iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

                    string userName = CommonDAL.GetUserName(db, userID);

                    plantSetting = Common.GetPlantSettings(db, siteID);

                    if (plantSetting.WarehouseNumber == string.Empty)
                    {
                        throw new Exception("Warehouse number is not configured for the plant. Please contact administrator.");
                    }
                    else
                    {
                        //if packoffPO is true then only packaging materials are considered
                        DataTable dataTableTransferReq = PreweighDAL.GetTORequiredItems(db, siteID, processOrder, packoffPO);

                        List<string> itemTransferRequirementNumbers = new List<string>();
                        List<string> poNoTRButStagingRequiredMaterials = new List<string>();
                        string previousTR = string.Empty;

                        for (int i = 0; i < dataTableTransferReq.Rows.Count; i++)
                        {
                            string transferRequirementNumber = dataTableTransferReq.Rows[i]["FTBNUM"].ToString();
                            //Finsihed goods & bulk may not have TR generated. Do not send them for TO creation. Keep them sepeartely
                            if (transferRequirementNumber.Trim().PadLeft(10, '0') != "0000000000")
                            {
                                if (previousTR != transferRequirementNumber)
                                {
                                    itemTransferRequirementNumbers.Add(transferRequirementNumber);
                                }
                                previousTR = transferRequirementNumber;
                            }
                            else
                            {
                                poNoTRButStagingRequiredMaterials.Add(dataTableTransferReq.Rows[i]["FLINEITEM"].ToString());
                            }
                        }

                        if (itemTransferRequirementNumbers.Count == 0 && poNoTRButStagingRequiredMaterials.Count == 0)
                        {
                            transferOrderNumber = "-1";         //indicator which tells no items for staging
                        }
                        else
                        {
                            System.Data.Common.DbTransaction transaction;
                            using (System.Data.Common.DbConnection connection = db.CreateConnection())
                            {
                                connection.Open();
                                transaction = connection.BeginTransaction();
                                List<string> transferOrderNumberList = new List<string>();

                                try
                                {
                                    iPASRFSAP.ProcessOrderHdrInfo poHdrInfo = null;
                                    iPASRFSAP.ProcessOrderItemInfo poItemInfo = null;

                                    for (int i = 0; i < itemTransferRequirementNumbers.Count; i++)
                                    {
                                        poHdrInfo = new iPASRFSAP.ProcessOrderHdrInfo();
                                        string transferRequirementNumber = itemTransferRequirementNumbers[i].ToString();

                                        poHdrInfo.TransferRequirementNumber = transferRequirementNumber;
                                        poHdrInfo.WareHouseNumber = plantSetting.WarehouseNumber;

                                        //Get all the transfer requirement item number against the TR number & create TO
                                        DataRow[] drLineItems = dataTableTransferReq.Select(" FTBNUM ='" + transferRequirementNumber + "'");
                                        foreach (DataRow drItem in drLineItems)
                                        {
                                            poItemInfo = new iPASRFSAP.ProcessOrderItemInfo();

                                            poItemInfo.TransferReqItemNumber = drItem["FTBPOS"].ToString();
                                            poItemInfo.LineItemNumber = Convert.ToInt32(drItem["FLINEITEM"].ToString());

                                            poHdrInfo.ItemInfoList.Add(poItemInfo);
                                        }

                                        tapDataTable = new DataTable();
                                        if (poHdrInfo.ItemInfoList.Count > 0)
                                        {
                                            sapBapiClass.CreateTransferOrder(poHdrInfo, userName, ref takDataTable, ref tapDataTable, ref msgDataTable);
                                        }

                                        for (int row = 0; row < tapDataTable.Rows.Count; row++)
                                        {
                                            decimal qty = 0;
                                            decimal.TryParse(tapDataTable.Rows[row]["VSOLA"].ToString(), out qty);

                                            iPASRFSAP.ProcessOrderItemInfo itemNum = new iPASRFSAP.ProcessOrderItemInfo();

                                            itemNum = (iPASRFSAP.ProcessOrderItemInfo)poHdrInfo.ItemInfoList.FirstOrDefault(p => p.TransferReqItemNumber == tapDataTable.Rows[row]["TBPOS"].ToString());

                                            if (row == 0)
                                            {
                                                transferOrderNumber = tapDataTable.Rows[row]["TANUM"].ToString();
                                                transferOrderNumberList.Add(transferOrderNumber);

                                                if (transferOrderNumber.Trim() == string.Empty || transferOrderNumber.Trim().PadLeft(10, '0') == "0000000000")
                                                {
                                                    throw new Exception("No transfer order created for TR: " + transferRequirementNumber);
                                                }
                                                CommonDAL.LogProcessTransactionLog(db, transaction, processOrder, ProcessTransactionLog.Preweigh_Started.ToString(), "Transfer order created successfully for TR: " + poHdrInfo.TransferRequirementNumber + "; Transfer Order: " + transferOrderNumber, userID, currentDate, currentTime);
                                            }

                                            if (itemNum != null)
                                            {
                                                int lineItemNum = itemNum.LineItemNumber;

                                                //Put unique batch for a line item in a sepearte table LDB1_PO_ITEMINFO. Total qty is qty required for that batch
                                                //SAP might have returned a batch for a line item splited by bin. LDB1_PO_ITEMINFO will have total qty for the
                                                //batch (irrespective of bin)
                                                if (PreweighDAL.CheckPOItemBatchInfoExist(db, transaction, processOrder, lineItemNum, tapDataTable.Rows[row]["MATNR"].ToString(), tapDataTable.Rows[row]["CHARG"].ToString()))
                                                {
                                                    PreweighDAL.UpdatePOItemBatchInfo(db, transaction, processOrder, lineItemNum, tapDataTable.Rows[row]["MATNR"].ToString(), tapDataTable.Rows[row]["CHARG"].ToString(), qty);
                                                }
                                                else
                                                {
                                                    PreweighDAL.InsertPOItemBatchInfo(db, transaction, processOrder, lineItemNum, tapDataTable.Rows[row]["MATNR"].ToString(), tapDataTable.Rows[row]["CHARG"].ToString(), qty, tapDataTable.Rows[row]["MEINS"].ToString());
                                                }

                                                PreweighDAL.PrepareStagingInfo(db, transaction, processOrder
                                                        , poHdrInfo.TransferRequirementNumber
                                                        , tapDataTable.Rows[row]["TBPOS"].ToString()
                                                        , lineItemNum
                                                        , tapDataTable.Rows[row]["MATNR"].ToString()
                                                        , tapDataTable.Rows[row]["TANUM"].ToString()
                                                        , tapDataTable.Rows[row]["TAPOS"].ToString()
                                                        , tapDataTable.Rows[row]["CHARG"].ToString()
                                                        , tapDataTable.Rows[row]["VLPLA"].ToString()
                                                        , qty
                                                        , tapDataTable.Rows[row]["MEINS"].ToString());
                                            }
                                        }
                                    }

                                    //Also insert staging required but no TR items - like bulk, finished goods
                                    if (!packoffPO)
                                    {
                                        string lineItems = string.Empty;
                                        for (int row = 0; row < poNoTRButStagingRequiredMaterials.Count; row++)
                                        {
                                            if (row == 0)
                                                lineItems = poNoTRButStagingRequiredMaterials[row].ToString();
                                            else
                                                lineItems = lineItems + "," + poNoTRButStagingRequiredMaterials[row].ToString();
                                        }

                                        if (lineItems != string.Empty)
                                        {
                                            PreweighDAL.PrepareStagingForNoTRButStagingRequired(db, transaction, processOrder, lineItems);
                                            PreweighDAL.PrepareItemInfoForNoTRButStagingRequired(db, transaction, processOrder, lineItems);
                                        }
                                    }

                                    Common.GetCurrentSiteDateTime(db, siteID, ref currentDate, ref currentTime);

                                    if (!packoffPO)
                                    {
                                        PreweighDAL.UpdatePreweighStartStatus(db, transaction, processOrder, userID, currentDate, currentTime, Convert.ToChar(ProcessOrderStatus.Staging_InProgress));
                                    }

                                    CommonDAL.LogProcessTransactionLog(db, transaction, processOrder, ProcessTransactionLog.Preweigh_Started.ToString(), "Process order is started successfully", userID, currentDate, currentTime);

                                    transaction.Commit();
                                }
                                catch (Exception ex)
                                {
                                    transaction.Rollback();

                                    CommonDAL.LogProcessTransactionLog(db, processOrder, ProcessTransactionLog.Error_In_Preweigh_Start.ToString(), ex.Message, userID, currentDate, currentTime);
                                    //Make sure all TO is cancelled
                                    if (plantSetting.WarehouseNumber != string.Empty)
                                    {
                                        for (int i = 0; i < transferOrderNumberList.Count; i++)
                                        {
                                            string errorMessage = CancelTo(sapBapiClass, plantSetting.WarehouseNumber, transferOrderNumberList[i], userName);
                                            if (errorMessage == string.Empty)
                                            {
                                                CommonDAL.LogProcessTransactionLog(db, processOrder, ProcessTransactionLog.Error_In_Preweigh_Start.ToString(), "TO cancelled for " + transferOrderNumberList[i], userID, currentDate, currentTime);
                                            }
                                            else
                                            {
                                                CommonDAL.LogProcessTransactionLog(db, processOrder, ProcessTransactionLog.Error_In_Preweigh_Start.ToString(), "Failed to cancel TO " + transferOrderNumberList[i] + "; " + errorMessage, userID, currentDate, currentTime);
                                            }
                                        }
                                    }

                                    throw;
                                }
                                finally
                                {
                                    connection.Close();
                                }
                            }
                        }
                    }
                }
                return transferOrderNumber;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while creating transfer order", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                  "Process Order: " + processOrder);

                throw new FaultException(ex.Message);
            }
        }

        //No more used (was used in TR logic)
        private static string CancelTo(iPASRFSAP.BAPIClass sapBapiClass, string warehouseNumber, string transferOrderNumber, string userName)
        {
            try
            {
                sapBapiClass.CancelTO(warehouseNumber, transferOrderNumber, userName);
                return string.Empty;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public ProcessOrderStatus GetProcessOrderHeaderStatus(string processOrderNumber)
        {
            IDataReader dataReaderPOStatus = null;
            try
            {
                string status = string.Empty;
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderPOStatus = PreweighDAL.GetProcessOrderHeaderStatus(db, null, processOrderNumber);

                if (dataReaderPOStatus.Read())
                {
                    status = Common.GetSafeString(dataReaderPOStatus, "FHDRSTATUS");
                }
                dataReaderPOStatus.Close();

                return Common.GetProcessOrderStatus(status);
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while checking process order status", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "Process Orders: " + processOrderNumber);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPOStatus != null && !dataReaderPOStatus.IsClosed)
                    dataReaderPOStatus.Close();
            }
        }

        public bool ForceMarkPrewighCompleted(int siteID, int userID, string processOrder)
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
            System.Data.Common.DbTransaction transaction;
            int createdDate = 0;
            int createdTime = 0;

            using (System.Data.Common.DbConnection connection = db.CreateConnection())
            {
                connection.Open();
                transaction = connection.BeginTransaction();
                try
                {
                    //Check if picking is done atleast for one line item, if not and forced preweigh completed button is used, it means system can do auto kitting completed
                    decimal totalPreweighedQty = PreweighDAL.GetPickedQuantityForLineItem(db, transaction, processOrder, 0, string.Empty);

                    Common.GetCurrentSiteDateTime(db, siteID, ref createdDate, ref createdTime);

                    string pickKitProcess = PreweighDAL.GetPickKitProcess(db, siteID);

                    if (Convert.ToChar(pickKitProcess) == Convert.ToChar(PlantPickKitProcess.Picking_Kitting_Together))
                    {
                        //Pick & kit together & hence both pick & kit should be marked as completed for Picking_Kitting_Together PO
                        StagingDAL.ForceMarkPickingCompletedForAllLineItem(db, transaction, processOrder);
                        StagingDAL.UpdateHeaderPickStatusToCompleted(db, transaction, processOrder, createdDate, createdTime, false);

                        ForceMarkKittingCompleted(db, transaction, siteID, userID, processOrder);       //Log is also added here
                    }
                    else
                    {
                        StagingDAL.ForceMarkPickingCompletedForAllLineItem(db, transaction, processOrder);
                        StagingDAL.UpdateHeaderPickStatusToCompleted(db, transaction, processOrder, createdDate, createdTime, false);

                        CommonDAL.LogProcessTransactionLog(db, transaction, processOrder, ProcessTransactionLog.Picking_Completed.ToString()
                           , "Process order is forcefully marked picking completed", userID, createdDate, createdTime);

                        if (totalPreweighedQty == 0)
                        {
                            ForceMarkKittingCompleted(db, transaction, siteID, userID, processOrder);
                        }
                    }

                    transaction.Commit();

                    return true;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    Common.LogException(ex, "PreWeighService", "Error while marking preweigh as completed (forcefully)", "iPAS_PreWeighService",
                        System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Orders: " + processOrder + "; SiteID: " + siteID);

                    throw new FaultException(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        public bool ForceMarkKittingCompleted(int siteID, int userID, string processOrder)
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
            System.Data.Common.DbTransaction transaction;

            using (System.Data.Common.DbConnection connection = db.CreateConnection())
            {
                connection.Open();
                transaction = connection.BeginTransaction();
                try
                {
                    ForceMarkKittingCompleted(db, transaction, siteID, userID, processOrder);

                    transaction.Commit();

                    return true;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    Common.LogException(ex, "PreWeighService", "Error while marking kitting as completed (forcefully)", "iPAS_PreWeighService",
                        System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Orders: " + processOrder + ";SiteID: " + siteID);

                    throw new FaultException(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        private bool ForceMarkKittingCompleted(Database db, DbTransaction transaction, int siteID, int userID, string processOrder)
        {
            //Un-reserve not used but reserved stock in staging area
            //Mark kitting completed for partially kitted items
            //Mark Header as kitting completed; If picking is already completed then mark PO as staging completed
            int createdDate = 0;
            int createdTime = 0;

            Common.GetCurrentSiteDateTime(db, siteID, ref createdDate, ref createdTime);

            //Un-reserve not used but reserved stock in staging area
            ClearUnusedStagingReservationStock(db, transaction, siteID, processOrder);
            StagingDAL.ForceMarkKittingCompletedForAllLineItem(db, transaction, processOrder);
            StagingDAL.UpdateHeaderKitStatusToCompleted(db, transaction, processOrder, createdDate, createdTime);
            //Below flag gets set when addition is issued and it should be picked by staging opeartor; Once picked, it should get cleared.
            StagingDAL.ClearPreweighPickByWho(db, transaction, processOrder);

            CommonDAL.LogProcessTransactionLog(db, transaction, processOrder, ProcessTransactionLog.Kitting_Completed.ToString()
            , "Process order is forcefully marked kitting completed", userID, createdDate, createdTime);

            return true;
        }

        private void ClearUnusedStagingReservationStock(Database db, DbTransaction transaction, int siteID, string processOrder)
        {
            decimal pickedQty = 0;
            decimal kittedQuantity = 0;
            decimal autoKittedQuantity = 0;

            DataTable orderItemTable = StagingDAL.GetAllPickingRequiredItemsForOrder(db, transaction, siteID, processOrder, string.Empty);
            OrderPLineSettings plineSettings = Common.GetProductionLineSettings(db, siteID, processOrder);

            for (int row = 0; row < orderItemTable.Rows.Count; row++)
            {
                decimal.TryParse(orderItemTable.Rows[row]["FPICKEDQTY"].ToString().Trim(), out pickedQty);
                decimal.TryParse(orderItemTable.Rows[row]["FKITTEDQTY"].ToString().Trim(), out  kittedQuantity);
                decimal.TryParse(orderItemTable.Rows[row]["FAUTOKITTEDQTY"].ToString().Trim(), out  autoKittedQuantity);

                string kitStatus = orderItemTable.Rows[row]["FKITSTATUS"].ToString();
                string materialNumber = orderItemTable.Rows[row]["FIDHID"].ToString();

                if (kitStatus == "S" || kitStatus == "N")
                {
                    //Picked or reserved qty is let's say 20 KG; 5KG is auto kitted from PSA and 10KG is kitted from staging area. On force kitting completion (20-10) = 10 KG unused out of reserve should return back to staging area
                    decimal unusedQty = pickedQty - (kittedQuantity - autoKittedQuantity); //Exclude auto kitted qty from PSA

                    if (unusedQty > 0)      //Picked qty is more than kitted then unused qty should be made available for other PO
                    {
                        StagingDAL.UpdateUnusedStagingReservedQty(db, transaction, siteID, plineSettings.StagingArea, plineSettings.StagingBin, materialNumber, unusedQty);
                    }
                }
            }
        }

        public bool ConfirmRMQtyExceedsIssue(BasicParam basicInfo, string processOrderNum, bool isPickInfo)
        {
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                return StagingDAL.UpdateRMQuantityReCheck(db, processOrderNum, isPickInfo);
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while updating quantity recheck", "iPAS_PreWeighService",
                        System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Order: " + processOrderNum + ";SiteID: " + basicInfo.SiteID + ", UserID: " + basicInfo.UserID);

                throw new FaultException(ex.Message);
            }
        }

        #endregion

        #region KitLabel

        /* CR-1551  Siva - Kit,Truck Token Label -Start */
        public int CreateKitLabel(PrintPreweighLabel printKitLabelInfo)
        {

            try
            {
                int result = 0;
                string kitLabel = string.Empty;
                int lineItemNumber = 1;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                kitLabel = PreweighDAL.CheckPreweighLabelExists(db, printKitLabelInfo.ProcessOrderNumber);

                if (kitLabel.Trim().Length == 0)
                {
                    int currentDate = 0;
                    int currentTime = 0;

                    Common.GetCurrentSiteDateTime(db, printKitLabelInfo.SiteID, ref currentDate, ref currentTime);
                    kitLabel = "STG" + printKitLabelInfo.ProcessOrderNumber.Trim().PadLeft(12, '0');
                    PreweighDAL.InsertPreWeighLabel(db, printKitLabelInfo.ProcessOrderNumber, kitLabel, lineItemNumber, printKitLabelInfo.UserID, currentDate);
                }

                iPAS_PalletInfo.PrintProductLabelInfo printLabelInfo = new iPAS_PalletInfo.PrintProductLabelInfo();
                printLabelInfo.LabelNumber = kitLabel;
                printLabelInfo.LabelFormatType = iPAS_PalletInfo.LabelFormatType.Kit_Label;
                printLabelInfo.noOfPallets = printKitLabelInfo.NumberOfPallet;
                printLabelInfo.NumberOfCopies = printKitLabelInfo.NumberOfLabel;
                printLabelInfo.PrinterID = printKitLabelInfo.PrinterID;
                printLabelInfo.SiteID = printKitLabelInfo.SiteID;
                printLabelInfo.UserID = printKitLabelInfo.UserID;

                result = iPAS_PalletInfo.PalletInfoBAL.PrintMESLabel(db, printLabelInfo);

                if (CommonDAL.CheckUserExistsForPrinter(db, printKitLabelInfo.UserID))

                    CommonDAL.SetUserDefaultSTGPrinter(db, printKitLabelInfo.UserID, printKitLabelInfo.PrinterID);

                else

                    CommonDAL.InsertUserDefaultSTGPrinter(db, printKitLabelInfo.UserID, printKitLabelInfo.PrinterID);


                return result;

            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while creating kit labels", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Orders: " + printKitLabelInfo.ProcessOrderNumber + "; SiteID: " + printKitLabelInfo.SiteID.ToString().Trim());
                throw new FaultException(ex.Message);
            }

        }
        /* CR-1551  Siva - Kit,Truck Token Label -End */

        private static void PrintKitLabel(Database db, KitLabelInfo kitLabelInfo, PrintPreweighLabel printKitLabelInfo, string userName, string fileName)
        {
            IDataReader dataReaderInfo = null;
            try
            {
                string printerShortName = string.Empty;
                string incompleteMaterialDesc = string.Empty;

                dataReaderInfo = CommonDAL.GetPrinterShortName(db, printKitLabelInfo.PrinterID);
                if (dataReaderInfo.Read())
                {
                    printerShortName = Common.GetSafeString(dataReaderInfo, "FPRINTERSHORTNAME");
                }
                dataReaderInfo.Close();

                if (kitLabelInfo.POStatus == ProcessOrderStatus.Staging_InProgress)
                {
                    fileName = fileName + "_INCOMP_KIT_" + printerShortName + ".txt";

                    int index = 0;

                    dataReaderInfo = PreweighDAL.GetIncompleteKitList(db, printKitLabelInfo.SiteID, kitLabelInfo.ProcessOrder);
                    while (dataReaderInfo.Read())
                    {
                        if (incompleteMaterialDesc.Trim().Length == 0)
                            incompleteMaterialDesc = Common.GetSafeString(dataReaderInfo, "FMATNR") + "|" + Common.GetSafeString(dataReaderInfo, "FIDHDESC");
                        else
                            incompleteMaterialDesc = incompleteMaterialDesc + "|" + Common.GetSafeString(dataReaderInfo, "FMATNR") + "|" + Common.GetSafeString(dataReaderInfo, "FIDHDESC");

                        index++;

                        if (index == 4)         //maximum four
                            break;
                    }
                    dataReaderInfo.Close();
                }
                else
                {
                    fileName = fileName + "_COMP_KIT_" + printerShortName + ".txt";
                }


                #region LabelContent

                //Label Format
                /*KitLabel|Process Order Number|Product Code|Product Description|Batch Number|Total Qty|Unit|UserName|Mixer|NoOfLabel|Total Pallet|(Incomplete Material description(if kitting is not completed) */

                StringBuilder writeToFile = new StringBuilder();

                writeToFile.Append(kitLabelInfo.KitLabel.Trim());
                writeToFile.Append("|");
                writeToFile.Append(kitLabelInfo.ProcessOrder.Trim());
                writeToFile.Append("|");
                writeToFile.Append(kitLabelInfo.MaterialNumber.Trim());
                writeToFile.Append("|");
                writeToFile.Append(kitLabelInfo.MaterialDescription.Trim());
                writeToFile.Append("|");
                writeToFile.Append(kitLabelInfo.BatchNumber.Trim());
                writeToFile.Append("|");
                writeToFile.Append(kitLabelInfo.TotalQty.ToString().Trim());
                writeToFile.Append("|");
                writeToFile.Append(kitLabelInfo.Unit.Trim());
                writeToFile.Append("|");
                writeToFile.Append(userName.Trim());
                writeToFile.Append("|");
                writeToFile.Append(kitLabelInfo.Resource.Trim());
                writeToFile.Append("|");
                writeToFile.Append(printKitLabelInfo.NumberOfLabel.ToString().Trim());
                writeToFile.Append("|");
                writeToFile.Append(printKitLabelInfo.NumberOfPallet.ToString().Trim());

                if (incompleteMaterialDesc.Length > 0)
                {
                    writeToFile.Append("|");
                    writeToFile.Append(incompleteMaterialDesc.Trim());
                }

                #endregion

                //string targetFile = ConfigurationManager.AppSettings["BarCodeLabelLocation"] + fileName + "_KIT_" + printerShortName + ".txt";
                string targetFile = ConfigurationManager.AppSettings["BarCodeLabelLocation"] + fileName;

                using (FileStream fs = new FileStream(targetFile, FileMode.Create, FileAccess.Write))
                {
                    using (StreamWriter sw = new StreamWriter(fs))
                    {
                        sw.WriteLine(writeToFile.ToString());
                        sw.Close();
                    }
                    fs.Close();
                }
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "StagingService", "Error while creating printing kit labels", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Kit Label: " + kitLabelInfo.KitLabel + "; SiteID: " + printKitLabelInfo.SiteID.ToString() + ";User ID: " + printKitLabelInfo.UserID.ToString());
            }
            finally
            {
                if (dataReaderInfo != null && !dataReaderInfo.IsClosed)
                    dataReaderInfo.Close();
            }
        }

        #endregion

        #region RevertPO
        public ProcessOrderHdrInfo GetProcessOrderInfoForRevertPreweigh(FilterInfo filterInfo)
        {
            IDataReader dataReaderPOInfo = null;
            ProcessOrderHdrInfo poHeaderInfo = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                string pickKitProcess = PreweighDAL.GetPickKitProcess(db, filterInfo.SiteID);
                PlantPickKitProcess plantPickKitProcess = (PlantPickKitProcess)Convert.ToChar(pickKitProcess);

                dataReaderPOInfo = PreweighDAL.GetProcessOrderInfoForRevertPreweigh(db, filterInfo.SiteID, filterInfo.ProcessOrderNumber);

                int i = 0;

                List<ProcessOrderItemInfo> itemInfo = null;
                string userName = string.Empty;
                while (dataReaderPOInfo.Read())
                {
                    if (i == 0)
                    {
                        poHeaderInfo = new ProcessOrderHdrInfo();
                        itemInfo = new List<ProcessOrderItemInfo>();

                        poHeaderInfo.ProcessOrder = Common.GetSafeString(dataReaderPOInfo, "FAUFNR");
                        poHeaderInfo.Material = Common.GetSafeString(dataReaderPOInfo, "FMATNRPO");
                        poHeaderInfo.Description = Common.GetSafeString(dataReaderPOInfo, "FIDHDESCPO");
                        poHeaderInfo.Batch = Common.GetSafeString(dataReaderPOInfo, "FCHARGPO");
                        poHeaderInfo.Category = Common.GetSafeString(dataReaderPOInfo, "FCATEGORY");
                        poHeaderInfo.Status = Common.GetProcessOrderStatus(Common.GetSafeString(dataReaderPOInfo, "FHDRSTATUS"));
                        poHeaderInfo.QIStatus = Common.GetQualityStatus(Common.GetSafeString(dataReaderPOInfo, "FQISTATUS"));

                        poHeaderInfo.POPickingKittingProcess = plantPickKitProcess;

                        poHeaderInfo.POPickOrKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(dataReaderPOInfo, "FKITSTATUS"));
                        poHeaderInfo.IsKittingStarted = true;
                        if (poHeaderInfo.POPickOrKitStatus == PickingOrKittingStatus.Not_Started)
                        {
                            poHeaderInfo.POPickOrKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(dataReaderPOInfo, "FPICKSTATUS"));
                            poHeaderInfo.IsKittingStarted = false;
                        }
                    }

                    ProcessOrderItemInfo lineItem = new ProcessOrderItemInfo();

                    lineItem.LineItemNumber = Common.GetSafeInt32(dataReaderPOInfo, "FLINEITEM");
                    lineItem.MaterialNumber = Common.GetSafeString(dataReaderPOInfo, "FMATNR");
                    lineItem.BatchNumber = Common.GetSafeString(dataReaderPOInfo, "FCHARG");
                    lineItem.Description = Common.GetSafeString(dataReaderPOInfo, "FIDHDESC");
                    lineItem.ReqQty = Common.GetSafeDecimal(dataReaderPOInfo, "FQTY");

                    if (poHeaderInfo.IsKittingStarted == true)
                        lineItem.PreweighedQty = Common.GetSafeDecimal(dataReaderPOInfo, "FKITQTY");
                    else
                        lineItem.PreweighedQty = Common.GetSafeDecimal(dataReaderPOInfo, "FPREWEIGHQTY");

                    lineItem.UOM = Common.GetSafeString(dataReaderPOInfo, "FUOM");

                    if (poHeaderInfo.IsKittingStarted == true)
                        lineItem.ItemPickOrKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(dataReaderPOInfo, "FITEMKITSTATUS"));
                    else
                        lineItem.ItemPickOrKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(dataReaderPOInfo, "FITEMPICKSTATUS"));

                    userName = PreweighDAL.GetPickedUser(db, filterInfo.ProcessOrderNumber, filterInfo.SiteID, lineItem.LineItemNumber, lineItem.BatchNumber);
                    if (userName != string.Empty)
                    {
                        lineItem.PickedBy = userName;
                    }

                    //lineItem.DGClass = Common.GetSafeString(dataReaderPOInfo, "FDGCLASS");
                    lineItem.GHSInfo = iPAS_PalletInfo.PalletInfoBAL.GetMaterialGHSInfo(db, filterInfo.SiteID, lineItem.MaterialNumber, false, false, false, false);

                    //DataRow[] drBatchInfo = dtBatchBinInfo.Select(" FLINEITEM =" + lineItem.LineItemNumber + " AND FCHARG='" + lineItem.BatchNumber + "'");
                    //List<BatchInfo> batchInfoList = new List<BatchInfo>();
                    //for (int row = 0; row < drBatchInfo.Length; row++)
                    //{
                    //    decimal qtyPicked = 0;
                    //    decimal.TryParse(drBatchInfo[row]["FPICKEDQTY"].ToString(), out qtyPicked);
                    //    if (qtyPicked > 0)
                    //    {
                    //        BatchInfo batchInfo = new BatchInfo();
                    //        batchInfo.BatchNumber = drBatchInfo[row]["FCHARG"].ToString();
                    //        batchInfo.Bin = drBatchInfo[row]["FBINLOCATION"].ToString();

                    //        batchInfo.QtyPicked = qtyPicked;
                    //        batchInfo.UOM = drBatchInfo[row]["FUOM"].ToString();
                    //        batchInfo.Pickedby = drBatchInfo[row]["FFIRSTNAME"].ToString();

                    //        if (batchInfo.Pickedby != string.Empty)
                    //        {
                    //            lineItem.PickedBy = batchInfo.Pickedby;
                    //        }

                    //        batchInfoList.Add(batchInfo);
                    //    }
                    //}
                    //lineItem.BatchInfo = batchInfoList;

                    itemInfo.Add(lineItem);
                    i++;
                }

                if (itemInfo != null)
                    poHeaderInfo.MaterialItemInfo = itemInfo;

                dataReaderPOInfo.Close();

                return poHeaderInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching process order info for revert", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "Process Orders: " + filterInfo.ProcessOrderNumber + "; UserID: " + filterInfo.UserID + "; SiteID: " + filterInfo.SiteID);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPOInfo != null && !dataReaderPOInfo.IsClosed)
                    dataReaderPOInfo.Close();
            }
        }

        //public ProcessOrderItemInfo GetProcessOrderSingleLineItemInfo(int siteID, int userID, string processOrderNumber, int lineItemNumber, string batchNumber)
        //{
        //    IDataReader dataReaderPOInfo = null;
        //    ProcessOrderItemInfo lineItem = new ProcessOrderItemInfo();
        //    try
        //    {
        //        Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

        //        dataReaderPOInfo = PreweighDAL.GetProcessOrderSingleLineItemInfo(db, siteID, processOrderNumber, lineItemNumber, batchNumber);
        //        int i = 0;

        //        List<BatchInfo> batchInfoList = new List<BatchInfo>();
        //        while (dataReaderPOInfo.Read())
        //        {
        //            if (i == 0)
        //            {
        //                lineItem.LineItemNumber = Common.GetSafeInt32(dataReaderPOInfo, "FLINEITEM");
        //                lineItem.MaterialNumber = Common.GetSafeString(dataReaderPOInfo, "FMATNR");
        //                lineItem.BatchNumber = Common.GetSafeString(dataReaderPOInfo, "FCHARG");
        //                lineItem.Description = Common.GetSafeString(dataReaderPOInfo, "FIDHDESC");
        //                lineItem.ReqQty = Common.GetSafeDecimal(dataReaderPOInfo, "FQTY");
        //                lineItem.PreweighedQty = Common.GetSafeDecimal(dataReaderPOInfo, "FPICKEDQTY");
        //                lineItem.UOM = Common.GetSafeString(dataReaderPOInfo, "FUOM");

        //                lineItem.Status = Common.GetProcessOrderItemStatus(Common.GetSafeString(dataReaderPOInfo, "FSTATUS"));
        //                lineItem.DGClass = Common.GetSafeString(dataReaderPOInfo, "FDGCLASS");
        //            }

        //            //decimal qtyPicked = Common.GetSafeDecimal(dataReaderPOInfo, "FPICKEDQTY");

        //            //if (qtyPicked > 0)
        //            //{
        //            //    BatchInfo batchInfo = new BatchInfo();
        //            //    batchInfo.BatchNumber = Common.GetSafeString(dataReaderPOInfo, "FCHARG");
        //            //    batchInfo.Bin = Common.GetSafeString(dataReaderPOInfo, "FBINLOCATION");
        //            //    batchInfo.QtyPicked = Common.GetSafeDecimal(dataReaderPOInfo, "FPICKEDQTY");
        //            //    batchInfo.UOM = Common.GetSafeString(dataReaderPOInfo, "FUOM");

        //            //    batchInfoList.Add(batchInfo);
        //            //}

        //            i++;
        //        }

        //        lineItem.BatchInfo = batchInfoList;

        //        dataReaderPOInfo.Close();

        //        return lineItem;
        //    }
        //    catch (Exception ex)
        //    {
        //        Common.LogException(ex, "PreWeighService", "Error while fetching lineitem info for process order.", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
        //            "Process Orders: " + processOrderNumber + "; LineItem: " + lineItemNumber + "; SiteID: " + siteID);

        //        throw new FaultException(ex.Message);
        //    }
        //    finally
        //    {
        //        if (dataReaderPOInfo != null && !dataReaderPOInfo.IsClosed)
        //            dataReaderPOInfo.Close();
        //    }
        //}

        public bool RevertPreweighCompletely(string processOrder, BasicParam basicParam)
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

            //string pickKitProcess = PreweighDAL.GetPickKitProcess(db, basicParam.SiteID);
            RevertPickingKittingCompletely(db, processOrder, basicParam);

            return true;
        }

        //private bool RevertPreweighCompletelyPickKitTogether(Database db, string processOrder, BasicParam basicParam)
        //{
        //    System.Data.Common.DbTransaction transaction;

        //    int currentDate = 0;
        //    int currentTime = 0;

        //    DataTable dtStagedMaterial = PreweighDAL.GetStagedMaterialQtyForPO(db, processOrder);

        //    using (System.Data.Common.DbConnection connection = db.CreateConnection())
        //    {
        //        PlantSettings plantSetting = new PlantSettings();
        //        IDataReader dataReaderTransferOrder = null;

        //        connection.Open();
        //        transaction = connection.BeginTransaction();
        //        try
        //        {
        //            string userName = CommonDAL.GetUserName(db, basicParam.UserID);

        //            plantSetting = Common.GetPlantSettings(db, basicParam.SiteID);

        //            //Get all open transfer orders
        //            dataReaderTransferOrder = PreweighDAL.GetTransferOrderNumberForPO(db, processOrder.Trim());
        //            List<string> transferOrders = new List<string>();
        //            if (dataReaderTransferOrder.Read())
        //            {
        //                string transferOrderNumber = Common.GetSafeString(dataReaderTransferOrder, "FTANUM");
        //                if (transferOrderNumber.Trim().PadLeft(10, '0') != "0000000000")
        //                {
        //                    transferOrders.Add(transferOrderNumber);
        //                }
        //            }
        //            dataReaderTransferOrder.Close();

        //            Common.GetCurrentSiteDateTime(db, basicParam.SiteID, ref currentDate, ref currentTime);

        //            //Un-stage materials
        //            for (int row = 0; row < dtStagedMaterial.Rows.Count; row++)
        //            {
        //                decimal stagedQty = Convert.ToDecimal(dtStagedMaterial.Rows[row]["FPICKEDQTY"].ToString());
        //                PreweighDAL.ReduceStagedMaterialQty(db, transaction, basicParam.SiteID, dtStagedMaterial.Rows[row]["FMATNR"].ToString(), dtStagedMaterial.Rows[row]["FCHARG"].ToString(), stagedQty);
        //            }

        //            PreweighDAL.RevertAllProcessOrderStagingLineItem(db, transaction, processOrder);
        //            PreweighDAL.RemoveAllProcessOrderItemInfo(db, transaction, processOrder);
        //            PreweighDAL.RevertPerweighLabel(db, transaction, processOrder);

        //            PreweighDAL.RevertAllProcessOrderLineItem(db, transaction, processOrder, Convert.ToChar(ProcessOrderItemStatus.Not_Started));

        //            PreweighDAL.MarkPOAsNotStarted(db, transaction, processOrder.Trim(), Convert.ToChar(ProcessOrderStatus.Not_Started));

        //            CommonDAL.LogProcessTransactionLog(db, transaction, processOrder, ProcessTransactionLog.Preweigh_Revert.ToString(), "Process order is completely reverted successfully", basicParam.UserID, currentDate, currentTime);

        //            if (transferOrders.Count > 0)
        //            {
        //                //Revert TO Creation
        //                iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

        //                for (int i = 0; i < transferOrders.Count; i++)
        //                {
        //                    string errorMessage = CancelTo(sapBapiClass, plantSetting.WarehouseNumber, transferOrders[i], userName);
        //                    if (errorMessage == string.Empty)
        //                    {
        //                        CommonDAL.LogProcessTransactionLog(db, transaction, processOrder, ProcessTransactionLog.Preweigh_Revert.ToString(), "TO cancelled successfully: " + transferOrders[i], basicParam.UserID, currentDate, currentTime);
        //                    }
        //                    else
        //                    {
        //                        CommonDAL.LogProcessTransactionLog(db, transaction, processOrder, ProcessTransactionLog.Preweigh_Revert.ToString(), "Failed to cancel TO: " + transferOrders[i] + "; " + errorMessage, basicParam.UserID, currentDate, currentTime);
        //                    }
        //                }
        //            }

        //            transaction.Commit();
        //            return true;
        //        }
        //        catch (Exception ex)
        //        {
        //            transaction.Rollback();
        //            Common.LogException(ex, "PreWeighService", "Error while reverting process order.", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
        //                "Process Orders: " + processOrder + "; UserID: " + basicParam.UserID + "; SiteID: " + basicParam.SiteID);

        //            throw new FaultException(ex.Message);
        //        }
        //        finally
        //        {
        //            if (dataReaderTransferOrder != null && !dataReaderTransferOrder.IsClosed)
        //                dataReaderTransferOrder.Close();

        //            connection.Close();
        //        }
        //    }
        //}

        private bool RevertPickingKittingCompletely(Database db, string processOrder, BasicParam basicParam)
        {
            IDataReader infoReader = null;
            try
            {
                OrderPLineSettings plineSettings = new OrderPLineSettings();
                PlantSettings plantSetting = new PlantSettings();

                PickingOrKittingStatus processOrderPickKitStatus = PickingOrKittingStatus.Not_Started;

                int currentDate = 0;
                int currentTime = 0;
                Common.GetCurrentSiteDateTime(db, basicParam.SiteID, ref currentDate, ref currentTime);

                //Get Pick & Kit header status
                infoReader = PreweighDAL.GetPickKitHeaderStatus(db, processOrder);
                if (infoReader.Read())
                {
                    processOrderPickKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(infoReader, "FKITSTATUS"));
                }
                infoReader.Close();

                //Get production line properties for PO
                plineSettings = Common.GetProductionLineSettings(db, basicParam.SiteID, processOrder);

                //Get plant settings
                plantSetting = Common.GetPlantSettings(db, basicParam.SiteID);

                using (System.Data.Common.DbConnection connection = db.CreateConnection())
                {
                    connection.Open();
                    System.Data.Common.DbTransaction transaction = connection.BeginTransaction();
                    try
                    {
                        //If kitting is already started then first do Kitting revert else revert picking
                        if (processOrderPickKitStatus != PickingOrKittingStatus.Not_Started && plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Seperate)
                        {
                            RevertKitMaterialInfoForPO(db, transaction, basicParam, plineSettings, processOrder, currentDate, currentTime);
                            PreweighDAL.RevertKitProcessOrderHeaderInfo(db, transaction, processOrder);
                        }
                        else
                        {
                            //If picking started then do followings
                            //1. Get all staging qty grouped by material
                            //2. Reduce reserved qty in staging info table
                            //3. Remove staging records for PO
                            //4. Change pick status to not started in presb item table
                            //5. Revert pick status in header also hdrstatus along with group id, staging start date, pick start date, time & pick started by
                            //Finaly add a transaction log 

                            if (processOrderPickKitStatus != PickingOrKittingStatus.Not_Started && plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Together)
                            {
                                RevertKitMaterialInfoForPO(db, transaction, basicParam, plineSettings, processOrder, currentDate, currentTime);
                                PreweighDAL.RevertKitProcessOrderHeaderInfo(db, transaction, processOrder);
                            }

                            DataTable dtPickedQty = PreweighDAL.GetAllPickedQuantityInfoForPO(db, basicParam.SiteID, processOrder);
                            DataTable autoKittedItemTable = PreweighDAL.GetAutoKittedMaterialQtyInfoForPO(db, processOrder);
                            bool autoKittedItemExists = false;
                            if (dtPickedQty.Rows.Count > 0)
                            {
                                decimal pickedQty = 0;
                                foreach (DataRow row in dtPickedQty.Rows)
                                {
                                    decimal.TryParse(row["FPICKEDQTY"].ToString(), out pickedQty);
                                    if (pickedQty > 0)
                                    {
                                        string materialNumber = row["FIDHID"].ToString().Trim();

                                        //Find the auto kitted qty for line item and don't reduce that quantity from staging area
                                        decimal autoKittedQty = 0;
                                        DataRow[] autoKittedQtyRow = autoKittedItemTable.Select("FMATNR='" + materialNumber + "'");
                                        if (autoKittedQtyRow != null && autoKittedQtyRow.Length > 0)
                                        {
                                            decimal.TryParse(autoKittedQtyRow[0]["FAUTOKITTEDQTY"].ToString().Trim(), out autoKittedQty);
                                            autoKittedItemExists = true;
                                        }

                                        if (autoKittedQty > 0)
                                            pickedQty = pickedQty - autoKittedQty;

                                        PreweighDAL.ReduceReserveredQtyInStagingArea(db, transaction, basicParam.SiteID, plineSettings.StagingArea, plineSettings.StagingBin, materialNumber, pickedQty);
                                    }
                                }
                            }

                            PreweighDAL.RevertAllProcessOrderStagingLineItem(db, transaction, processOrder);
                            PreweighDAL.RevertAllPickItemStatus(db, transaction, processOrder);
                            PreweighDAL.RevertPickProcessOrderHeaderInfo(db, transaction, processOrder);

                            //If quanity is auto kitted, then revert corresponding kit info.
                            if (autoKittedItemExists)
                            {
                                //Reduce the unconfirmed reservered qty from the PO/Line item from where quantity is reserved for PO
                                ReduceUnConfirmedReservedQuantityForPO(db, transaction, basicParam.SiteID, processOrder, 0);

                                if (plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Seperate)
                                {
                                    PreweighDAL.RevertKitItemInfoForPO(db, transaction, processOrder);
                                    PreweighDAL.RevertKitLineItemStatus(db, transaction, processOrder);
                                }
                                //Delete/Update records from LDB1_KIT_RESERVEPOINFO and LDB1_POEXTRAQTY_INFO tables
                                PreweighDAL.DeleteReservedQtyInfo(db, transaction, processOrder, 0);
                            }

                            if (plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Seperate)
                                CommonDAL.LogProcessTransactionLog(db, transaction, processOrder, ProcessTransactionLog.Preweigh_Revert.ToString(), "Picking completely reverted successfully", basicParam.UserID, currentDate, currentTime);
                        }

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Common.LogException(ex, "PreWeighService", "Error while reverting process order.", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                            "Process Orders: " + processOrder + "; UserID: " + basicParam.UserID + "; SiteID: " + basicParam.SiteID);

                        throw new FaultException(ex.Message);
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (infoReader != null && !infoReader.IsClosed)
                    infoReader.Close();
            }
        }


        private void RevertKitMaterialInfoForPO(Database db, DbTransaction transaction, BasicParam basicParam, OrderPLineSettings plineSettings, string processOrder, int currentDate, int currentTime)
        {
            //If kitting started
            //1. Get Kit line items grouped by material & batch
            //2. Do bin to bin from supply area to staging area
            //3. Increase qty in staging info area table both total qty & reserved qty
            //4. Remove all records for the PO from LDB1_PO_KITITEMINFO
            //5. Revert status of each line item which is in kitting started or completed status to Not started
            //6. Revert Kit status in header to Not started and also related kit date/time & kit started by, group id
            //Finaly add a transaction log 

            iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

            PlantSettings plantSetting = Common.GetPlantSettings(db, basicParam.SiteID);
            string userName = CommonDAL.GetUserName(db, basicParam.UserID);

            DataTable dtKittedItemInfo = PreweighDAL.GetAllKitLineItemsForPO(db, basicParam.SiteID, processOrder);

            if (dtKittedItemInfo.Rows.Count > 0)
            {
                decimal kittedQty = 0;
                string plantCode = string.Empty;
                string storageLocation = string.Empty;

                List<iPASRFSAP.LabelInfo> labelInfoList = new List<iPASRFSAP.LabelInfo>();
                foreach (DataRow row in dtKittedItemInfo.Rows)
                {
                    decimal.TryParse(row["FQTY"].ToString(), out kittedQty);

                    bool isBatchManaged = false;
                    if (row["FISBATCHMANAGED"].ToString() == "Y")
                        isBatchManaged = true;

                    plantCode = row["FWERKS"].ToString().Trim();

                    if (kittedQty > 0)
                    {
                        StagingDAL.UpdateStagingAreaInfoForMaterial(db, transaction, basicParam.SiteID, row["FMATNR"].ToString().Trim(), plineSettings.StagingBin
                            , 0, plineSettings.StagingArea, kittedQty, kittedQty, currentDate);

                        //Do bin to bin movement from supply area to staging area
                        iPASRFSAP.LabelInfo labelInfo = PrepareBinToBinMovementTable(row["FMATNR"].ToString().Trim(), plantCode, plantSetting.WarehouseNumber, row["FLGORT"].ToString(), row["FCHARG"].ToString(),
                            kittedQty, row["FUOM"].ToString(), plineSettings.SupplyArea, plineSettings.SupplyBin, plineSettings.StagingArea, plineSettings.StagingBin, string.Empty, string.Empty,
                            isBatchManaged, userName);

                        labelInfoList.Add(labelInfo);
                    }
                }

                //Reduce the unconfirmed reservered qty from the PO/Line item from where quantity is reserved for PO
                ReduceUnConfirmedReservedQuantityForPO(db, transaction, basicParam.SiteID, processOrder, 0);

                //Find out all the TOPO line item where TOPO=Revert PO line item in LDB1_KIT_RESERVEPOINFO.
                //Delete these records from LDB1_KIT_RESERVEPOINFO if FCONFIRMEDQTY=0.
                PreweighDAL.DeleteReservedQtyInfo(db, transaction, processOrder, 0);

                PreweighDAL.UpdateAllKitPalletCurrentBinToStagingBin(db, transaction, basicParam.SiteID, processOrder, plineSettings.SupplyBin, plineSettings.StagingBin);
                PreweighDAL.RevertKitItemInfoForPO(db, transaction, processOrder);
                PreweighDAL.RevertKitLineItemStatus(db, transaction, processOrder);

                //BELOW DELETE FROM LDB1_KIT_RESERVEPOINFO IS COMMENTED; There could be PO to which qty might be 
                //reserved from this PO & those PO might have already kitting completed; hence do not delete
                // PreweighDAL.DeleteUnConfirmedReservedQtyInfo(db, transaction, processOrder, 0);


                //Delete record for the line item from LDB1_POEXTRAQTY_INFO if FCONFIRMEDQTY=0 &
                //Update FTOTALQTY AND FRESERVEDQTY equal to FCONFIRMEDQTY if FCONFIRMEDQTY <> 0
                PreweighDAL.DeleteUnConfirmedExtraQuantityForPO(db, transaction, processOrder, 0);
                PreweighDAL.UpdateUnConfirmedExtraQuantityForPO(db, transaction, processOrder, 0, currentDate);

                string transferOrder = string.Empty;
                if (labelInfoList.Count > 0)
                {
                    transferOrder = sapBapiClass.MassConfirmBinTransfer(labelInfoList, userName);
                }
                CommonDAL.LogProcessTransactionLog(db, transaction, processOrder, ProcessTransactionLog.Revert_Kitting.ToString(), "Kitting reverted successfully: " + transferOrder, basicParam.UserID, currentDate, currentTime);
            }
        }

        private static iPASRFSAP.LabelInfo PrepareBinToBinMovementTable(string materialNumber, string plantCode, string warehouseNumber, string storageLocation
        , string batchNumber, decimal qty, string uom, string storageType, string sourceBin, string targetStorageType, string targetBin, string stockType
        , string vendorNumber, bool isBatchManaged, string userName)
        {
            //Do bin to bin transfer for material from picked bin location to staging area
            iPASRFSAP.LabelInfo labelInfo = new iPASRFSAP.LabelInfo();
            labelInfo.MaterialNumber = materialNumber.Trim().PadLeft(18, '0');
            labelInfo.Plant = plantCode.Trim();
            labelInfo.WareHouseNumber = warehouseNumber;
            labelInfo.StorageLocation = storageLocation.Trim();
            labelInfo.BatchNumber = batchNumber.Trim().ToUpper();
            labelInfo.Quantity = qty;
            labelInfo.Unit = uom.Trim();
            labelInfo.StorageType = storageType;
            labelInfo.CurrentBin = sourceBin;

            labelInfo.TargetStorageType = targetStorageType;
            labelInfo.BinLocation = targetBin;
            labelInfo.StockTypeFlag = stockType;
            labelInfo.VendorNumber = vendorNumber;
            labelInfo.IsBatchManaged = isBatchManaged;

            return labelInfo;
        }

        public bool RevertProcessOrderLineItem(RevertProcessOrderInfo revertPOInfoList)
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

            string pickKitProcess = PreweighDAL.GetPickKitProcess(db, revertPOInfoList.SiteID);
            RevertPickingOrKittingForLineItem(db, revertPOInfoList);

            return true;
        }

        //private bool RevertProcessOrderPreweighPickKitTogether(Database db, RevertProcessOrderInfo revertPOInfoList)
        //{
        //    System.Data.Common.DbTransaction transaction;
        //    int currentDate = 0;
        //    int currentTime = 0;
        //    int siteID = 0;
        //    DataTable dtStagedMaterial = new DataTable();

        //    if (revertPOInfoList != null)
        //    {
        //        siteID = revertPOInfoList.SiteID;
        //        dtStagedMaterial = PreweighDAL.GetStagedMaterialQtyForPO(db, revertPOInfoList.ProcessOrder);
        //    }

        //    Common.GetCurrentSiteDateTime(db, siteID, ref currentDate, ref currentTime);

        //    using (System.Data.Common.DbConnection connection = db.CreateConnection())
        //    {
        //        connection.Open();
        //        transaction = connection.BeginTransaction();
        //        try
        //        {
        //            //Update picked qty as zero for the batch, bin location of the line item number
        //            PreweighDAL.RevertProcessOrderStagingLineItem(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, revertPOInfoList.MaterialNumber
        //                , revertPOInfoList.BatchNumber);

        //            PreweighDAL.RevertProcessOrderBatchItemInfo(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, revertPOInfoList.BatchNumber, Convert.ToChar(ProcessOrderItemStatus.Not_Started));

        //            decimal pickedQty = PreweighDAL.GetProcessOrderLineItemPickedQty(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber);

        //            //PreweighDAL.RevertProcessOrderLineItemToStarted(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, Convert.ToChar(ProcessOrderItemStatus.Staging_InProgress));
        //            if (pickedQty == 0)
        //            {
        //                PreweighDAL.RevertProcessOrderLineItemToNotStarted(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, Convert.ToChar(ProcessOrderItemStatus.Not_Started));
        //            }

        //            //Also reduced staged qty
        //            DataRow[] drInfo;
        //            if (revertPOInfoList.BatchNumber.Trim().Length > 0)
        //                drInfo = dtStagedMaterial.Select("FLINEITEM=" + revertPOInfoList.LineItemNumber + " AND FMATNR ='" + revertPOInfoList.MaterialNumber.Trim().PadLeft(18, '0') + "' AND FCHARG='" + revertPOInfoList.BatchNumber + "' ");
        //            else
        //                drInfo = dtStagedMaterial.Select("FLINEITEM=" + revertPOInfoList.LineItemNumber + " AND FMATNR ='" + revertPOInfoList.MaterialNumber.Trim().PadLeft(18, '0') + "' ");

        //            if (drInfo.Length > 0)
        //            {
        //                decimal stagedQty = Convert.ToDecimal(drInfo[0]["FPICKEDQTY"].ToString());
        //                PreweighDAL.ReduceStagedMaterialQty(db, transaction, revertPOInfoList.SiteID, revertPOInfoList.MaterialNumber, revertPOInfoList.BatchNumber, stagedQty);
        //            }

        //            PreweighDAL.UpdateProcessOrderHeaderStatus(db, transaction, revertPOInfoList.ProcessOrder, Convert.ToChar(ProcessOrderStatus.Staging_InProgress));

        //            CommonDAL.LogProcessTransactionLog(db, transaction, revertPOInfoList.ProcessOrder, ProcessTransactionLog.Preweigh_Revert.ToString(),
        //                "Preweigh reverted for line item: " + revertPOInfoList.LineItemNumber + "; Batch: " + revertPOInfoList.BatchNumber, revertPOInfoList.UserID, currentDate, currentTime);


        //            transaction.Commit();
        //            return true;
        //        }
        //        catch (Exception ex)
        //        {
        //            transaction.Rollback();
        //            Common.LogException(ex, "PreWeighService", "Error while reverting process order.", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
        //                "Process Orders: " + revertPOInfoList.ProcessOrder + "; UserID: " + revertPOInfoList.UserID + "; SiteID: " + revertPOInfoList.SiteID);

        //            throw new FaultException(ex.Message);
        //        }
        //        finally
        //        {
        //            connection.Close();
        //        }
        //    }
        //}

        private bool RevertPickingOrKittingForLineItem(Database db, RevertProcessOrderInfo revertPOInfoList)
        {
            IDataReader infoReader = null;
            try
            {
                OrderPLineSettings plineSettings = new OrderPLineSettings();
                PlantSettings plantSetting = new PlantSettings();
                List<iPASRFSAP.LabelInfo> labelInfoList = null;
                decimal kittedQuantity = 0;

                int currentDate = 0;
                int currentTime = 0;
                PickingOrKittingStatus processOrderPickKitStatus = PickingOrKittingStatus.Not_Started;

                Common.GetCurrentSiteDateTime(db, revertPOInfoList.SiteID, ref currentDate, ref currentTime);

                //Get production line properties for PO                   
                plineSettings = Common.GetProductionLineSettings(db, revertPOInfoList.SiteID, revertPOInfoList.ProcessOrder);
                //Get Plant settings
                plantSetting = Common.GetPlantSettings(db, revertPOInfoList.SiteID);

                //Get Pick & Kit header status
                infoReader = PreweighDAL.GetPickKitHeaderStatus(db, revertPOInfoList.ProcessOrder);
                if (infoReader.Read())
                {
                    //Get kit status
                    processOrderPickKitStatus = Common.GetPickingOrKittingStatus(Common.GetSafeString(infoReader, "FKITSTATUS"));
                }
                infoReader.Close();

                string userName = CommonDAL.GetUserName(db, revertPOInfoList.UserID);


                using (System.Data.Common.DbConnection connection = db.CreateConnection())
                {
                    connection.Open();
                    System.Data.Common.DbTransaction transaction = connection.BeginTransaction();
                    try
                    {
                        iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(revertPOInfoList.LanguageCode);

                        //If kitting is already started then first do Kitting revert else revert picking
                        if (processOrderPickKitStatus != PickingOrKittingStatus.Not_Started && plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Seperate)
                        {
                            //Do bin to bin movement from supply area to staging area                            
                            labelInfoList = PrePareBinToBinTableForKitMaterials(db, transaction, revertPOInfoList, plantSetting, plineSettings, userName, ref kittedQuantity);

                            if (kittedQuantity > 0)
                            {
                                // increase staging quantity
                                StagingDAL.UpdateStagingAreaInfoForMaterial(db, transaction, revertPOInfoList.SiteID, revertPOInfoList.MaterialNumber, plineSettings.StagingBin
                                    , 0, plineSettings.StagingArea, kittedQuantity, kittedQuantity, currentDate);

                                PreweighDAL.UpdatePalletCurrentBinToStagingBin(db, transaction, revertPOInfoList.SiteID, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, plineSettings.SupplyBin, plineSettings.StagingBin);
                            }

                            //Reduce the unconfirmed reservered qty from the PO/Line item from where quantity is reserved for PO line item
                            ReduceUnConfirmedReservedQuantityForPO(db, transaction, revertPOInfoList.SiteID, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber);

                            PreweighDAL.RevertProcessOrderKittedLineItem(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, revertPOInfoList.BatchNumber);
                            PreweighDAL.RevertProcessOrdeSingleKitLineItem(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber);

                            // check whether the kitted line item is last or not. if it is last then update kit end date and start date to zero in header table. 
                            if (PreweighDAL.CheckIsLastKitLineItemForPO(db, transaction, revertPOInfoList.ProcessOrder, 0))
                            {
                                PreweighDAL.RevertKitProcessOrderHeaderInfo(db, transaction, revertPOInfoList.ProcessOrder);
                            }
                            else
                            {
                                PreweighDAL.RevertProcessOrderHeaderKitStartedInfo(db, transaction, revertPOInfoList.ProcessOrder, 'W', 'S');
                            }

                            //BELOW DELETE FROM LDB1_KIT_RESERVEPOINFO IS COMMENTED; There could be PO to which qty might be 
                            //reserved from this PO & those PO might have already kitting completed; hence do not delete
                            // PreweighDAL.DeleteUnConfirmedReservedQtyInfo(db, transaction, processOrder, 0);

                            //Find out all the TOPO line item where FROMPO=Revert PO line item in LDB1_KIT_RESERVEPOINFO.
                            //Delete these records from LDB1_KIT_RESERVEPOINFO if FCONFIRMEDQTY=0.
                            PreweighDAL.DeleteReservedQtyInfo(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber);

                            //Delete record for the line item from LDB1_POEXTRAQTY_INFO if FCONFIRMEDQTY=0 &
                            //Update FTOTALQTY AND FRESERVEDQTY equal to FCONFIRMEDQTY if FCONFIRMEDQTY <> 0
                            PreweighDAL.DeleteUnConfirmedExtraQuantityForPO(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber);
                            PreweighDAL.UpdateUnConfirmedExtraQuantityForPO(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, currentDate);

                            string transferOrder = string.Empty;
                            if (labelInfoList.Count > 0)
                            {
                                transferOrder = sapBapiClass.MassConfirmBinTransfer(labelInfoList, userName);
                            }

                            CommonDAL.LogProcessTransactionLog(db, transaction, revertPOInfoList.ProcessOrder, ProcessTransactionLog.Revert_Kitting.ToString(),
                            "Kitting reverted for line item: " + revertPOInfoList.LineItemNumber + ";Transfer Order: " + transferOrder, revertPOInfoList.UserID, currentDate, currentTime);
                        }
                        else
                        {
                            if (processOrderPickKitStatus != PickingOrKittingStatus.Not_Started && plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Together)
                            {
                                labelInfoList = PrePareBinToBinTableForKitMaterials(db, transaction, revertPOInfoList, plantSetting, plineSettings, userName, ref kittedQuantity);

                                StagingDAL.UpdateStagingAreaInfoForMaterial(db, transaction, revertPOInfoList.SiteID, revertPOInfoList.MaterialNumber, plineSettings.StagingBin
                                   , 0, plineSettings.StagingArea, kittedQuantity, kittedQuantity, currentDate);
                            }

                            decimal pickedQty = PreweighDAL.GetPickedQuantityForLineItem(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, revertPOInfoList.BatchNumber);

                            //Find the auto kitted qty for line item and don't reduce that quantity from staging area
                            decimal autoKittedQty = 0;
                            infoReader = PreweighDAL.GetAutoKittedQuantityForPOItem(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, revertPOInfoList.BatchNumber);
                            if (infoReader.Read())
                            {
                                autoKittedQty = Common.GetSafeDecimal(infoReader, "FAUTOKITTEDQTY");
                            }
                            infoReader.Close();

                            if (autoKittedQty > 0)
                                pickedQty = pickedQty - autoKittedQty;

                            //Remove record from staging table
                            PreweighDAL.RevertProcessOrderPickedLineItem(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, revertPOInfoList.BatchNumber);

                            if (plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Together)
                            {
                                //Delete from LDB1_PO_KITITEMINFO also if pick kit together
                                PreweighDAL.RevertProcessOrderKittedLineItem(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, revertPOInfoList.BatchNumber);
                                //Update kit status to not started.
                                PreweighDAL.RevertProcessOrdeSingleKitLineItem(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber);
                            }

                            //reduce staging quantity
                            if (plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Seperate)
                            {
                                PreweighDAL.ReduceReserveredQtyInStagingArea(db, transaction, revertPOInfoList.SiteID, plineSettings.StagingArea, plineSettings.StagingBin, revertPOInfoList.MaterialNumber, pickedQty);
                            }

                            PreweighDAL.RevertProcessOrderPickLineItemToNotStarted(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber);

                            //check whether the line item is last or not. If it is last then change the header status to not started otherwise change to staging progress.
                            if (PreweighDAL.CheckIsLastPickLineItemForPO(db, transaction, revertPOInfoList.ProcessOrder, 0))
                            {
                                if (plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Together)
                                {
                                    PreweighDAL.RevertKitProcessOrderHeaderInfo(db, transaction, revertPOInfoList.ProcessOrder);
                                }
                                PreweighDAL.RevertPickProcessOrderHeaderInfo(db, transaction, revertPOInfoList.ProcessOrder);
                            }
                            else
                            {
                                if (plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Together)
                                {
                                    PreweighDAL.RevertProcessOrderHeaderKitStartedInfo(db, transaction, revertPOInfoList.ProcessOrder, 'W', 'S');
                                }
                                PreweighDAL.RevertProcessOrderHeaderPickStartedInfo(db, transaction, revertPOInfoList.ProcessOrder);
                            }

                            //If quanity is auto kitted, then revert corresponding kit info.
                            if (autoKittedQty > 0)
                            {
                                //Reduce the unconfirmed reservered qty from the PO/Line item from where quantity is reserved for PO line item
                                ReduceReservedQuantityForPO(db, transaction, revertPOInfoList.SiteID, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, autoKittedQty);

                                if (plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Seperate)
                                {
                                    PreweighDAL.RevertProcessOrderKittedLineItem(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, revertPOInfoList.BatchNumber);

                                    // checking whether the line item completely reverted or not. If yes then updated the line item status to not started else in progress
                                    if (PreweighDAL.CheckIsLastKitLineItemForPO(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber))
                                    {
                                        PreweighDAL.RevertProcessOrdeSingleKitLineItem(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber);
                                    }
                                    else
                                    {
                                        StagingDAL.UpdateLineItemKitStatus(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, "S");
                                    }

                                }

                                //Delete/Update records from LDB1_KIT_RESERVEPOINFO and LDB1_POEXTRAQTY_INFO tables
                                PreweighDAL.DeleteReservedQtyInfo(db, transaction, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber);
                            }

                            if (plantSetting.PickKitProcess == PlantPickKitProcess.Picking_Kitting_Together)
                            {
                                string transferOrder = string.Empty;
                                if (labelInfoList.Count > 0)
                                {
                                    transferOrder = sapBapiClass.MassConfirmBinTransfer(labelInfoList, userName);
                                }
                                CommonDAL.LogProcessTransactionLog(db, transaction, revertPOInfoList.ProcessOrder, ProcessTransactionLog.Revert_Kitting.ToString(),
                               "Kitting reverted for line item: " + revertPOInfoList.LineItemNumber + ";Transfer Order: " + transferOrder, revertPOInfoList.UserID, currentDate, currentTime);

                            }
                            else
                            {
                                CommonDAL.LogProcessTransactionLog(db, transaction, revertPOInfoList.ProcessOrder, ProcessTransactionLog.Preweigh_Revert.ToString(),
                                    "Picking reverted for line item: " + revertPOInfoList.LineItemNumber + "; Qty Reverted: " + pickedQty, revertPOInfoList.UserID, currentDate, currentTime);
                            }
                        }

                        transaction.Commit();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        Common.LogException(ex, "PreWeighService", "Error while reverting process order.", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                            "Process Orders: " + revertPOInfoList.ProcessOrder + "; UserID: " + revertPOInfoList.UserID + "; SiteID: " + revertPOInfoList.SiteID);

                        throw new FaultException(ex.Message);
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (infoReader != null && !infoReader.IsClosed)
                    infoReader.Close();
            }
        }

        private List<iPASRFSAP.LabelInfo> PrePareBinToBinTableForKitMaterials(Database db, DbTransaction transaction, RevertProcessOrderInfo revertPOInfoList, PlantSettings plantSettings, OrderPLineSettings plineSettings, string userName, ref decimal kittedQuantity)
        {

            DataTable dtKittedItemInfo = PreweighDAL.GetKitLineItemInfoForPO(db, transaction, revertPOInfoList.SiteID, revertPOInfoList.ProcessOrder, revertPOInfoList.LineItemNumber, revertPOInfoList.BatchNumber);
            kittedQuantity = 0;
            List<iPASRFSAP.LabelInfo> labelInfoList = new List<iPASRFSAP.LabelInfo>();

            if (dtKittedItemInfo.Rows.Count > 0)
            {
                foreach (DataRow row in dtKittedItemInfo.Rows)
                {
                    bool isBatchManaged = false;
                    if (row["FISBATCHMANAGED"].ToString() == "Y")
                        isBatchManaged = true;

                    string movIndicator = row["FMOVIND"].ToString().Trim();

                    //kittedQuantity = kittedQuantity + Convert.ToDecimal(row["FQTY"].ToString());
                    decimal.TryParse(row["FQTY"].ToString(), out kittedQuantity);

                    string sourceBin = string.Empty;
                    string sourceBinType = string.Empty;
                    if (movIndicator == "B")
                    {
                        sourceBin = plineSettings.SupplyBulkBin;
                        sourceBinType = plineSettings.SupplyBulkArea;
                    }
                    else
                    {
                        sourceBin = plineSettings.SupplyBin;
                        sourceBinType = plineSettings.SupplyArea;
                    }

                    if (kittedQuantity > 0)
                    {
                        iPASRFSAP.LabelInfo labelInfo = PrepareBinToBinMovementTable(row["FMATNR"].ToString().Trim(), row["FWERKS"].ToString(), plantSettings.WarehouseNumber, row["FLGORT"].ToString(), row["FCHARG"].ToString(),
                        kittedQuantity, row["FUOM"].ToString(), sourceBinType, sourceBin, plineSettings.StagingArea, plineSettings.StagingBin, string.Empty, string.Empty,
                            isBatchManaged, userName);

                        labelInfoList.Add(labelInfo);
                    }
                }
            }
            return labelInfoList;
        }

        private void ReduceUnConfirmedReservedQuantityForPO(Database db, DbTransaction transaction, int siteID, string processOrder, int lineItemNumber)
        {
            DataTable unConfirmedReservedQtyTable = PreweighDAL.GetNonConfirmedReservedQtyForPO(db, transaction, processOrder, lineItemNumber);
            foreach (DataRow dr in unConfirmedReservedQtyTable.Rows)
            {
                decimal unConfirmedReservedQty = 0;
                decimal.TryParse(dr["FRESERVEDQTY"].ToString().Trim(), out unConfirmedReservedQty);
                int lineItem = 0;
                int.TryParse(dr["FLINEITEM"].ToString().Trim(), out lineItem);

                if (unConfirmedReservedQty > 0)
                {
                    ReduceReservedQuantityForPO(db, transaction, siteID, processOrder, lineItem, unConfirmedReservedQty);
                }
            }
        }

        private void ReduceReservedQuantityForPO(Database db, DbTransaction transaction, int siteID, string processOrder, int lineItemNumber, decimal unConfirmedReservedQty)
        {
            int currentDate = 0;
            int currentTime = 0;
            Common.GetCurrentSiteDateTime(db, siteID, ref currentDate, ref currentTime);

            DataTable reservedQtyInfoTable = PreweighDAL.GetNonConfirmedReservedQtyInfoForPO(db, transaction, processOrder, lineItemNumber);
            foreach (DataRow dr in reservedQtyInfoTable.Rows)
            {
                string fromPO = dr["FFROMPO"].ToString().Trim();
                int fromLineItem = 0;
                int.TryParse(dr["FFROMLINEITEM"].ToString().Trim(), out fromLineItem);
                decimal nonConfirmedQty = 0;
                decimal.TryParse(dr["FNONCONFIRMEDQTY"].ToString().Trim(), out nonConfirmedQty);

                decimal qtyToReduce = (unConfirmedReservedQty > nonConfirmedQty) ? nonConfirmedQty : unConfirmedReservedQty;

                if (qtyToReduce > 0)
                {
                    PreweighDAL.ReduceReservedQtyInPOExtraQtyInfo(db, transaction, siteID, fromPO, fromLineItem, qtyToReduce, currentDate);
                    unConfirmedReservedQty = unConfirmedReservedQty - qtyToReduce;
                }

                if (unConfirmedReservedQty <= 0)
                    break;
            }
        }

        public ProcessOrderBasicList GetPreweighStartedProcessOrders(PagerFilter pagerFilter)
        {
            IDataReader dataReaderPOInfo = null;
            int currentDate = 0;
            int currentTime = 0;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                ProcessOrderBasicList poBasicInfoList = new ProcessOrderBasicList();
                ProcessOrderBasicInfo poBasicInfo;

                string pickKitProcess = PreweighDAL.GetPickKitProcess(db, pagerFilter.SiteID);
                bool includeConfirmPO = false;
                if (Convert.ToChar(pickKitProcess) == Convert.ToChar(PlantPickKitProcess.Picking_Kitting_Seperate))
                {
                    includeConfirmPO = true;                //In pick kit together, confirm means TO confirm in SAP, so can't revert once it is TO confirmed
                }

                Common.GetCurrentSiteDateTime(db, pagerFilter.SiteID, ref currentDate, ref currentTime);
                dataReaderPOInfo = PreweighDAL.GetPreweighStartedProcessOrders(db, pagerFilter.SiteID, includeConfirmPO, currentDate, pagerFilter.PageIndex, pagerFilter.PageSize);

                int index = 0;
                while (dataReaderPOInfo.Read())
                {
                    if (index == 0)
                        poBasicInfoList.TotalCount = Common.GetSafeInt32(dataReaderPOInfo, "FCOUNT");

                    poBasicInfo = new ProcessOrderBasicInfo();
                    poBasicInfo.ProcessOrderNumber = Common.GetSafeString(dataReaderPOInfo, "FAUFNR");
                    poBasicInfo.MaterialNumber = Common.GetSafeString(dataReaderPOInfo, "FMATNR");
                    poBasicInfo.MaterialDescription = Common.GetSafeString(dataReaderPOInfo, "FIDHDESC");
                    poBasicInfo.BatchNumber = Common.GetSafeString(dataReaderPOInfo, "FCHARG");
                    poBasicInfo.Status = Common.GetProcessOrderStatus(Common.GetSafeString(dataReaderPOInfo, "FHDRSTATUS"));
                    poBasicInfoList.ProcesssOrderBasicInfoList.Add(poBasicInfo);
                    index++;
                }

                dataReaderPOInfo.Close();

                return poBasicInfoList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching preweigh started process orders", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                   "UserID: " + pagerFilter.UserID + "; SiteID: " + pagerFilter.SiteID);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPOInfo != null && !dataReaderPOInfo.IsClosed)
                    dataReaderPOInfo.Close();
            }
        }
        #endregion

        #region ConfirmTO
        public List<POBasicHeaderInfo> GetProcessOrderForToConfirmation(ToConfirmFilter filterInfo)
        {
            IDataReader dataReaderProcessOrder = null;
            List<POBasicHeaderInfo> lstPOList = new List<POBasicHeaderInfo>();

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                int currentDate = 0;
                int currentTime = 0;

                string sortField = string.Empty;
                if (filterInfo.SortType != null)
                    sortField = filterInfo.SortType.ToString();

                Common.GetCurrentSiteDateTime(db, filterInfo.SiteID, ref currentDate, ref currentTime);

                dataReaderProcessOrder = PreweighDAL.GetProcessOrderForToConfirmation(db, filterInfo.SiteID, currentDate, filterInfo.UserID, filterInfo.AccessLevelID,
                    filterInfo.PlineID, filterInfo.PageStartIndex, filterInfo.PageSize, sortField, filterInfo.ShowOnlyTONotCompleted);

                while (dataReaderProcessOrder.Read())
                {
                    POBasicHeaderInfo hdrInfo = new POBasicHeaderInfo();
                    hdrInfo.ProcessOrderNumber = Common.GetSafeString(dataReaderProcessOrder, "FAUFNR");
                    hdrInfo.BatchNumber = Common.GetSafeString(dataReaderProcessOrder, "FCHARG");
                    hdrInfo.MaterialNumber = Common.GetSafeString(dataReaderProcessOrder, "FMATNR");
                    hdrInfo.MaterialDescription = Common.GetSafeString(dataReaderProcessOrder, "FIDHDESC");
                    hdrInfo.TotalRecords = Common.GetSafeInt32(dataReaderProcessOrder, "FCOUNT");

                    string hdrStatus = Common.GetSafeString(dataReaderProcessOrder, "FHDRSTATUS");
                    hdrInfo.Status = Common.GetProcessOrderStatus(hdrStatus);

                    lstPOList.Add(hdrInfo);
                }

                dataReaderProcessOrder.Close();

                return lstPOList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Failed to fetch process order list for destock confirm", "iPAS_PreWeighService",
                   System.Reflection.MethodBase.GetCurrentMethod().Name, "UserID: " + filterInfo.UserID + "; SiteID: " + filterInfo.SiteID);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderProcessOrder != null && !dataReaderProcessOrder.IsClosed)
                    dataReaderProcessOrder.Close();
            }
        }

        public TOConfirmInfo GetBomItemForToConfirm(int siteId, string processOrder)
        {
            IDataReader dataReaderBomInfo = null;
            List<TOConfirmItemInfo> toConfirmItemInfo = new List<TOConfirmItemInfo>();
            TOConfirmInfo toConfirmInfo = new TOConfirmInfo();

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderBomInfo = PreweighDAL.GetBomItemForToConfirm(db, processOrder, siteId);

                int i = 0;
                while (dataReaderBomInfo.Read())
                {
                    TOConfirmItemInfo itemInfo = new TOConfirmItemInfo();

                    if (i == 0)
                    {
                        toConfirmInfo.TransferOrderNum = Common.GetSafeString(dataReaderBomInfo, "FTBNUM");
                        toConfirmInfo.ProcessOrder = Common.GetSafeString(dataReaderBomInfo, "FAUFNR");
                    }

                    itemInfo.BatchNum = Common.GetSafeString(dataReaderBomInfo, "FCHARG");
                    itemInfo.BinLocation = Common.GetSafeString(dataReaderBomInfo, "FBINLOCATION");
                    itemInfo.MaterialNum = Common.GetSafeString(dataReaderBomInfo, "FMATNR");
                    itemInfo.PickedQty = Common.GetSafeDecimal(dataReaderBomInfo, "FPICKEDQTY");

                    itemInfo.TransferReqNum = Common.GetSafeString(dataReaderBomInfo, "FTBNUM");
                    itemInfo.TRItemNum = Common.GetSafeString(dataReaderBomInfo, "FTBPOS");

                    itemInfo.TransferOrderNum = Common.GetSafeString(dataReaderBomInfo, "FTANUM");
                    itemInfo.ToItemNum = Common.GetSafeString(dataReaderBomInfo, "FTAPOS");

                    itemInfo.MaterialDesc = Common.GetSafeString(dataReaderBomInfo, "FIDHDESC");
                    itemInfo.UOM = Common.GetSafeString(dataReaderBomInfo, "FUOM");

                    toConfirmItemInfo.Add(itemInfo);
                    i++;
                }

                dataReaderBomInfo.Close();

                toConfirmInfo.TOConfirmItemInfo = toConfirmItemInfo;
                toConfirmInfo.IsTransactionLogExists = true;

                return toConfirmInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching BOM item info for TO confirm", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Orders: " + processOrder + "; SiteID: " + siteId);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderBomInfo != null && !dataReaderBomInfo.IsClosed)
                    dataReaderBomInfo.Close();
            }
        }

        public int ConfirmTO(int siteID, int userID, string processOrder)
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
            return ConfirmTransferOrder(db, siteID, userID, processOrder, false);
        }

        public static int ConfirmTransferOrder(Database db, int siteID, int userID, string processOrder, bool isForPackOff)
        {
            IDataReader dataReaderWarehouseNumber = null;
            string warehouseNumber = string.Empty;
            int createdOn = 0;
            int createdTime = 0;

            try
            {
                string userName = CommonDAL.GetUserName(db, userID);

                dataReaderWarehouseNumber = CommonDAL.GetWarehouseNumber(db, siteID);
                if (dataReaderWarehouseNumber.Read())
                {
                    warehouseNumber = Common.GetSafeString(dataReaderWarehouseNumber, "FWAREHOUSENUMBER");
                }
                dataReaderWarehouseNumber.Close();

                if (warehouseNumber == string.Empty)
                {
                    return 2; //Warehouse number is not configured for the plant. Please contact administrator.                  
                }

                Common.GetCurrentSiteDateTime(db, siteID, ref createdOn, ref createdTime);

                iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);


                DataTable dtTORequiredItems = PreweighDAL.GetTOConfirmRequiredItems(db, siteID, processOrder, isForPackOff);

                char[] charsToTrim = { 'c', '0' };
                string lineItems = string.Empty;
                string currentLineItem = string.Empty;
                string previousLineItem = string.Empty;
                bool cancellationDone = false;

                //Need to re-create TO for each different TR
                DataTable dtDistinctTR = dtTORequiredItems.DefaultView.ToTable(true, "FTBNUM");
                for (int i = 0; i < dtDistinctTR.Rows.Count; i++)
                {
                    iPASRFSAP.ConfirmTransferOrderInfo poHdrInfo = new iPASRFSAP.ConfirmTransferOrderInfo();

                    lineItems = string.Empty;
                    currentLineItem = string.Empty;
                    previousLineItem = string.Empty;

                    for (int row = 0; row < dtTORequiredItems.Rows.Count; row++)
                    {
                        if (dtTORequiredItems.Rows[row]["FTBNUM"].ToString() == dtDistinctTR.Rows[i]["FTBNUM"].ToString())
                        {
                            iPASRFSAP.ConfirmTransferOrderItemInfo itemInfo = new iPASRFSAP.ConfirmTransferOrderItemInfo();

                            currentLineItem = dtTORequiredItems.Rows[row]["FLINEITEM"].ToString();

                            itemInfo.BatchNumber = dtTORequiredItems.Rows[row]["FCHARG"].ToString();
                            itemInfo.SourceBin = dtTORequiredItems.Rows[row]["FBINLOCATION"].ToString();
                            itemInfo.ActualQuantity = Convert.ToDecimal(dtTORequiredItems.Rows[row]["FPICKEDQTY"].ToString());
                            itemInfo.Unit = dtTORequiredItems.Rows[row]["FUOM"].ToString();
                            //itemInfo.TransferOrderNumber = Common.GetSafeString(dataReaderTOInfo, "FTANUM");
                            //itemInfo.TransferOrderItemNumber = Common.GetSafeString(dataReaderTOInfo, "FTAPOS");
                            itemInfo.TransferReqItemNumber = dtTORequiredItems.Rows[row]["FTBPOS"].ToString();
                            itemInfo.RequiredQtyForTR = Convert.ToDecimal(dtTORequiredItems.Rows[row]["FQTY"].ToString());
                            itemInfo.TotalPickedQty = Convert.ToDecimal(dtTORequiredItems.Rows[row]["FTOTALPICKEDQTY"].ToString());
                            itemInfo.SourceStorageType = dtTORequiredItems.Rows[row]["FSTORAGETYPE"].ToString();

                            if (poHdrInfo.TransferRequirementNumber == string.Empty)
                            {
                                poHdrInfo.TransferRequirementNumber = dtTORequiredItems.Rows[row]["FTBNUM"].ToString();
                                poHdrInfo.WareHouseNumber = warehouseNumber;
                            }

                            if (currentLineItem != previousLineItem)
                            {
                                if (lineItems == string.Empty)
                                    lineItems = currentLineItem;
                                else
                                    lineItems = lineItems + "," + currentLineItem;
                            }

                            previousLineItem = currentLineItem;

                            poHdrInfo.ItemInfoList.Add(itemInfo);
                        }
                    }

                    if (dtTORequiredItems.Rows.Count > 0)
                    {
                        //First cancel any TO on any conflict 
                        //For example, Let us say process order X has picked material 171806/batch: 3C02 from RAW H19 (100 KG) & TO has not created for this. 
                        //i.e. SAP has  not reserved any qty for this material against this PO.
                        //But SAP has reserved this material against another PO Y under bin RAW H19 (100 KG). Operator picked this for PO X instead of Y.
                        //when you try to confirm TO for PO X, it will throw Available qty is zero error. As per SAP qty is zero under this bin
                        //Solution is cancel TO that is created for PO Y against this material & then confirm PO X.

                        if (cancellationDone == false)
                        {
                            GetTOCancellationRequiredItems(db, sapBapiClass, warehouseNumber, userName, processOrder);
                            cancellationDone = true;
                        }

                        //One TR => one TO - cancel originally created TO & recreate with actual
                        poHdrInfo.TransferOrderNumber = PreweighDAL.GetFirstCreatedTransferOrderNumber(db, processOrder, lineItems);

                        iPASRFSAP.ConfirmTransferOrderInfo toOutputTable = new iPASRFSAP.ConfirmTransferOrderInfo();
                        string newTRNumber = string.Empty;
                        string errorMessage = sapBapiClass.ReCreateTransferOrderAndConfirmTO(poHdrInfo, userName, ref toOutputTable, ref newTRNumber);

                        if (errorMessage != string.Empty)
                        {
                            if (newTRNumber != string.Empty)
                            {
                                PreweighDAL.UpdateNewTransferOrderNumber(db, processOrder, newTRNumber, lineItems);
                            }
                            throw new Exception(errorMessage);
                        }

                        string newTransferOrderNumber = string.Empty;
                        foreach (iPASRFSAP.ConfirmTransferOrderItemInfo itemInfo in toOutputTable.ItemInfoList)
                        {
                            DataRow[] drSelect = dtTORequiredItems.Select("FTBPOS='" + itemInfo.TransferReqItemNumber + "'");

                            if (drSelect.Length > 0)
                            {
                                PreweighDAL.UpdateStagingTOConfirmedQty(db, processOrder, drSelect[0]["FLINEITEM"].ToString(), itemInfo.BatchNumber
                                    , itemInfo.SourceBin, itemInfo.TransferOrderNumber, itemInfo.TransferOrderItemNumber);

                                PreweighDAL.UpdateItemStatusToStagingConfirmed(db, processOrder, drSelect[0]["FLINEITEM"].ToString(), Convert.ToChar(ProcessOrderItemStatus.Staging_Confirmed));

                                if (newTransferOrderNumber.Length == 0 && (itemInfo.TransferOrderNumber != string.Empty && itemInfo.TransferOrderNumber.Trim().PadLeft(10, '0') != "0000000000"))
                                {
                                    newTransferOrderNumber = itemInfo.TransferOrderNumber;
                                }
                            }
                        }

                        if (newTransferOrderNumber.Length > 0)
                        {
                            CommonDAL.LogProcessTransactionLog(db, processOrder, ProcessTransactionLog.Preweigh_Completed.ToString()
                                , "TO Confirmed for TR ( " + poHdrInfo.TransferRequirementNumber + " ): " + newTransferOrderNumber, userID, createdOn, createdTime);
                        }
                    }
                }

                DataTable dtBinToBinRequiredItems = PreweighDAL.GetBinToBinRequiredItems(db, siteID, processOrder);
                if (dtBinToBinRequiredItems.Rows.Count > 0)
                {
                    List<iPASRFSAP.LabelInfo> labelInfo = new List<iPASRFSAP.LabelInfo>();
                    string lineItemNumbers = string.Empty;
                    for (int row = 0; row < dtBinToBinRequiredItems.Rows.Count; row++)
                    {
                        iPASRFSAP.LabelInfo itemInfo = new iPASRFSAP.LabelInfo();
                        itemInfo.MaterialNumber = dtBinToBinRequiredItems.Rows[row]["FMATNR"].ToString();
                        itemInfo.Plant = dtBinToBinRequiredItems.Rows[row]["FWERKS"].ToString();
                        itemInfo.StorageLocation = dtBinToBinRequiredItems.Rows[row]["FLGORT"].ToString();
                        itemInfo.BatchNumber = dtBinToBinRequiredItems.Rows[row]["FCHARG"].ToString();
                        itemInfo.Quantity = Convert.ToDecimal(dtBinToBinRequiredItems.Rows[row]["FPICKEDQTY"].ToString());
                        itemInfo.Unit = dtBinToBinRequiredItems.Rows[row]["FUOM"].ToString();
                        itemInfo.StorageType = dtBinToBinRequiredItems.Rows[row]["FSTORAGETYPE"].ToString();
                        itemInfo.CurrentBin = dtBinToBinRequiredItems.Rows[row]["FBINLOCATION"].ToString();
                        itemInfo.WareHouseNumber = warehouseNumber;

                        if (dtBinToBinRequiredItems.Rows[row]["FISBATCHMANAGED"].ToString() == "Y")
                            itemInfo.IsBatchManaged = true;

                        if (dtBinToBinRequiredItems.Rows[row]["FMOVIND"].ToString() == "B" || dtBinToBinRequiredItems.Rows[row]["FISADDITION"].ToString() == "Y")
                        {
                            if (dtBinToBinRequiredItems.Rows[row]["FMOVIND"].ToString() == "B")
                            {
                                itemInfo.TargetStorageType = "PSA";
                                itemInfo.BinLocation = "PSA_BULK";
                            }
                            else
                            {
                                itemInfo.TargetStorageType = dtBinToBinRequiredItems.Rows[row]["FSUPPLYAREA"].ToString();
                                itemInfo.BinLocation = dtBinToBinRequiredItems.Rows[row]["FSUPPLYBIN"].ToString();
                            }
                        }
                        else
                        {
                            itemInfo.TargetStorageType = "914";
                            itemInfo.BinLocation = processOrder.Trim().TrimStart(charsToTrim); ;
                        }

                        if (lineItemNumbers == string.Empty)
                            lineItemNumbers = dtBinToBinRequiredItems.Rows[row]["FLINEITEM"].ToString();
                        else
                            lineItemNumbers = lineItemNumbers + "," + dtBinToBinRequiredItems.Rows[row]["FLINEITEM"].ToString();

                        labelInfo.Add(itemInfo);
                    }

                    string transferOrderNumber = string.Empty;
                    transferOrderNumber = sapBapiClass.MassConfirmBinTransfer(labelInfo, userName);

                    PreweighDAL.UpdateBinToBinTOConfirmedQty(db, processOrder, transferOrderNumber, lineItemNumbers);

                    PreweighDAL.UpdateItemStatusToStagingConfirmed(db, processOrder, lineItemNumbers, Convert.ToChar(ProcessOrderItemStatus.Staging_Confirmed));

                    CommonDAL.LogProcessTransactionLog(db, processOrder, ProcessTransactionLog.Preweigh_Completed.ToString()
                            , "TO Confirmed By Bin To Bin Movement: " + transferOrderNumber, userID, createdOn, createdTime);

                    //if (lineItems == string.Empty)
                    //    lineItems = lineItemNumbers;
                    //else
                    //    lineItems = lineItems + "," + lineItemNumbers;
                }

                ////update to confirmed
                //if (lineItems.Length > 0)
                //{
                //    PreweighDAL.UpdateItemStatusToStagingConfirmed(db, processOrder, lineItems, Convert.ToChar(ProcessOrderItemStatus.Staging_Confirmed));
                //}

                if (PreweighDAL.GetToNotConfirmedCount(db, processOrder) == 0)
                {
                    PreweighDAL.MarkPOTOConfirmed(db, processOrder, Convert.ToChar(ProcessOrderStatus.TO_Confirmed));
                }

                return 1;
            }
            catch (Exception ex)
            {
                CommonDAL.LogProcessTransactionLog(db, processOrder, ProcessTransactionLog.Error_In_Preweigh_Complete.ToString()
                           , ex.Message, userID, createdOn, createdTime);

                //Common.LogException(ex, "PreWeighService", "Error while confirming TO", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderWarehouseNumber != null && !dataReaderWarehouseNumber.IsClosed)
                    dataReaderWarehouseNumber.Close();
            }
        }

        private static bool GetTOCancellationRequiredItems(Database db, iPASRFSAP.BAPIClass sapBapiClass, string warehouseNumber, string userName, string processOrder)
        {
            try
            {
                DataTable dtCancellationItems = PreweighDAL.GetTOCancellationRequiredItems(db, processOrder);

                string currentMatBatchBin = string.Empty;
                string prevMatBatchBin = string.Empty;
                decimal cancelledQty = 0;
                decimal pickedQty = 0;

                for (int row = 0; row < dtCancellationItems.Rows.Count; row++)
                {
                    currentMatBatchBin = dtCancellationItems.Rows[row]["FMATNR"].ToString() + "_" + dtCancellationItems.Rows[row]["FCHARG"].ToString() + "_" + dtCancellationItems.Rows[row]["FBINLOCATION"].ToString();

                    if (currentMatBatchBin != prevMatBatchBin)
                    {
                        cancelledQty = 0;
                        pickedQty = Convert.ToDecimal(dtCancellationItems.Rows[row]["FCANCELLATIONQTY"].ToString());
                    }

                    if (pickedQty > cancelledQty)
                    {
                        string transferOrderToBeCancelled = dtCancellationItems.Rows[row]["FTANUM"].ToString();
                        string transferOrderItemToBeCancelled = dtCancellationItems.Rows[row]["FTAPOS"].ToString();
                        decimal toQty = Convert.ToDecimal(dtCancellationItems.Rows[row]["FTOQTY"].ToString());

                        try
                        {
                            if (sapBapiClass.CancelSingleTO(warehouseNumber, transferOrderToBeCancelled, transferOrderItemToBeCancelled, userName))
                            {
                                cancelledQty = cancelledQty + toQty;
                            }
                        }
                        catch
                        {
                        }
                    }

                    prevMatBatchBin = currentMatBatchBin;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool ForcedConfirmTO(int siteID, int userID, string processOrder)
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
            System.Data.Common.DbTransaction transaction;
            int currentDate = 0;
            int currentTime = 0;

            using (System.Data.Common.DbConnection connection = db.CreateConnection())
            {
                connection.Open();
                transaction = connection.BeginTransaction();
                try
                {
                    Common.GetCurrentSiteDateTime(db, siteID, ref currentDate, ref currentTime);

                    DataTable dtTORequiredItems = PreweighDAL.GetTOConfirmRequiredItems(db, siteID, processOrder, false);

                    string lineItems = string.Empty;
                    string currentLineItem = string.Empty;
                    string previousLineItem = string.Empty;

                    for (int row = 0; row < dtTORequiredItems.Rows.Count; row++)
                    {
                        iPASRFSAP.ConfirmTransferOrderItemInfo itemInfo = new iPASRFSAP.ConfirmTransferOrderItemInfo();

                        currentLineItem = dtTORequiredItems.Rows[row]["FLINEITEM"].ToString();

                        if (currentLineItem != previousLineItem)
                        {
                            if (lineItems == string.Empty)
                                lineItems = currentLineItem;
                            else
                                lineItems = lineItems + "," + currentLineItem;
                        }

                        previousLineItem = currentLineItem;
                    }

                    if (lineItems != string.Empty)
                    {
                        PreweighDAL.UpdateForcedStagingComplete(db, transaction, processOrder, lineItems);
                        PreweighDAL.UpdateItemStatusToStagingConfirmed(db, transaction, processOrder, lineItems, Convert.ToChar(ProcessOrderItemStatus.Staging_Confirmed));
                    }
                    PreweighDAL.MarkForcedPOTOConfirmed(db, transaction, processOrder, Convert.ToChar(ProcessOrderStatus.TO_Confirmed));

                    if (dtTORequiredItems.Rows.Count > 0)
                    {
                        CommonDAL.LogProcessTransactionLog(db, transaction, processOrder, ProcessTransactionLog.Preweigh_Completed.ToString(), "Process order is completed, TO Confirmed forcefully", userID, currentDate, currentTime);
                    }

                    transaction.Commit();

                    return true;
                }
                catch (Exception ex)
                {
                    transaction.Rollback();

                    CommonDAL.LogProcessTransactionLog(db, processOrder, ProcessTransactionLog.Error_In_Preweigh_Complete.ToString()
                               , "Error In Force TO confirm: " + ex.Message, userID, currentDate, currentTime);

                    Common.LogException(ex, "PreWeighService", "Error while forced confirming TO", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + siteID);
                    throw new FaultException(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        //NOT USED
        public TOConfirmReportInfo GetTOConfirmReportInfo(int siteID, string processOrder)
        {
            TOConfirmReportInfo toConfirmReportInfo = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                DataTable reportInfoTable = PreweighDAL.GetTOConfirmReportInfo(db, siteID, processOrder);
                if (reportInfoTable.Rows.Count > 0)
                {
                    DataTable distinctLineItemTable = reportInfoTable.DefaultView.ToTable(true, "FLINEITEM");

                    if (distinctLineItemTable.Rows.Count > 0)
                    {
                        toConfirmReportInfo = new TOConfirmReportInfo();
                        List<TOConfirmReportItemInfo> itemInfoList = new List<TOConfirmReportItemInfo>();

                        decimal decimalValue = 0;
                        int integerValue = 0;

                        toConfirmReportInfo.ProcessOrder = reportInfoTable.Rows[0]["FAUFNR"].ToString();
                        toConfirmReportInfo.MaterialNumber = reportInfoTable.Rows[0]["FMATNRPO"].ToString();
                        toConfirmReportInfo.MaterialDescription = reportInfoTable.Rows[0]["FIDHDESCPO"].ToString();
                        toConfirmReportInfo.BatchNumber = reportInfoTable.Rows[0]["FCHARGPO"].ToString();

                        decimal.TryParse(reportInfoTable.Rows[0]["FTOTALQTY"].ToString(), out decimalValue);
                        toConfirmReportInfo.Quantity = decimalValue;

                        toConfirmReportInfo.UOM = reportInfoTable.Rows[0]["FMEINSPO"].ToString();

                        int.TryParse(reportInfoTable.Rows[0]["FPREWEIGHACTSTRDATE"].ToString(), out integerValue);
                        toConfirmReportInfo.ActualStartDate = integerValue;

                        int.TryParse(reportInfoTable.Rows[0]["FPREWEIGHSTARTTIME"].ToString(), out integerValue);
                        toConfirmReportInfo.ActualStartTime = integerValue;

                        int.TryParse(reportInfoTable.Rows[0]["FPREWEIGHACTFINDATE"].ToString(), out integerValue);
                        toConfirmReportInfo.ActualEndDate = integerValue;

                        int.TryParse(reportInfoTable.Rows[0]["FPREWEIGHENDTIME"].ToString(), out integerValue);
                        toConfirmReportInfo.ActualEndTime = integerValue;

                        foreach (DataRow dr in distinctLineItemTable.Rows)
                        {
                            TOConfirmReportItemInfo itemInfo = new TOConfirmReportItemInfo();

                            DataRow[] itemInfoRow = reportInfoTable.Select(" FLINEITEM ='" + dr["FLINEITEM"].ToString().Trim() + "'");

                            if (itemInfoRow.Length > 0)
                            {
                                itemInfo.MaterialNumber = itemInfoRow[0]["FMATNR"].ToString().Trim();
                                itemInfo.MaterialDescription = itemInfoRow[0]["FIDHDESC"].ToString().Trim();

                                decimal.TryParse(itemInfoRow[0]["ITEMQTY"].ToString().Trim(), out decimalValue);
                                itemInfo.ReqQty = decimalValue;

                                decimal.TryParse(itemInfoRow[0]["PREWEIGHQTY"].ToString().Trim(), out decimalValue);
                                itemInfo.PreweighedQty = decimalValue;

                                itemInfo.UOM = itemInfoRow[0]["ITEMUOM"].ToString().Trim();

                                itemInfo.TransferRequirementNum = itemInfoRow[0]["FTBNUM"].ToString().Trim();
                                itemInfo.TransferRequirementItemNum = itemInfoRow[0]["FTBPOS"].ToString().Trim();

                                List<BatchInfo> batchInfoList = new List<BatchInfo>();

                                foreach (DataRow itemRow in itemInfoRow)
                                {
                                    BatchInfo batchInfo = new BatchInfo();
                                    batchInfo.BatchNumber = itemRow["FCHARG"].ToString().Trim();
                                    batchInfo.Bin = itemRow["FBINLOCATION"].ToString().Trim();
                                    batchInfo.TransferOrderNum = itemRow["FTANUM"].ToString().Trim();
                                    batchInfo.TransferOrderItemNum = itemRow["FTAPOS"].ToString().Trim();

                                    decimal.TryParse(itemRow["FPICKEDQTY"].ToString().Trim(), out decimalValue);
                                    batchInfo.QtyPicked = decimalValue;

                                    batchInfo.UOM = itemRow["FUOM"].ToString().Trim();
                                    batchInfo.Pickedby = itemRow["FPICKER"].ToString().Trim();

                                    batchInfoList.Add(batchInfo);
                                }

                                itemInfo.BatchInfo = batchInfoList;
                            }

                            itemInfoList.Add(itemInfo);
                        }

                        toConfirmReportInfo.ReportItemInfoList = itemInfoList;

                    }
                }

                return toConfirmReportInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching TO Confirm Report Info", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Order: " + processOrder + "; SiteID: " + siteID.ToString());
                throw new FaultException(ex.Message);
            }
        }

        #endregion

        #region Handheld_Staging_Pick
        public List<POBasicInfo> GetStagingProcessOrderForToday(POFilterInfo filterInfo)
        {
            IDataReader processOrderDataReader = null;
            List<POBasicInfo> processOrderInfoList = new List<POBasicInfo>();
            POBasicInfo processOrderInfo = null;
            int currentDate = 0;
            int currentTime = 0;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                currentDate = filterInfo.CurrentDate;
                if (filterInfo.CurrentDate == 0)
                {
                    Common.GetCurrentSiteDateTime(db, filterInfo.SiteID, ref currentDate, ref currentTime);
                }

                processOrderDataReader = PreweighDAL.GetStagingProcessOrderForToday(db, filterInfo.SiteID, currentDate, filterInfo.UserID, filterInfo.AccessLevelID, filterInfo.PlineID);

                using (processOrderDataReader)
                {
                    while (processOrderDataReader.Read())
                    {
                        processOrderInfo = new POBasicInfo();

                        processOrderInfo.ProcessOrderNumber = Common.GetSafeString(processOrderDataReader, "FAUFNR");
                        processOrderInfo.MaterialNumber = Common.GetSafeString(processOrderDataReader, "FMATNR");
                        processOrderInfo.MaterialDescription = Common.GetSafeString(processOrderDataReader, "FIDHDESC");
                        processOrderInfo.ScheduledDate = Common.GetSafeInt32(processOrderDataReader, "FSCHDLDATE");

                        processOrderInfo.Status = Common.GetProcessOrderStatus(Common.GetSafeString(processOrderDataReader, "FHDRSTATUS"));

                        processOrderInfoList.Add(processOrderInfo);
                    }

                    processOrderDataReader.Close();
                }

                return processOrderInfoList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching process orders for today", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Site ID: " + filterInfo.SiteID.ToString() + "; User ID: " + filterInfo.UserID.ToString());
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (processOrderDataReader != null && !processOrderDataReader.IsClosed)
                {
                    processOrderDataReader.Close();
                }
            }
        }

        public List<GroupByPOInfo> GetStagingProcessOrderByGroupForToday(POFilterInfo filterInfo)
        {
            IDataReader processOrderDataReader = null;
            List<GroupByPOInfo> processOrderInfoList = new List<GroupByPOInfo>();
            GroupByPOInfo processOrderInfo = null;
            int i = 0;
            int rowCount = 0;
            string currentMaterial = string.Empty;
            string previousMaterial = string.Empty;
            string previousProcessOrder = string.Empty;
            int currentDate = 0;
            int currentTime = 0;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                currentDate = filterInfo.CurrentDate;
                if (filterInfo.CurrentDate == 0)
                {
                    Common.GetCurrentSiteDateTime(db, filterInfo.SiteID, ref currentDate, ref currentTime);
                }

                processOrderDataReader = PreweighDAL.GetStagingProcessOrderByGroupForToday(db, filterInfo.SiteID, currentDate, filterInfo.UserID, filterInfo.AccessLevelID, filterInfo.PlineID);

                using (processOrderDataReader)
                {
                    while (processOrderDataReader.Read())
                    {
                        ProcessOrderStatus hdrStatus = Common.GetProcessOrderStatus(Common.GetSafeString(processOrderDataReader, "FSTATUS"));
                        if (hdrStatus == ProcessOrderStatus.Addition)     //ADDITION; never include them in group
                        {
                            if (i != 0)
                            {
                                processOrderInfo.TotalGroupedPO = rowCount;
                                processOrderInfoList.Add(processOrderInfo);
                            }
                            rowCount = 1;
                            processOrderInfo = new GroupByPOInfo();
                            processOrderInfo.ProcessOrderNumber = Common.GetSafeString(processOrderDataReader, "FAUFNR");
                            processOrderInfo.MaterialNumber = Common.GetSafeString(processOrderDataReader, "FMATNR");
                            processOrderInfo.Status = hdrStatus;
                            processOrderInfo.ScheduledDate = Common.GetSafeInt32(processOrderDataReader, "FSCHDLDATE");
                            processOrderInfo.TotalGroupedPO = 1;
                        }
                        else
                        {
                            currentMaterial = Common.GetSafeString(processOrderDataReader, "FMATNR").ToUpper() + Common.GetSafeString(processOrderDataReader, "FGROUPSTATUS").Trim();
                            if (previousMaterial != currentMaterial)
                            {
                                if (i != 0)
                                {
                                    processOrderInfo.TotalGroupedPO = rowCount;
                                    processOrderInfoList.Add(processOrderInfo);
                                }
                                rowCount = 1;
                                processOrderInfo = new GroupByPOInfo();
                                processOrderInfo.ProcessOrderNumber = Common.GetSafeString(processOrderDataReader, "FAUFNR");
                                processOrderInfo.MaterialNumber = Common.GetSafeString(processOrderDataReader, "FMATNR");
                                processOrderInfo.Status = hdrStatus;
                                processOrderInfo.ScheduledDate = Common.GetSafeInt32(processOrderDataReader, "FSCHDLDATE");
                            }
                            else
                            {
                                if (previousProcessOrder.Trim() != Common.GetSafeString(processOrderDataReader, "FAUFNR"))
                                {
                                    rowCount = rowCount + 1;
                                    processOrderInfo.ProcessOrderNumber = processOrderInfo.ProcessOrderNumber + "\r\n" + Common.GetSafeString(processOrderDataReader, "FAUFNR");
                                }
                                if (hdrStatus != ProcessOrderStatus.Not_Started)
                                {
                                    if (processOrderInfo.Status != ProcessOrderStatus.Staging_InProgress && hdrStatus == ProcessOrderStatus.Staging_InProgress)
                                    {
                                        processOrderInfo.Status = hdrStatus;
                                    }
                                }
                            }
                        }

                        previousMaterial = currentMaterial;
                        previousProcessOrder = Common.GetSafeString(processOrderDataReader, "FAUFNR");

                        i++;
                    }

                    processOrderDataReader.Close();

                    if (processOrderInfo != null)
                    {
                        processOrderInfo.TotalGroupedPO = rowCount;
                        processOrderInfoList.Add(processOrderInfo);
                    }
                }

                return processOrderInfoList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching process orders by group for today", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Site ID: " + filterInfo.SiteID.ToString() + "; User ID: " + filterInfo.UserID.ToString());
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (processOrderDataReader != null && !processOrderDataReader.IsClosed)
                {
                    processOrderDataReader.Close();
                }
            }
        }

        public ProcessOrderStatus ValidateProcessOrderForPicking(string processOrders)
        {
            IDataReader dataReaderPOStatus = null;
            try
            {
                string status = string.Empty;
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderPOStatus = PreweighDAL.ValidateProcessOrderForPicking(db, processOrders);

                string poStatus = string.Empty;

                if (dataReaderPOStatus.Read())
                {
                    status = Common.GetSafeString(dataReaderPOStatus, "FHDRSTATUS");

                    if (poStatus == string.Empty)
                        poStatus = status;

                    if (status == "N")          //if any one of the PO is not started then don't allow to pick it in group
                    {
                        poStatus = status;
                    }

                    if (poStatus != "N" && (status == "W" || status == "I"))
                    {
                        poStatus = status;
                    }
                }

                if (poStatus != "N" && poStatus != "W" && poStatus != "I")
                {
                    poStatus = "E";
                }

                return Common.GetProcessOrderStatus(status);
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while checking process order status", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "Process Orders: " + processOrders);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPOStatus != null && !dataReaderPOStatus.IsClosed)
                    dataReaderPOStatus.Close();
            }
        }

        #endregion

        #region Handheld_Pick_BOM

        public int ValidateProcessOrder(int siteID, string processOrderNumber)
        {
            IDataReader dataReaderProcessOrder = null;

            int returnValue = 0;
            int scheduledDate = 0;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                int currentDate = 0;
                int currentTime = 0;
                ProcessOrderStatus hdrStatus = ProcessOrderStatus.Not_Started;

                Common.GetCurrentSiteDateTime(db, siteID, ref currentDate, ref currentTime);

                dataReaderProcessOrder = PreweighDAL.CheckProcessOrderValid(db, processOrderNumber, siteID);
                if (dataReaderProcessOrder.Read())
                {
                    scheduledDate = Common.GetSafeInt32(dataReaderProcessOrder, "FPREWEIGHSCHDLDATE");
                    hdrStatus = Common.GetProcessOrderStatus(Common.GetSafeString(dataReaderProcessOrder, "FHDRSTATUS"));
                }
                dataReaderProcessOrder.Close();

                if (scheduledDate == 0)
                {
                    returnValue = 1; //not found
                }
                else if (scheduledDate != currentDate)
                {
                    returnValue = 2;
                }
                else if (hdrStatus == ProcessOrderStatus.Not_Started)
                {
                    returnValue = 3;
                }
                else if (hdrStatus == ProcessOrderStatus.Staging_Completed || hdrStatus == ProcessOrderStatus.TO_Confirmed)
                {
                    returnValue = 4;
                }
                else if (hdrStatus != ProcessOrderStatus.Staging_InProgress)
                {
                    returnValue = 5;
                }
                else
                {
                    returnValue = 0;
                }

                return returnValue;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while validating proicess Order", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Order: " + processOrderNumber + "; SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderProcessOrder != null && !dataReaderProcessOrder.IsClosed)
                    dataReaderProcessOrder.Close();
            }
        }

        public ProcessOrderBOMInfo GetProcessOrderBOMInfo(int siteID, int userID, string processOrderNumber)
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
            return FillProcessOrderBOMInfo(db, siteID, userID, processOrderNumber, "BY_PO", 0);
        }

        public ProcessOrderBOMInfo GetProcessOrdersByGroupItems(int siteID, int userID, string processOrderNumber)
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
            return FillProcessOrderBOMInfo(db, siteID, userID, processOrderNumber, "BY_GROUP", 0);
        }



        public BomInfo GetAvailableBinBatchList(AvailableBinFilter filterInfo)
        {
            IDataReader dataReaderWareHouse = null;
            IDataReader dataReaderPendingQty = null;
            List<AvailableBinBatchInfo> availableBinBatchInfoList = new List<AvailableBinBatchInfo>();
            BomInfo bomInfo = null;
            string warehouseNumber = string.Empty;
            decimal requiredQty = 0;
            decimal totalPreweighedQty = 0;
            string bapiMessage = string.Empty;
            DataTable availableBinTable = new DataTable();
            AvailableBinBatchInfo availableBinBatchInfo;
            decimal quantity = 0;
            string plantCode = string.Empty;
            string materialNum = string.Empty;
            string storageLocation = string.Empty;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderPendingQty = PreweighDAL.GetRequiredQtyForStageNumber(db, filterInfo.ProcessOrders, filterInfo.Posnr, filterInfo.Vornr, filterInfo.MaterialNumber, filterInfo.BatchNumber);
                if (dataReaderPendingQty.Read())
                {
                    requiredQty = Common.GetSafeDecimal(dataReaderPendingQty, "FQTY");
                    totalPreweighedQty = Common.GetSafeDecimal(dataReaderPendingQty, "FPICKEDQTY");
                }
                dataReaderPendingQty.Close();

                decimal pendingQty = requiredQty - totalPreweighedQty;
                if (pendingQty <= 0)
                {
                    return bomInfo;           //return NULL - preweigh is completed
                }

                dataReaderWareHouse = CommonDAL.GetWarehouseNumber(db, filterInfo.SiteID);
                if (dataReaderWareHouse.Read())
                {
                    warehouseNumber = Common.GetSafeString(dataReaderWareHouse, "FWAREHOUSENUMBER");
                }
                dataReaderWareHouse.Close();

                if (warehouseNumber.Trim().Length > 0)
                {
                    bomInfo = new BomInfo();

                    DataTable dtBatchlist = PreweighDAL.GetPickBatchBinInfo(db, filterInfo.ProcessOrders, filterInfo.Posnr, filterInfo.Vornr, filterInfo.MaterialNumber, filterInfo.BatchNumber);
                    if (dtBatchlist.Rows.Count > 0)
                    {
                        storageLocation = dtBatchlist.Rows[0]["FLGORT"].ToString();
                        plantCode = dtBatchlist.Rows[0]["FWERKS"].ToString();
                    }

                    //Get pallets that are in staging area. This is required to mark in available list to indicate that they are in staging area
                    DataTable dtStagingPallet = PreweighDAL.GetPalletInStagingArea(db, filterInfo.SiteID, filterInfo.ProcessOrders, filterInfo.MaterialNumber, filterInfo.BatchNumber);
                    DataTable dtNonConfirmedBatchQty = PreweighDAL.GetNonConfirmedMaterialBatchQty(db, filterInfo.MaterialNumber, filterInfo.BatchNumber);


                    iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);


                    bapiMessage = sapBapiClass.GetAvailableBinList(filterInfo.MaterialNumber, plantCode, string.Empty, filterInfo.BatchNumber.Trim(), warehouseNumber
                        , ref availableBinTable);

                    //bin from which material/batch is already picked
                    string expiryDate = string.Empty;
                    for (int iRow = 0; iRow < dtBatchlist.Rows.Count; iRow++)
                    {
                        bool canAdd = false;
                        availableBinBatchInfo = new AvailableBinBatchInfo();

                        availableBinBatchInfo.BatchNum = filterInfo.BatchNumber;
                        availableBinBatchInfo.BinLocation = dtBatchlist.Rows[iRow]["FBINLOCATION"].ToString();
                        decimal.TryParse(dtBatchlist.Rows[iRow]["FPICKEDQTY"].ToString(), out quantity);
                        availableBinBatchInfo.Quantity = quantity;
                        availableBinBatchInfo.UOM = dtBatchlist.Rows[iRow]["FUOM"].ToString().Trim();

                        DataRow[] drPalletFound = dtStagingPallet.Select(" FBINLOCATION ='" + availableBinBatchInfo.BinLocation + "' AND FCHARG ='" + availableBinBatchInfo.BatchNum + "'");
                        if (drPalletFound.Length > 0)
                        {
                            availableBinBatchInfo.IsPalletInStagingArea = true;
                        }

                        if (dtBatchlist.Rows[iRow]["FPICKEDQTY"].ToString() != "0")
                        {
                            availableBinBatchInfo.IsAlreadyPicked = true;
                            canAdd = true;
                        }

                        if (dtBatchlist.Rows[iRow]["FTOQTY"].ToString() != "0")
                        {
                            availableBinBatchInfo.IsSAP_Proposed = true;
                        }

                        if (availableBinTable != null && availableBinTable.Rows.Count > 0)
                        {
                            decimal availQty = 0;
                            DataRow[] drBatchFound = availableBinTable.Select(" BESTQ='' AND LGORT='" + storageLocation.Trim() + "' AND LGPLA ='" + availableBinBatchInfo.BinLocation
                                                                                + "' AND CHARG ='" + availableBinBatchInfo.BatchNum + "'");
                            if (drBatchFound.GetLength(0) > 0)
                            {

                                DataRow[] drFilterRow = dtNonConfirmedBatchQty.Select(" FBINLOCATION ='" + availableBinBatchInfo.BinLocation + "'");
                                decimal nonConfirmedQty = 0;
                                decimal nonConfirmedBinQty = 0;
                                decimal convertedNonConfirmedQty = 0;
                                string nonConfirmedQtyUOM = string.Empty;

                                foreach (DataRow dr in drFilterRow)
                                {
                                    nonConfirmedBinQty = Convert.ToDecimal(dr["FNONCONFIRMEDQTY"].ToString().Trim());
                                    nonConfirmedQtyUOM = dr["FUOM"].ToString().Trim();

                                    if (nonConfirmedQtyUOM.Trim().ToUpper() != availableBinBatchInfo.UOM.ToUpper())
                                        convertedNonConfirmedQty = sapBapiClass.UnitConversion(filterInfo.MaterialNumber, nonConfirmedQtyUOM, availableBinBatchInfo.UOM.ToUpper(), nonConfirmedBinQty);
                                    else
                                        convertedNonConfirmedQty = nonConfirmedBinQty;

                                    nonConfirmedQty = nonConfirmedQty + convertedNonConfirmedQty;
                                }

                                string expDate = drBatchFound[0]["VFDAT"].ToString();
                                expiryDate = expDate.Substring(6);
                                expiryDate = expiryDate + "-" + expDate.Substring(4, 2);
                                expiryDate = expiryDate + "-" + expDate.Substring(0, 4);

                                availableBinBatchInfo.ExpiryDate = expiryDate;

                                foreach (DataRow itemRow in drBatchFound)
                                {
                                    decimal.TryParse(itemRow["GESME"].ToString(), out quantity);
                                    if (itemRow["MEINS"].ToString().Trim().ToUpper() != availableBinBatchInfo.UOM.ToUpper())
                                    {
                                        quantity = sapBapiClass.UnitConversion(filterInfo.MaterialNumber, itemRow["MEINS"].ToString().Trim().ToUpper(), availableBinBatchInfo.UOM.ToUpper(), quantity);
                                    }

                                    availQty = availQty + quantity;
                                    availableBinBatchInfo.Quantity = availQty - nonConfirmedQty;

                                    if (availableBinBatchInfo.Quantity > 0)
                                        canAdd = true;
                                }
                            }
                        }

                        if (canAdd)
                        {
                            availableBinBatchInfoList.Add(availableBinBatchInfo);
                        }
                    }


                    //loop through sap returned bins for the batch
                    if (availableBinTable.Rows.Count > 0 && bapiMessage == string.Empty)
                    {
                        DataRow[] drFilterRow = null;

                        foreach (DataRow dr in availableBinTable.Rows)
                        {
                            if (dr["BESTQ"].ToString() == string.Empty && dr["LGORT"].ToString() == storageLocation.Trim())
                            {
                                drFilterRow = dtBatchlist.Select(" FBINLOCATION ='" + dr["LGPLA"].ToString() + "' AND FCHARG ='" + dr["CHARG"].ToString().Trim() + "'");
                                if (drFilterRow.GetLength(0) > 0)
                                {
                                }
                                else
                                {
                                    availableBinBatchInfo = new AvailableBinBatchInfo();

                                    decimal.TryParse(dr["GESME"].ToString(), out quantity);
                                    availableBinBatchInfo.BatchNum = dr["CHARG"].ToString().Trim();
                                    availableBinBatchInfo.BinLocation = dr["LGPLA"].ToString();

                                    availableBinBatchInfo.Quantity = quantity;
                                    availableBinBatchInfo.UOM = dr["MEINS"].ToString();
                                    availableBinBatchInfo.StorageType = dr["LGTYP"].ToString();

                                    if (dr["VFDAT"].ToString() != string.Empty)
                                    {
                                        string expDate = dr["VFDAT"].ToString();
                                        expiryDate = expDate.Substring(6);
                                        expiryDate = expiryDate + "-" + expDate.Substring(4, 2);
                                        expiryDate = expiryDate + "-" + expDate.Substring(0, 4);

                                        availableBinBatchInfo.ExpiryDate = expiryDate;
                                    }
                                    else
                                    {
                                        availableBinBatchInfo.ExpiryDate = string.Empty;
                                    }


                                    DataRow[] drPalletFound = dtStagingPallet.Select(" FBINLOCATION ='" + availableBinBatchInfo.BinLocation + "' AND FCHARG ='" + availableBinBatchInfo.BatchNum + "'");
                                    if (drPalletFound.Length > 0)
                                    {
                                        availableBinBatchInfo.IsPalletInStagingArea = true;
                                    }

                                    //DataRow[] drBinFound = dtBatchlist.Select(" FTOQTY > 0 AND FBINLOCATION ='" + availableBinBatchInfo.BinLocation + "' AND FCHARG ='" + availableBinBatchInfo.BatchNum + "'");
                                    //if (drBinFound.Length > 0)
                                    //{
                                    //    availableBinBatchInfo.IsSAP_Proposed = true;
                                    //}

                                    DataRow[] drConfirmedQty = dtNonConfirmedBatchQty.Select(" FBINLOCATION ='" + availableBinBatchInfo.BinLocation + "'");

                                    decimal nonConfirmedQty = 0;
                                    decimal nonConfirmedBinQty = 0;
                                    decimal convertedNonConfirmedQty = 0;
                                    string nonConfirmedQtyUOM = string.Empty;

                                    foreach (DataRow row in drConfirmedQty)
                                    {
                                        nonConfirmedBinQty = Convert.ToDecimal(row["FNONCONFIRMEDQTY"].ToString().Trim());
                                        nonConfirmedQtyUOM = row["FUOM"].ToString().Trim();

                                        if (dr["MEINS"].ToString().Trim().ToUpper() != nonConfirmedQtyUOM.Trim().ToUpper())
                                            convertedNonConfirmedQty = sapBapiClass.UnitConversion(filterInfo.MaterialNumber, nonConfirmedQtyUOM, dr["MEINS"].ToString().Trim(), nonConfirmedBinQty);
                                        else
                                            convertedNonConfirmedQty = nonConfirmedBinQty;

                                        nonConfirmedQty = nonConfirmedQty + convertedNonConfirmedQty;
                                    }

                                    availableBinBatchInfo.Quantity = availableBinBatchInfo.Quantity - nonConfirmedQty;

                                    if (availableBinBatchInfo.Quantity > 0)
                                    {
                                        availableBinBatchInfoList.Add(availableBinBatchInfo);
                                    }
                                }
                            }
                        }
                    }

                    bomInfo.BatchBinInfo = availableBinBatchInfoList;
                    bomInfo.QtyPending = pendingQty;

                    return bomInfo;
                }
                else
                {
                    throw new FaultException("Warehouse number not set for the plant.");
                }
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting available bins from SAP", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + filterInfo.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderWareHouse != null && !dataReaderWareHouse.IsClosed)
                    dataReaderWareHouse.Close();

                if (dataReaderPendingQty != null && !dataReaderPendingQty.IsClosed)
                    dataReaderPendingQty.Close();
            }
        }


        public bool ConfirmPreweighPPE(ConfirmPPEInfo ppeInfo)
        {
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                PreweighDAL.ConfirmPreweighPPE(db, ppeInfo.ProcessOrder, ppeInfo.Posnr, ppeInfo.Vornr, ppeInfo.Material, ppeInfo.ConfirmUserID);

                return true;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while confirming PPE", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Orders: " + ppeInfo.ProcessOrder + "; UserID: " + ppeInfo.ConfirmUserID + "; SiteID: " + ppeInfo.SiteID);
                throw new FaultException(ex.Message);
            }
        }

        public PalletInfo GetPalletInfo(int siteID, int userID, string labelNumber)
        {
            IDataReader dataReaderPallet = null;
            PalletInfo palletInfo = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderPallet = PreweighDAL.GetLabelInfo(db, siteID, labelNumber);

                if (dataReaderPallet.Read())
                {
                    palletInfo = new PalletInfo();
                    palletInfo.BatchNumber = Common.GetSafeString(dataReaderPallet, "FBATCHNUM");
                    palletInfo.MaterialNumber = Common.GetSafeString(dataReaderPallet, "FMATERIALNUM");
                    palletInfo.LabelNumber = Common.GetSafeString(dataReaderPallet, "FLABELNUM");
                    palletInfo.Bin = Common.GetSafeString(dataReaderPallet, "FCURRENTBIN");
                    palletInfo.CanNeglectBatch = Common.GetSafeString(dataReaderPallet, "FCANNEGLECTBATCH") == "Y" ? true : false;
                }
                dataReaderPallet.Close();

                return palletInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching label info", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Label Number: " + labelNumber + "; UserID: " + userID + "; SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPallet != null && !dataReaderPallet.IsClosed)
                    dataReaderPallet.Close();
            }
        }

        public AvailableBinBatchInfo GetBinLocationQuantity(int siteID, string materialNumber, string plant, string batchNumber, string binLocation, string unit)
        {
            AvailableBinBatchInfo batchInfo = null;
            PlantSettings plantSetting = new PlantSettings();
            IDataReader dataReaderNonConfirmed = null;
            decimal nonConfirmedQty = 0;
            DataTable availableBinTable = new DataTable();
            decimal quantity = 0;
            decimal convertedQunatity = 0;
            decimal qtyAvailable = 0;
            string storageType = string.Empty;
            string binQtyUnit = string.Empty;
            string matchBatchNumber = batchNumber;


            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                plantSetting = Common.GetPlantSettings(db, siteID);

                if (plantSetting.SapAvailabilityStatus == SAPStatus.Down)
                {
                    batchInfo = new AvailableBinBatchInfo();
                    batchInfo.BatchNum = batchNumber;
                    batchInfo.BinLocation = binLocation;
                    batchInfo.Quantity = qtyAvailable;
                    batchInfo.StorageType = storageType;
                    batchInfo.UOM = unit;
                }

                iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

                string returnMessage = sapBapiClass.GetAvailableBinList(materialNumber, plant, binLocation, batchNumber, plantSetting.WarehouseNumber, ref availableBinTable);

                if (returnMessage == string.Empty && availableBinTable.Rows.Count > 0)
                {
                    foreach (DataRow dr in availableBinTable.Rows)
                    {
                        if (batchNumber == string.Empty)
                        {
                            matchBatchNumber = dr["CHARG"].ToString().ToUpper();
                        }

                        if (dr["BESTQ"].ToString() == string.Empty && plant == dr["WERKS"].ToString() && dr["LGPLA"].ToString() == binLocation.Trim().ToUpper() && dr["CHARG"].ToString().ToUpper() == matchBatchNumber.Trim().ToUpper() && dr["MATNR"].ToString().Trim().PadLeft(18, '0') == materialNumber.Trim().PadLeft(18, '0'))
                        {
                            decimal.TryParse(dr["GESME"].ToString(), out quantity); //VERME IS REPLACED WITH GESME. AS TO IS ALREADY DONE, VERME WILL BE ZERO, IF GESME IS ASSIGNED to TO
                            binQtyUnit = dr["MEINS"].ToString().Trim();

                            if (unit.Trim().Length > 0 && unit.Trim().ToUpper() != binQtyUnit.Trim().ToUpper())
                                convertedQunatity = sapBapiClass.UnitConversion(materialNumber, binQtyUnit, unit, quantity);
                            else
                                convertedQunatity = quantity;

                            qtyAvailable = qtyAvailable + convertedQunatity;
                            storageType = dr["LGTYP"].ToString();
                        }
                    }
                }

                if (plantSetting.BatchDeterminationLogic == PlantBatchLogic.TRBased)
                {
                    decimal nonConfirmedBinQty = 0;
                    decimal convertedNonConfirmedBinQty = 0;
                    string nonConfirmedBinQtyUOM = string.Empty;

                    dataReaderNonConfirmed = PreweighDAL.GetNonConfirmedBinBatchQty(db, materialNumber, batchNumber, binLocation);
                    while (dataReaderNonConfirmed.Read())
                    {
                        nonConfirmedBinQty = Common.GetSafeDecimal(dataReaderNonConfirmed, "FNONCONFIRMEDQTY");
                        nonConfirmedBinQtyUOM = Common.GetSafeString(dataReaderNonConfirmed, "FUOM");

                        if (unit.Trim().ToUpper() != nonConfirmedBinQtyUOM.Trim().ToUpper())
                            convertedNonConfirmedBinQty = sapBapiClass.UnitConversion(materialNumber, nonConfirmedBinQtyUOM, unit, nonConfirmedBinQty);
                        else
                            convertedNonConfirmedBinQty = nonConfirmedBinQty;

                        nonConfirmedQty = nonConfirmedQty + convertedNonConfirmedBinQty;
                    }
                    dataReaderNonConfirmed.Close();

                    qtyAvailable = qtyAvailable - nonConfirmedQty;
                }

                if (qtyAvailable > 0)
                {
                    batchInfo = new AvailableBinBatchInfo();
                    batchInfo.BatchNum = batchNumber;
                    batchInfo.BinLocation = binLocation;
                    batchInfo.Quantity = qtyAvailable;
                    batchInfo.StorageType = storageType;
                    batchInfo.UOM = unit;
                }

                return batchInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting bin qty from SAP", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {

                if (dataReaderNonConfirmed != null && !dataReaderNonConfirmed.IsClosed)
                    dataReaderNonConfirmed.Close();
            }
        }

        public List<BomInfoBygroup> GetRequiredQtyToBePickedForBom(PickInfo pickInfo)
        {
            IDataReader dataReaderPOInfo = null;
            List<BomInfoBygroup> bomInfoByGroupList = new List<BomInfoBygroup>();
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderPOInfo = PreweighDAL.GetRequiredQtyToBePickedForBom(db, pickInfo.ProcessOrder, pickInfo.Posnr, pickInfo.Vornr, pickInfo.MaterialNumber, pickInfo.BatchNumber);

                int i = 0;
                while (dataReaderPOInfo.Read())
                {
                    if (i == 0)
                    {
                        bomInfoByGroupList = new List<BomInfoBygroup>();
                    }

                    BomInfoBygroup bomInfoByGroup = new BomInfoBygroup();

                    bomInfoByGroup.ProcessOrder = Common.GetSafeString(dataReaderPOInfo, "FAUFNR");
                    bomInfoByGroup.Uom = Common.GetSafeString(dataReaderPOInfo, "FUOM");

                    decimal requiredQty = Common.GetSafeDecimal(dataReaderPOInfo, "FQTY");
                    decimal qtyPreweighed = Common.GetSafeDecimal(dataReaderPOInfo, "FPICKEDQTY");

                    decimal pendingQtyTobePicked = requiredQty - qtyPreweighed;

                    bomInfoByGroup.RequiredQty = requiredQty;
                    if (pendingQtyTobePicked <= 0)
                        bomInfoByGroup.QtyToBePicked = 0;
                    else
                        bomInfoByGroup.QtyToBePicked = pendingQtyTobePicked;

                    bomInfoByGroupList.Add(bomInfoByGroup);
                    i++;
                }

                dataReaderPOInfo.Close();
                return bomInfoByGroupList;

            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching required qty to be picked for BOM", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, string.Empty);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPOInfo != null && !dataReaderPOInfo.IsClosed)
                    dataReaderPOInfo.Close();
            }
        }

        public decimal GetMatchingBomInfoForProcessOrder(PickInfo pickInfo)
        {
            IDataReader dataReaderQty = null;
            decimal requiredQty = 0;
            decimal totalPreweighedQty = 0;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderQty = PreweighDAL.GetMatchingBomInfoForProcessOrder(db, pickInfo.ProcessOrder, pickInfo.Posnr, pickInfo.Vornr, pickInfo.MaterialNumber, pickInfo.BatchNumber);

                if (dataReaderQty.Read())
                {
                    requiredQty = Common.GetSafeDecimal(dataReaderQty, "FQTY");
                    totalPreweighedQty = Common.GetSafeDecimal(dataReaderQty, "FPICKEDQTY");
                }

                dataReaderQty.Close();

                return (requiredQty - totalPreweighedQty);
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching label info", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, string.Empty);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderQty != null && !dataReaderQty.IsClosed)
                    dataReaderQty.Close();
            }
        }

        public bool DoPreweigh(PreweighInfo preweighInfo)
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
            System.Data.Common.DbTransaction transaction;
            using (System.Data.Common.DbConnection connection = db.CreateConnection())
            {
                connection.Open();
                transaction = connection.BeginTransaction();
                try
                {
                    DoPreweighProcess(db, transaction, preweighInfo);
                    transaction.Commit();

                    return true;
                }
                catch (Exception ex)
                {
                    Common.LogException(ex, "PreWeighService", "Error while doing preweigh update", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Label Number: " + preweighInfo.LabelNumber + "; UserID: " + preweighInfo.Picker + "; SiteID: " + preweighInfo.SiteID);
                    transaction.Rollback();
                    throw new FaultException(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

        public bool DoMassPreweigh(List<PreweighInfo> preweighInfo)
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
            System.Data.Common.DbTransaction transaction;

            for (int i = 0; i < preweighInfo.Count; i++)
            {
                using (System.Data.Common.DbConnection connection = db.CreateConnection())
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();
                    try
                    {
                        DoPreweighProcess(db, transaction, preweighInfo[i]);
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        Common.LogException(ex, "PreWeighService", "Error while doing preweigh update", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Label Number: " + preweighInfo[i].LabelNumber + "; UserID: " + preweighInfo[i].Picker + "; SiteID: " + preweighInfo[i].SiteID);
                        transaction.Rollback();
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            return true;
        }

        private bool DoPreweighProcess(Database db, DbTransaction transaction, PreweighInfo preweighInfo)
        {
            IDataReader dataReaderPOLineInfo = null;
            IDataReader dataReaderStagingInfo = null;
            IDataReader dataReaderCompleteCheck = null;
            IDataReader dataReaderCheckPalletInStaging = null;

            decimal totalReqQty = 0;
            decimal totalPreweighedQty = 0;
            int lineItemNumber = 0;
            ProcessOrderItemStatus itemStatus = ProcessOrderItemStatus.Not_Started;
            bool isExistStageInfo = false;
            string uom = string.Empty;
            bool isComplete = true;
            string toLineItem = string.Empty;

            try
            {
                int currentdate = 0;
                int currentTime = 0;

                Common.GetCurrentSiteDateTime(db, preweighInfo.SiteID, ref currentdate, ref currentTime);

                MoveConsignmentStockToOwnStock(db, currentdate, preweighInfo);

                if (preweighInfo.ReAssignBatch != string.Empty && preweighInfo.ReAssignBatch != preweighInfo.BatchNumber)
                {
                    //If it is reassigned to another batch then make sure that new batch exists in the item info
                    int lineItemNumberForMaterial = PreweighDAL.GetLineItemForMaterial(db, transaction, preweighInfo.ProcessOrder, preweighInfo.Posnr, preweighInfo.Vornr, preweighInfo.MaterialNumber);
                    if (!PreweighDAL.CheckBatchExistsInPOItemInfo(db, transaction, preweighInfo.ProcessOrder, preweighInfo.Posnr, preweighInfo.Vornr, preweighInfo.MaterialNumber, preweighInfo.BatchNumber))
                    {
                        PreweighDAL.InsertPOItemBatchInfo(db, transaction, preweighInfo.ProcessOrder, lineItemNumberForMaterial, preweighInfo.MaterialNumber, preweighInfo.BatchNumber, preweighInfo.PreweighedQty, preweighInfo.Uom);
                    }
                    else
                    {
                        PreweighDAL.UpdatePOItemBatchInfo(db, transaction, preweighInfo.ProcessOrder, lineItemNumberForMaterial, preweighInfo.MaterialNumber, preweighInfo.BatchNumber, preweighInfo.PreweighedQty);
                    }

                    PreweighDAL.ReduceReAssignPOItemBatchQty(db, transaction, preweighInfo.ProcessOrder, lineItemNumberForMaterial, preweighInfo.MaterialNumber, preweighInfo.ReAssignBatch, preweighInfo.PreweighedQty);
                    PreweighDAL.DeletePOItemOnFullReAssign(db, transaction, preweighInfo.ProcessOrder, lineItemNumberForMaterial, preweighInfo.MaterialNumber, preweighInfo.ReAssignBatch);
                    PreweighDAL.UpdateReAssignedBatchStatus(db, transaction, preweighInfo.ProcessOrder, lineItemNumberForMaterial, preweighInfo.MaterialNumber, preweighInfo.ReAssignBatch, Convert.ToChar(ProcessOrderItemStatus.Staging_Completed));
                }

                dataReaderPOLineInfo = PreweighDAL.GetProcessOrderLineItemInfo(db, transaction, preweighInfo.ProcessOrder, preweighInfo.Posnr, preweighInfo.Vornr, preweighInfo.MaterialNumber, preweighInfo.BatchNumber);

                if (dataReaderPOLineInfo.Read())
                {
                    totalReqQty = Common.GetSafeDecimal(dataReaderPOLineInfo, "FQTY");
                    totalPreweighedQty = Common.GetSafeDecimal(dataReaderPOLineInfo, "FPICKEDQTY");
                    lineItemNumber = Common.GetSafeInt32(dataReaderPOLineInfo, "FLINEITEM");
                    uom = Common.GetSafeString(dataReaderPOLineInfo, "FUOM");
                }
                dataReaderPOLineInfo.Close();

                if (totalReqQty > 0)
                {
                    if ((preweighInfo.PreweighedQty + totalPreweighedQty) >= totalReqQty)
                        itemStatus = ProcessOrderItemStatus.Staging_Completed;
                    else
                        itemStatus = ProcessOrderItemStatus.Staging_InProgress;

                    PreweighDAL.UpdateItemStatus(db, transaction, preweighInfo.ProcessOrder, lineItemNumber, preweighInfo.BatchNumber, Convert.ToChar(itemStatus));

                    dataReaderStagingInfo = PreweighDAL.CheckStagingInfoExists(db, transaction, preweighInfo.ProcessOrder, preweighInfo.MaterialNumber, preweighInfo.BatchNumber
                        , preweighInfo.Bin, lineItemNumber);

                    if (dataReaderStagingInfo.Read())
                    {
                        isExistStageInfo = true;
                        toLineItem = Common.GetSafeString(dataReaderStagingInfo, "FTAPOS");
                    }
                    dataReaderStagingInfo.Close();

                    if (isExistStageInfo == true)
                    {
                        PreweighDAL.UpdateStagingInfo(db, transaction, preweighInfo.ProcessOrder, preweighInfo.MaterialNumber
                            , preweighInfo.BatchNumber, preweighInfo.Bin, lineItemNumber, preweighInfo.Picker, preweighInfo.PreweighedQty, preweighInfo.StorageType, toLineItem);
                    }
                    else
                    {
                        PreweighDAL.InsertStagingInfo(db, transaction, preweighInfo.ProcessOrder, lineItemNumber, preweighInfo.MaterialNumber
                            , preweighInfo.BatchNumber, preweighInfo.Bin, preweighInfo.PreweighedQty, uom, preweighInfo.Picker, preweighInfo.StorageType);
                    }

                    CommonDAL.LogProcessTransactionLog(db, transaction, preweighInfo.ProcessOrder, ProcessTransactionLog.Pallet_Picked.ToString()
                       , "Pallet Picked For Material ( " + lineItemNumber + " ): " + preweighInfo.MaterialNumber + ", Batch: " + preweighInfo.BatchNumber + ", Bin: " + preweighInfo.Bin + ": " + preweighInfo.LabelNumber + ", Qty: " + preweighInfo.PreweighedQty.ToString()
                        , preweighInfo.Picker, currentdate, currentTime);

                    //Keep the pallet in staging area. check pallet already in LDB1_STAGINGPALLET table?
                    dataReaderCheckPalletInStaging = PreweighDAL.CheckStagingPalletInfoExists(db, transaction, preweighInfo.SiteID, preweighInfo.LabelNumber);
                    isExistStageInfo = false;
                    if (dataReaderCheckPalletInStaging.Read())
                    {
                        isExistStageInfo = true;
                    }
                    dataReaderCheckPalletInStaging.Close();

                    if (isExistStageInfo == false)
                    {
                        PreweighDAL.InsertStagingPallet(db, transaction, preweighInfo.SiteID, preweighInfo.LabelNumber, preweighInfo.MaterialNumber, preweighInfo.BatchNumber, preweighInfo.Bin, 0, currentdate);
                    }
                    else
                    {
                        PreweighDAL.UpdateStagingPalletBinLocation(db, transaction, preweighInfo.SiteID, preweighInfo.LabelNumber, preweighInfo.Bin);
                    }

                    //UPDATE STAGED QTY
                    dataReaderCheckPalletInStaging = PreweighDAL.CheckStagedMaterialExists(db, transaction, preweighInfo.SiteID, preweighInfo.MaterialNumber, preweighInfo.BatchNumber);
                    isExistStageInfo = false;
                    if (dataReaderCheckPalletInStaging.Read())
                    {
                        isExistStageInfo = true;
                    }
                    dataReaderCheckPalletInStaging.Close();

                    if (isExistStageInfo == false)
                    {
                        PreweighDAL.InsertStagedMaterial(db, transaction, preweighInfo.SiteID, preweighInfo.MaterialNumber, preweighInfo.BatchNumber, preweighInfo.PreweighedQty, currentdate);
                    }
                    else
                    {
                        PreweighDAL.UpdateStagedMaterialQty(db, transaction, preweighInfo.SiteID, preweighInfo.MaterialNumber, preweighInfo.BatchNumber, preweighInfo.PreweighedQty);
                    }
                }

                dataReaderCompleteCheck = PreweighDAL.GetNotPreweighedBOM(db, transaction, preweighInfo.SiteID, preweighInfo.ProcessOrder);
                if (dataReaderCompleteCheck.Read())
                {
                    isComplete = false;
                }
                dataReaderCompleteCheck.Close();

                //Mark process order header status as complete if pre-weigh is completed for all BOM
                if (isComplete)
                {
                    //Pre-weigh completed
                    /* If header status is 'P' then update header status  to pre-weigh complete 'C'.
                     * condition added for preweigh done in manufacture */

                    PreweighDAL.MarkPOPreweighComplete(db, transaction, preweighInfo.ProcessOrder, Convert.ToChar(ProcessOrderStatus.Staging_Completed), currentdate, currentTime);

                    CommonDAL.LogProcessTransactionLog(db, transaction, preweighInfo.ProcessOrder, ProcessTransactionLog.Preweigh_Completed.ToString()
                        , "Preweigh completed for process order", preweighInfo.Picker, currentdate, currentTime);

                }
                return true;
            }
            catch
            {
                throw;
            }
            finally
            {
                if (dataReaderPOLineInfo != null && !dataReaderPOLineInfo.IsClosed)
                    dataReaderPOLineInfo.Close();

                if (dataReaderStagingInfo != null && !dataReaderStagingInfo.IsClosed)
                    dataReaderStagingInfo.Close();

                if (dataReaderCheckPalletInStaging != null && !dataReaderCheckPalletInStaging.IsClosed)
                    dataReaderCheckPalletInStaging.Close();

                if (dataReaderCompleteCheck != null && !dataReaderCompleteCheck.IsClosed)
                    dataReaderCompleteCheck.Close();
            }
        }

        public bool MovePalletFromStagingArea(int siteID, PickInfo palletInfo, string labelNumber)
        {
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                return PreweighDAL.MovePalletFromStagingArea(db, siteID, labelNumber);
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while moving pallet to staging area", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Material Number: " + palletInfo.MaterialNumber + "; Batch: " + palletInfo.BatchNumber + "; Bin Location: " + palletInfo.Bin);
                throw new FaultException(ex.Message);
            }
        }

        public PreweighValidateQty ValidatePreweighedQty(PickInfo pickInfo)
        {
            IDataReader dataReaderPOLineInfo = null;
            decimal totalReqQty = 0;
            decimal totalPreweighedQty = 0;
            PreweighValidateQty validateInfo = new PreweighValidateQty();
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                dataReaderPOLineInfo = PreweighDAL.GetProcessOrderLineItemInfo(db, pickInfo.ProcessOrder, pickInfo.Posnr, pickInfo.Vornr, pickInfo.MaterialNumber, pickInfo.BatchNumber);

                if (dataReaderPOLineInfo.Read())
                {
                    totalReqQty = Common.GetSafeDecimal(dataReaderPOLineInfo, "FQTY");
                    totalPreweighedQty = Common.GetSafeDecimal(dataReaderPOLineInfo, "FPICKEDQTY");
                }

                dataReaderPOLineInfo.Close();

                validateInfo.TotalPreweighedQty = totalPreweighedQty;
                validateInfo.QtyMaxDifference = Convert.ToDecimal(ConfigurationManager.AppSettings["QtyMaxLimit"].ToString());
                validateInfo.ToleranceLevel = Convert.ToDecimal(ConfigurationManager.AppSettings["QtyToleranceLevel"].ToString());
                validateInfo.RequiredQty = totalReqQty;

                validateInfo.NonConfirmedQty = 0;           //COMMENTED BECAUSE THIS IS AVAILABLE QTY IN THE BIN IS ALREADY 
                //dataReaderPOLineInfo = PreweighDAL.GetNonConfirmedBinBatchQty(db, pickInfo.MaterialNumber, pickInfo.BatchNumber, pickInfo.Bin);
                //if (dataReaderPOLineInfo.Read())
                //{
                //    validateInfo.NonConfirmedQty = Common.GetSafeDecimal(dataReaderPOLineInfo, "FNONCONFIRMEDQTY");
                //}
                //dataReaderPOLineInfo.Close();


                return validateInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while validating qty", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "PRocess ORder: " + pickInfo.ProcessOrder);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPOLineInfo != null && !dataReaderPOLineInfo.IsClosed)
                    dataReaderPOLineInfo.Close();
            }
        }

        public List<AvailableBinBatchInfo> GetReAssignBatchList(ReAssignParam reassignParam)
        {
            PlantSettings plantSetting = new PlantSettings();
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                plantSetting = Common.GetPlantSettings(db, reassignParam.SiteID);

                if (plantSetting.WarehouseNumber.Trim().Length > 0)
                {

                    string bapiMessage = string.Empty;
                    DataTable availableBinTable = new DataTable();

                    List<AvailableBinBatchInfo> availableBinBatchInfoList = new List<AvailableBinBatchInfo>();
                    AvailableBinBatchInfo availableBinBatchInfo;
                    decimal quantity = 0;

                    iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

                    bapiMessage = sapBapiClass.GetAvailableBinList(reassignParam.MaterialNumber, reassignParam.Plant, string.Empty, string.Empty, plantSetting.WarehouseNumber, ref availableBinTable);

                    if (availableBinTable.Rows.Count > 0)
                    {
                        //sort available bin batch table by expiry date
                        DataView availabeBinView = availableBinTable.DefaultView;
                        availabeBinView.Sort = "VFDAT ASC";
                        DataTable sortedBinTable = availabeBinView.ToTable();

                        foreach (DataRow dr in sortedBinTable.Rows)
                        {

                            decimal nonConfirmedQty = GetMaterialBatchBinNonConfirmedQty(sapBapiClass, db, reassignParam.MaterialNumber, dr["CHARG"].ToString(), dr["LGPLA"].ToString(), dr["MEINS"].ToString());
                            if (dr["BESTQ"].ToString() == string.Empty && dr["LGORT"].ToString() == reassignParam.StorageLocation)
                            {
                                availableBinBatchInfo = availableBinBatchInfoList.FirstOrDefault(binBatch => binBatch.BatchNum == dr["CHARG"].ToString()
                                                                             && binBatch.BinLocation == dr["LGPLA"].ToString()
                                                                             && binBatch.StorageType == dr["LGTYP"].ToString());

                                if (availableBinBatchInfo == null)
                                {
                                    availableBinBatchInfo = new AvailableBinBatchInfo();

                                    availableBinBatchInfo.BinLocation = dr["LGPLA"].ToString();
                                    availableBinBatchInfo.BatchNum = dr["CHARG"].ToString();
                                    decimal.TryParse(dr["GESME"].ToString(), out quantity);
                                    if (quantity > 0)
                                    {
                                        availableBinBatchInfo.Quantity = quantity - nonConfirmedQty;
                                        availableBinBatchInfo.UOM = dr["MEINS"].ToString();
                                        availableBinBatchInfo.StorageType = dr["LGTYP"].ToString();

                                        if (availableBinBatchInfo.Quantity > 0)
                                        {
                                            availableBinBatchInfoList.Add(availableBinBatchInfo);
                                        }
                                    }
                                }
                                else
                                {
                                    decimal.TryParse(dr["GESME"].ToString(), out quantity);
                                    if (quantity > 0)
                                    {
                                        availableBinBatchInfo.Quantity = availableBinBatchInfo.Quantity + quantity;
                                    }
                                }
                            }
                        }

                    }

                    return availableBinBatchInfoList;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting available bins from SAP", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + reassignParam.SiteID);
                throw new FaultException(ex.Message);
            }

        }


        public List<AvailableBinBatchInfo> GetStagedMaterialBatchInfo(int siteID, int userID, string materialNumber)
        {
            IDataReader dataReaderStagedMaterial = null;
            List<AvailableBinBatchInfo> availableBinBatchInfoList = new List<AvailableBinBatchInfo>();
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderStagedMaterial = PreweighDAL.GetStagedMaterialBatchInfo(db, siteID, materialNumber);

                while (dataReaderStagedMaterial.Read())
                {
                    AvailableBinBatchInfo availableBinBatchInfo = new AvailableBinBatchInfo();

                    availableBinBatchInfo.BatchNum = Common.GetSafeString(dataReaderStagedMaterial, "FCHARG");
                    availableBinBatchInfo.Quantity = Common.GetSafeDecimal(dataReaderStagedMaterial, "FCONSUMEDQTY");

                    availableBinBatchInfoList.Add(availableBinBatchInfo);
                }

                dataReaderStagedMaterial.Close();

                return availableBinBatchInfoList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting available batches from staging table", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderStagedMaterial != null && !dataReaderStagedMaterial.IsClosed)
                    dataReaderStagedMaterial.Close();
            }

        }

        public List<AvailableBinBatchInfo> GetBatchInPSALocation(MaterialBatchInfo materialBatchInfo)
        {
            IDataReader dataReaderShelfLife = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                PlantSettings plantSetting = Common.GetPlantSettings(db, materialBatchInfo.SiteID);

                OrderPLineSettings plineSetting = Common.GetProductionLineSettings(db, materialBatchInfo.SiteID, materialBatchInfo.ProcessOrder);

                if (plantSetting.WarehouseNumber.Trim().Length > 0)
                {

                    string bapiMessage = string.Empty;
                    DataTable availableBinTable = new DataTable();

                    List<AvailableBinBatchInfo> availableBinBatchInfoList = new List<AvailableBinBatchInfo>();
                    AvailableBinBatchInfo availableBinBatchInfo;
                    decimal quantity = 0;

                    dataReaderShelfLife = StagingDAL.GetMaterialShelfLifeAndMovementIndicator(db, materialBatchInfo.MaterialNumber, materialBatchInfo.SiteID);
                    string movIND = string.Empty;
                    if (dataReaderShelfLife.Read())
                    {
                        movIND = Common.GetSafeString(dataReaderShelfLife, "FMOVIND");
                    }
                    dataReaderShelfLife.Close();

                    string supplyBin = plineSetting.SupplyBin;
                    string supplyArea = plineSetting.SupplyArea;
                    if (movIND == "B")
                    {
                        supplyBin = plineSetting.SupplyBulkBin;
                        supplyArea = plineSetting.SupplyBulkArea;
                    }

                    iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

                    bapiMessage = sapBapiClass.GetAvailableBinList(materialBatchInfo.MaterialNumber, materialBatchInfo.PlantCode
                        , plineSetting.SupplyBin, string.Empty, plantSetting.WarehouseNumber, ref availableBinTable);

                    if (availableBinTable.Rows.Count > 0)
                    {
                        foreach (DataRow dr in availableBinTable.Rows)
                        {
                            if (dr["BESTQ"].ToString() == string.Empty && dr["LGPLA"].ToString().Trim().ToUpper() == supplyBin.Trim().ToUpper() && dr["LGTYP"].ToString().Trim().ToUpper() == supplyArea.Trim().ToUpper())
                            {
                                availableBinBatchInfo = new AvailableBinBatchInfo();

                                availableBinBatchInfo.BinLocation = dr["LGPLA"].ToString();
                                availableBinBatchInfo.BatchNum = dr["CHARG"].ToString();
                                decimal.TryParse(dr["GESME"].ToString(), out quantity);
                                availableBinBatchInfo.Quantity = quantity;
                                availableBinBatchInfo.UOM = dr["MEINS"].ToString();
                                availableBinBatchInfo.StorageType = dr["LGTYP"].ToString();

                                availableBinBatchInfoList.Add(availableBinBatchInfo);
                            }
                        }
                    }

                    return availableBinBatchInfoList;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "ManufactureService", "Error while getting available batch in supply bins from SAP", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + materialBatchInfo.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderShelfLife != null && !dataReaderShelfLife.IsClosed)
                    dataReaderShelfLife.Close();
            }

        }

        private List<PPEDataInfo> GetMaterialPPECode(Database db, int siteID, string ppeCode1, string ppeCode2, string ppeCode3)
        {
            IDataReader ppeDataReader = null;
            try
            {
                List<PPEDataInfo> ppeList = new List<PPEDataInfo>();
                int ppeCount = 1;
                using (ppeDataReader = CommonDAL.GetMaterialPPECode(db, siteID, ppeCode1, ppeCode2, ppeCode3))
                {
                    while (ppeDataReader.Read())
                    {
                        PPEDataInfo ppeInfo = new PPEDataInfo();
                        ppeInfo.ImageName = Common.GetSafeString(ppeDataReader, "FPPEIMAGENAME");
                        ppeInfo.PPEDesc = Common.GetSafeString(ppeDataReader, "FPPEDESC");
                        ppeInfo.PPEID = Common.GetSafeInt32(ppeDataReader, "FPPEID");

                        string imageUrl = System.Configuration.ConfigurationManager.AppSettings["PPEImageDownloadPath"].ToString().TrimEnd('/') + "/" + siteID.ToString() + "/PPE/" + ppeInfo.PPEID.ToString().Trim() + "/Thumbnail/" + ppeInfo.ImageName.Trim();
                        ppeInfo.Image = Common.GetImageBytes(imageUrl);
                        if (ppeInfo.Image != null)
                        {
                            ppeList.Add(ppeInfo);
                            ppeCount++;
                            if (ppeCount > 4)
                                break;
                        }
                    }
                    ppeDataReader.Close();
                }

                return ppeList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Error while fecthing ppe", "iPAS_PreweighService"
                                    , System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + siteID + "; PPE: " + ppeCode1 + "," + ppeCode2 + "," + ppeCode3);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (ppeDataReader != null && !ppeDataReader.IsClosed)
                    ppeDataReader.Close();
            }
        }

        #endregion

        #region StockErrorLog
        public int InsertLog_StockError(int siteID, int userID, StockIssueLog issueLog)
        {
            try
            {
                int createdOn = 0;
                int createdTime = 0;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, siteID, ref createdOn, ref createdTime);

                int logID = PreweighDAL.InsertLog_StockError(db, siteID, Convert.ToInt32(issueLog.StockIssueType), issueLog.LoggedPOList, issueLog.Batch, issueLog.Material,
                    issueLog.Bin, issueLog.Quantity, issueLog.ActualQuantity, issueLog.Unit, issueLog.Comment, userID, createdOn);

                return logID;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while inserting stock error Log", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "User ID: " + userID.ToString() + "; SiteID: " + siteID.ToString() + "; Batch: " + issueLog.Batch + "; Material: " + issueLog.Material);

                throw new FaultException(ex.Message);
            }
        }

        public int InsertLog_BinTransfer(int siteID, int userID, StockIssueLog issueLog)
        {
            try
            {
                int createdOn = 0;
                int createdTime = 0;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, siteID, ref createdOn, ref createdTime);

                int logID = PreweighDAL.InsertLog_BinTransfer(db, siteID, Convert.ToInt32(issueLog.StockIssueType), issueLog.LoggedPOList, issueLog.Batch, issueLog.Material, issueLog.Bin,
                    issueLog.ActualBin, issueLog.ActualQuantity, issueLog.Comment, userID, createdOn);

                return logID;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while inserting Bin Transfer Log", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "User ID: " + userID.ToString() + "; SiteID: " + siteID.ToString() + "; Batch: " + issueLog.Batch + "; Material: " + issueLog.Material);

                throw new FaultException(ex.Message);
            }
        }

        public int InsertLog_BinBatchError(int siteID, int userID, StockIssueLog issueLog)
        {
            try
            {
                int createdOn = 0;
                int createdTime = 0;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, siteID, ref createdOn, ref createdTime);

                int logID = PreweighDAL.InsertLog_BinBatchError(db, siteID, Convert.ToInt32(issueLog.StockIssueType), issueLog.LoggedPOList, issueLog.Batch, issueLog.Material,
                    issueLog.Bin, issueLog.Batch, issueLog.ActaulBatch, issueLog.Comment, userID, createdOn);

                return logID;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while inserting Bin Batch Error Log", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "User ID: " + userID.ToString() + "; SiteID: " + siteID.ToString() + "; Batch: " + issueLog.Batch + "; Material: " + issueLog.Material);

                throw new FaultException(ex.Message);
            }
        }

        public int InsertLog_BinMaterialError(int siteID, int userID, StockIssueLog issueLog)
        {
            try
            {
                int createdOn = 0;
                int createdTime = 0;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, siteID, ref createdOn, ref createdTime);
                int logID = PreweighDAL.InsertLog_BinMaterialError(db, siteID, Convert.ToInt32(issueLog.StockIssueType), issueLog.LoggedPOList, issueLog.Batch, issueLog.Material,
                    issueLog.Bin, issueLog.Material, issueLog.ActualMaterial, issueLog.Comment, userID, createdOn);

                return logID;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while inserting Bin Material Error Log", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "User ID: " + userID.ToString() + "; SiteID: " + siteID.ToString() + "; Batch: " + issueLog.Batch + "; Material: " + issueLog.Material);

                throw new FaultException(ex.Message);
            }
        }

        public int InsertLog_BinMaterialBatchError(int siteID, int userID, StockIssueLog issueLog)
        {
            try
            {
                int createdOn = 0;
                int createdTime = 0;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, siteID, ref createdOn, ref createdTime);

                int logID = PreweighDAL.InsertLog_BinMaterialBatchError(db, siteID, Convert.ToInt32(issueLog.StockIssueType), issueLog.LoggedPOList, issueLog.Batch, issueLog.Material,
                    issueLog.Bin, issueLog.ActaulBatch, issueLog.ActualMaterial, issueLog.Comment, userID, createdOn);

                return logID;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while inserting Bin Material Batch Error Log", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "User ID: " + userID.ToString() + "; SiteID: " + siteID.ToString() + "; Batch: " + issueLog.Batch + "; Material: " + issueLog.Material);

                throw new FaultException(ex.Message);
            }
        }

        public int InsertLog_MaterialDeStockComment(int siteID, int userID, StockIssueLog issueLog)
        {
            try
            {
                int createdOn = 0;
                int createdTime = 0;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, siteID, ref createdOn, ref createdTime);

                int logID = PreweighDAL.InsertLog_MaterialDeStockComment(db, siteID, Convert.ToInt32(issueLog.StockIssueType), issueLog.LoggedPOList, issueLog.Batch,
                    issueLog.Material, issueLog.Bin, issueLog.Comment, userID, createdOn);

                return logID;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while inserting Material DeStock Error Log", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "User ID: " + userID.ToString() + "; SiteID: " + siteID.ToString() + "; Batch: " + issueLog.Batch + "; Material: " + issueLog.Material);

                throw new FaultException(ex.Message);
            }
        }

        public int InsertLog_UllageFound(int siteID, int userID, StockIssueLog issueLog)
        {
            try
            {
                int createdOn = 0;
                int createdTime = 0;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, siteID, ref createdOn, ref createdTime);

                int logID = PreweighDAL.InsertLog_UllageFound(db, siteID, Convert.ToInt32(issueLog.StockIssueType), issueLog.LoggedPOList, issueLog.Material, issueLog.Comment,
                    userID, createdOn);

                return logID;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while inserting Ullage Found Error Log", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "User ID: " + userID.ToString() + "; SiteID: " + siteID.ToString() + "; Batch: " + issueLog.Batch + "; Material: " + issueLog.Material);

                throw new FaultException(ex.Message);
            }
        }

        public StockIssueLogList GetOpenIssues(StockIssueLogFilter filterInfo)
        {
            IDataReader issueInfoDataReader = null;
            StockIssueLogList issueLogList = new StockIssueLogList();
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                string sortFiled = string.Empty;
                if (filterInfo.SortType != null)
                    sortFiled = filterInfo.SortType.ToString();

                string issueLogType = string.Empty;
                if (filterInfo.StockIssueLogType != null)
                    issueLogType = ((int)filterInfo.StockIssueLogType).ToString();

                string issueType = string.Empty;
                if (filterInfo.StockIssueType != null)
                    issueType = ((int)filterInfo.StockIssueType).ToString();

                if (filterInfo.MaterialSearch == null)
                    filterInfo.MaterialSearch = string.Empty;

                if (filterInfo.BatchSearch == null)
                    filterInfo.BatchSearch = string.Empty;

                if (filterInfo.BinSearch == null)
                    filterInfo.BinSearch = string.Empty;

                issueInfoDataReader = PreweighDAL.GetOpenIssues(db, filterInfo.SiteID, filterInfo.PageSize, filterInfo.PageIndex, filterInfo.MaterialSearch, filterInfo.BatchSearch
                                                                , filterInfo.BinSearch, sortFiled, issueLogType, issueType);

                StockIssueLog issueLog;

                int i = 0;

                while (issueInfoDataReader.Read())
                {
                    issueLog = new StockIssueLog();

                    issueLog.LogID = Common.GetSafeInt32(issueInfoDataReader, "FLOGID");
                    issueLog.StockIssueType = Common.GetStockLogType(Common.GetSafeInt32(issueInfoDataReader, "FISSUETYPE"));
                    issueLog.StockIssueLogType = Common.GetStockIssueLogType(Common.GetSafeInt32(issueInfoDataReader, "FLOGTYPE"));
                    issueLog.LoggedPOList = Common.GetSafeString(issueInfoDataReader, "FAURFLIST");
                    issueLog.Bin = Common.GetSafeString(issueInfoDataReader, "FBIN");
                    issueLog.ActualBin = Common.GetSafeString(issueInfoDataReader, "FACTUALBIN");
                    issueLog.Batch = Common.GetSafeString(issueInfoDataReader, "FBATCHNUM");
                    issueLog.ActaulBatch = Common.GetSafeString(issueInfoDataReader, "FACTULABATCH");
                    issueLog.Quantity = Common.GetSafeDecimal(issueInfoDataReader, "FQTY");
                    issueLog.ActualQuantity = Common.GetSafeDecimal(issueInfoDataReader, "FACTUALQTY");
                    issueLog.Unit = Common.GetSafeString(issueInfoDataReader, "FUOM");
                    issueLog.Material = Common.GetSafeString(issueInfoDataReader, "FMATERIAL");
                    issueLog.ActualMaterial = Common.GetSafeString(issueInfoDataReader, "FACTUALMATERIAL");
                    issueLog.Comment = Common.GetSafeString(issueInfoDataReader, "FCOMMENT");
                    issueLog.UserName = (Common.GetSafeString(issueInfoDataReader, "FLASTNAME").ToUpper() + " " + Common.GetSafeString(issueInfoDataReader, "FFIRSTNAME").ToUpper()).TrimStart();

                    issueLog.LogDate = Common.GetSafeInt32(issueInfoDataReader, "FCREATEDON");
                    issueLogList.IssueLogList.Add(issueLog);

                    if (i == 0)
                    {
                        issueLogList.TotalRecords = Common.GetSafeInt32(issueInfoDataReader, "FCOUNT");
                    }

                    i++;
                }

                issueInfoDataReader.Close();

                return issueLogList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching stock issue error logs", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "Log Type: " + filterInfo.StockIssueLogType.ToString() + "; SiteID: " + filterInfo.SiteID + ";Material: " + filterInfo.MaterialSearch + "; Batch: " + filterInfo.BatchSearch);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (issueInfoDataReader != null && !issueInfoDataReader.IsClosed)
                    issueInfoDataReader.Close();
            }
        }

        public bool CloseStockErrorLogIssue(BasicParam basicParam, int logID)
        {
            int currentDate = 0;
            int currentTime = 0;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, basicParam.SiteID, ref currentDate, ref currentTime);

                PreweighDAL.CloseStockErrorLogIssue(db, basicParam.SiteID, logID, basicParam.UserID, currentDate);
                return true;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while closing stock issue error log", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name,
                    "Log ID: " + logID.ToString() + "; SiteID: " + basicParam.SiteID.ToString() + "; UserID: " + basicParam.UserID);

                throw new FaultException(ex.Message);
            }
        }

        #endregion

        #region PrintPreweighLabel
        //OLD METHOD
        public bool CreatePreWeighLabel(PrintPreweighLabel preweighLabelInfo)
        {
            int currentDate = 0;
            int currentTime = 0;
            int lineItemNumber = 1;

            IDataReader dataReaderPreweighLabel = null;
            PreweighLabelInfo printPreweighLabelInfo = new PreweighLabelInfo();
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                string preweighLabel = PreweighDAL.CheckPreweighLabelExists(db, preweighLabelInfo.ProcessOrderNumber);

                if (preweighLabel.Trim().Length == 0)
                {
                    Common.GetCurrentSiteDateTime(db, preweighLabelInfo.SiteID, ref currentDate, ref currentTime);
                    preweighLabel = "STG" + preweighLabelInfo.ProcessOrderNumber;
                    PreweighDAL.InsertPreWeighLabel(db, preweighLabelInfo.ProcessOrderNumber, preweighLabel, lineItemNumber, preweighLabelInfo.UserID, currentDate);
                }

                dataReaderPreweighLabel = PreweighDAL.GetPreWeighLabelDetails(db, preweighLabelInfo.SiteID, preweighLabel);
                if (dataReaderPreweighLabel.Read())
                {
                    printPreweighLabelInfo.BatchNumber = Common.GetSafeString(dataReaderPreweighLabel, "FCHARG");
                    printPreweighLabelInfo.PreweighLabel = Common.GetSafeString(dataReaderPreweighLabel, "FPREWEIGHLABEL");
                    printPreweighLabelInfo.MaterialDescription = Common.GetSafeString(dataReaderPreweighLabel, "FIDHDESC");
                    printPreweighLabelInfo.MaterialNumber = Common.GetSafeString(dataReaderPreweighLabel, "FMATNR");
                    printPreweighLabelInfo.ProcessOrderNumber = Common.GetSafeString(dataReaderPreweighLabel, "FAUFNR");
                    printPreweighLabelInfo.Resource = Common.GetSafeString(dataReaderPreweighLabel, "FCATEGORY");
                    printPreweighLabelInfo.TotalQty = Common.GetSafeDecimal(dataReaderPreweighLabel, "FTOTALQTY");
                    printPreweighLabelInfo.Uom = Common.GetSafeString(dataReaderPreweighLabel, "FMEINS");
                }

                dataReaderPreweighLabel.Close();

                string uniqueFileStartName = DateTime.Now.ToString("ddMMhhmmssffff") + "_" + preweighLabelInfo.UserID + "_" + printPreweighLabelInfo.PreweighLabel;
                PrintPreweighLabel(db, printPreweighLabelInfo, preweighLabelInfo.NumberOfLabel, uniqueFileStartName, preweighLabelInfo.PrinterID, preweighLabelInfo.SiteID);

                if (CommonDAL.CheckUserExistsForPrinter(db, preweighLabelInfo.UserID))
                {
                    CommonDAL.SetUserDefaultSTGPrinter(db, preweighLabelInfo.UserID, preweighLabelInfo.PrinterID);
                }
                else
                {
                    CommonDAL.InsertUserDefaultSTGPrinter(db, preweighLabelInfo.UserID, preweighLabelInfo.PrinterID);
                }

                return true;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while creating preweigh labels", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Orders: " + preweighLabelInfo.ProcessOrderNumber + "; SiteID: " + preweighLabelInfo.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPreweighLabel != null && !dataReaderPreweighLabel.IsClosed)
                    dataReaderPreweighLabel.Close();
            }
        }

        //OLD METHOD
        private static bool PrintPreweighLabel(Database db, PreweighLabelInfo printPreweighLabelInfo, int numberOfLabels, string fileName, int printerID, int siteID)
        {
            IDataReader dataReaderPrinter = null;
            IDataReader dataReaderPOStatus = null;
            IDataReader dataReaderInCompleteList = null;
            ProcessOrderStatus status = ProcessOrderStatus.Not_Started;
            string materialDescriptions = string.Empty;

            try
            {
                string printerShortName = string.Empty;

                dataReaderPrinter = CommonDAL.GetPrinterShortName(db, printerID);
                if (dataReaderPrinter.Read())
                {
                    printerShortName = Common.GetSafeString(dataReaderPrinter, "FPRINTERSHORTNAME");
                }

                dataReaderPrinter.Close();

                dataReaderPOStatus = PreweighDAL.GetProcessOrderHeaderStatus(db, null, printPreweighLabelInfo.ProcessOrderNumber);
                if (dataReaderPOStatus.Read())
                {
                    status = Common.GetProcessOrderStatus(Common.GetSafeString(dataReaderPOStatus, "FHDRSTATUS"));
                }
                dataReaderPOStatus.Close();

                if (status == ProcessOrderStatus.Staging_InProgress)
                {
                    dataReaderInCompleteList = PreweighDAL.GetIncompletePreweighList(db, siteID, printPreweighLabelInfo.ProcessOrderNumber);
                    int i = 0;
                    while (dataReaderInCompleteList.Read())
                    {
                        if (i == 0)
                        {
                            fileName = fileName + "_INCOMP_" + printerShortName + ".txt";
                            materialDescriptions = Common.GetSafeString(dataReaderInCompleteList, "FIDHDESC");
                        }
                        else
                        {
                            materialDescriptions = materialDescriptions + "|" + Common.GetSafeString(dataReaderInCompleteList, "FIDHDESC");
                        }
                        i++;

                        if (i == 4)         //maximum four
                            break;
                    }

                    dataReaderInCompleteList.Close();
                }
                else
                {
                    fileName = fileName + "_COMP_" + printerShortName + ".txt";
                }

                string writeLine = string.Empty;

                string targetFile = ConfigurationManager.AppSettings["BarCodeLabelLocation"] + fileName;
                using (FileStream fs = new FileStream(targetFile, FileMode.Create, FileAccess.Write))
                {
                    using (StreamWriter sw = new StreamWriter(fs))
                    {

                        writeLine = printPreweighLabelInfo.MaterialNumber + "|" + printPreweighLabelInfo.MaterialDescription + "|" + printPreweighLabelInfo.BatchNumber
                            + "|" + printPreweighLabelInfo.TotalQty + "|" + printPreweighLabelInfo.Uom + "|" + printPreweighLabelInfo.Resource
                            + "|" + printPreweighLabelInfo.PreweighLabel + "|" + printPreweighLabelInfo.ProcessOrderNumber + "|" + numberOfLabels;


                        if (materialDescriptions.Length > 0)
                        {
                            writeLine = writeLine + "|" + materialDescriptions;
                        }

                        sw.WriteLine(writeLine);
                        sw.Close();
                    }
                    fs.Close();
                }

                return true;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while creating printing preweigh labels", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Orders: " + printPreweighLabelInfo.ProcessOrderNumber + "; SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPrinter != null && !dataReaderPrinter.IsClosed)
                    dataReaderPrinter.Close();

                if (dataReaderPOStatus != null && !dataReaderPOStatus.IsClosed)
                    dataReaderPOStatus.Close();

                if (dataReaderInCompleteList != null && !dataReaderInCompleteList.IsClosed)
                    dataReaderInCompleteList.Close();

            }

        }

        //Called from handheld, on verify kit, locate kit etc..
        public PreweighLabelInfo GetPreweighLabelInfo(int siteID, int userID, string preweighLabel)
        {
            PreweighLabelInfo preweighLabelInfo = null;
            PlantSettings plantSetting = new PlantSettings();
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                int currentDate = 0;
                int currentTime = 0;

                Common.GetCurrentSiteDateTime(db, siteID, ref currentDate, ref currentTime);

                plantSetting = Common.GetPlantSettings(db, siteID);

                //If external warehouse is enabled, the format of kit label in external warehouse is [kitLabel palletNumber]; hence splitting is done to get kit label
                preweighLabel = preweighLabel.Split(' ')[0].Trim();

                //kit label not found, then create one & fetch again preweighLabelInfo; Kit label may not be printed if kit is directly received from external warehouse;
                //Hence only in case of external warehouse enabled, create one if not found
                preweighLabelInfo = GetPreWeighLabelInfo(db, siteID, preweighLabel);
                if (plantSetting.ExternalWarehouse.EnableExternalWarehouseKitting && preweighLabelInfo == null)
                {
                    if (CreatePreweighLabelForExternalKitLabel(db, userID, siteID, ref preweighLabel) == true)
                    {
                        preweighLabelInfo = GetPreWeighLabelInfo(db, siteID, preweighLabel);
                    }
                }

                return preweighLabelInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching preweigh label info", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Preweigh Label: " + preweighLabel + "; SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
        }

        public static bool CreatePreweighLabelForExternalKitLabel(Database db, int userID, int siteID, ref string kitLabelNumber)
        {
            IDataReader postatusReader = null;
            try
            {
                int currentDate = 0;
                int currentTime = 0;

                string processOrder = kitLabelNumber.Trim();
                if (kitLabelNumber.Contains("STG"))
                {
                    processOrder = processOrder.Replace("STG", string.Empty);
                }
                else
                {
                    kitLabelNumber = "STG" + processOrder.PadLeft(12, '0');
                }

                using (postatusReader = PreweighDAL.GetProcessOrderHeaderStatus(db, null, processOrder))
                {
                    if (postatusReader.Read())
                    {
                        postatusReader.Close();
                        Common.GetCurrentSiteDateTime(db, siteID, ref currentDate, ref currentTime);

                        DataTable dtPreweighLabelExists = PreweighDAL.GetPreweighLabelInfo(db, kitLabelNumber);

                        if (dtPreweighLabelExists.Rows.Count == 0)
                            PreweighDAL.InsertPreWeighLabel(db, processOrder, kitLabelNumber, 1, userID, currentDate);

                        return true;
                    }
                    else
                    {
                        postatusReader.Close();
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while creating kit label", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Preweigh Label: " + kitLabelNumber + "; SiteID: " + siteID);
                return false;
            }
            finally
            {
                if (postatusReader != null && !postatusReader.IsClosed)
                    postatusReader.Close();
            }
        }

        private PreweighLabelInfo GetPreWeighLabelInfo(Database db, int siteID, string preweighLabel)
        {
            IDataReader dataReaderPreweighLabel = null;
            try
            {

                PreweighLabelInfo preweighLabelInfo = null;

                dataReaderPreweighLabel = PreweighDAL.GetPreWeighLabelDetails(db, siteID, preweighLabel);
                if (dataReaderPreweighLabel.Read())
                {
                    preweighLabelInfo = new PreweighLabelInfo();

                    preweighLabelInfo.BatchNumber = Common.GetSafeString(dataReaderPreweighLabel, "FCHARG");
                    preweighLabelInfo.PreweighLabel = Common.GetSafeString(dataReaderPreweighLabel, "FPREWEIGHLABEL");
                    preweighLabelInfo.MaterialDescription = Common.GetSafeString(dataReaderPreweighLabel, "FIDHDESC");
                    preweighLabelInfo.MaterialNumber = Common.GetSafeString(dataReaderPreweighLabel, "FMATNR");
                    preweighLabelInfo.ProcessOrderNumber = Common.GetSafeString(dataReaderPreweighLabel, "FAUFNR");
                    preweighLabelInfo.Resource = Common.GetSafeString(dataReaderPreweighLabel, "FCATEGORY");
                    preweighLabelInfo.TotalQty = Common.GetSafeDecimal(dataReaderPreweighLabel, "FTOTALQTY");
                    preweighLabelInfo.Uom = Common.GetSafeString(dataReaderPreweighLabel, "FMEINS");
                }

                dataReaderPreweighLabel.Close();

                return preweighLabelInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching preweigh label info", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Preweigh Label: " + preweighLabel + "; SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPreweighLabel != null && !dataReaderPreweighLabel.IsClosed)
                    dataReaderPreweighLabel.Close();
            }
        }

        public bool UpdatePreweighedBatchCurrentBin(int siteID, int userID, string preweighLabelNum, string binLocation)
        {
            int currentDate = 0;
            int currentTime = 0;
            DataTable dataTableBinExists = null;
            int lineItemNumber = 0;
            string binLocationExists = string.Empty;
            string processOrder = string.Empty;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, siteID, ref currentDate, ref currentTime);

                dataTableBinExists = PreweighDAL.GetPreweighLabelInfo(db, preweighLabelNum);

                if (dataTableBinExists.Rows.Count > 0)
                {
                    DataRow[] dataRowBinLocation = dataTableBinExists.Select(" FBINLOCATION= '" + binLocation.Trim().ToUpper() + "'");
                    if (dataRowBinLocation.Length == 0)
                    {
                        //Check if row exists with blank current bin
                        binLocationExists = dataTableBinExists.Rows[0]["FBINLOCATION"].ToString().Trim();
                        lineItemNumber = Convert.ToInt32(dataTableBinExists.Rows[0]["FLINEITEM"]);
                        if (binLocationExists == string.Empty)
                        {
                            PreweighDAL.UpdatePreweighedBatchCurrentBin(db, preweighLabelNum, binLocation, lineItemNumber, userID, currentDate);
                        }
                        else
                        {
                            processOrder = dataTableBinExists.Rows[0]["FAUFNR"].ToString();  //FIRST ROWS Process order number
                            lineItemNumber = Convert.ToInt32(dataTableBinExists.Rows[dataTableBinExists.Rows.Count - 1]["FLINEITEM"].ToString()); // last row's line item + 1
                            lineItemNumber++;
                            PreweighDAL.InsertPreweighedBatchCurrentBin(db, processOrder, preweighLabelNum, binLocation, userID, currentDate, lineItemNumber);

                        }
                    }
                    return true;
                }
                return false;

            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while checking bin location for preweigh label", "iPAS_PreWeighService",
                    System.Reflection.MethodBase.GetCurrentMethod().Name, "Preweigh Label: " + preweighLabelNum + "; SiteID: " + siteID);

                throw new FaultException(ex.Message);
            }
        }

        public List<PreweighLabelInfo> GetProcessOrderPreWeighLabelInfo(int siteID, int userID, string processOrder)
        {
            IDataReader dataReaderPreweighLabel = null;
            PreweighLabelInfo preweighLabelInfo = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                List<PreweighLabelInfo> preweighLabelList = new List<PreweighLabelInfo>();

                dataReaderPreweighLabel = PreweighDAL.GetProcessOrderPreWeighLabelInfo(db, siteID, processOrder);
                while (dataReaderPreweighLabel.Read())
                {
                    preweighLabelInfo = new PreweighLabelInfo();

                    preweighLabelInfo.BatchNumber = Common.GetSafeString(dataReaderPreweighLabel, "FCHARG");
                    preweighLabelInfo.PreweighLabel = Common.GetSafeString(dataReaderPreweighLabel, "FPREWEIGHLABEL");
                    preweighLabelInfo.MaterialDescription = Common.GetSafeString(dataReaderPreweighLabel, "FIDHDESC");
                    preweighLabelInfo.MaterialNumber = Common.GetSafeString(dataReaderPreweighLabel, "FMATNR");
                    preweighLabelInfo.ProcessOrderNumber = Common.GetSafeString(dataReaderPreweighLabel, "FAUFNR");
                    preweighLabelInfo.Resource = Common.GetSafeString(dataReaderPreweighLabel, "FCATEGORY");
                    preweighLabelInfo.TotalQty = Common.GetSafeDecimal(dataReaderPreweighLabel, "FTOTALQTY");
                    preweighLabelInfo.Uom = Common.GetSafeString(dataReaderPreweighLabel, "FMEINS");
                    preweighLabelInfo.Binlocation = Common.GetSafeString(dataReaderPreweighLabel, "FBINLOCATION");

                    preweighLabelList.Add(preweighLabelInfo);
                }

                dataReaderPreweighLabel.Close();

                return preweighLabelList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching preweigh label info", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Orde: " + processOrder + "; SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPreweighLabel != null && !dataReaderPreweighLabel.IsClosed)
                    dataReaderPreweighLabel.Close();
            }
        }

        #endregion

        #region PrintRawMaterialLabel
        public List<ProcessOrderBatchMaterial> GetAllPreweighedBatchesForMaterial(BatchMaterailParam batchParam)
        {
            IDataReader dataReaderBatcMaterial = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                List<ProcessOrderBatchMaterial> materialBacthList = new List<ProcessOrderBatchMaterial>();
                dataReaderBatcMaterial = PreweighDAL.GetAllPreweighedBatchesForMaterial(db, batchParam.ProcessOrderList, batchParam.MaterialNumber, batchParam.POSNR, batchParam.PhaseNumber);

                while (dataReaderBatcMaterial.Read())
                {
                    ProcessOrderBatchMaterial batchMaterial = new ProcessOrderBatchMaterial();
                    batchMaterial.BatchNumber = Common.GetSafeString(dataReaderBatcMaterial, "FCHARG");
                    batchMaterial.PickedQty = Common.GetSafeDecimal(dataReaderBatcMaterial, "FPICKEDQTY");
                    batchMaterial.UoM = Common.GetSafeString(dataReaderBatcMaterial, "FUOM");
                    materialBacthList.Add(batchMaterial);
                }
                dataReaderBatcMaterial.Close();
                return materialBacthList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching  batch material info for lineitem", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name
                    , "Process Orders: " + batchParam.ProcessOrderList + "; POSNR: " + batchParam.POSNR + ";Phase:" + batchParam.PhaseNumber
                    + ";Material:" + batchParam.MaterialNumber);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderBatcMaterial != null && !dataReaderBatcMaterial.IsClosed)
                    dataReaderBatcMaterial.Close();
            }
        }

        //EF00051- Aug 10, 2010 - Print raw material label
        public bool PrintPreweighQtyLabel(PreWeighQtyLabelParam labelParam)
        {
            IDataReader materialDataReader = null;
            IDataReader printerDataReader = null;
            string materialDesc = string.Empty;
            string hazardDesc = string.Empty;
            string targetFileName = string.Empty;
            string targetFile = string.Empty;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                materialDataReader = PreweighDAL.GetMaterialDesc(db, labelParam.SiteID, labelParam.MaterialNumber);

                if (materialDataReader.Read())
                {
                    materialDesc = Common.GetSafeString(materialDataReader, "FIDHDESC");
                    hazardDesc = Common.GetSafeString(materialDataReader, "FHAZARDDESC");
                }
                materialDataReader.Close();

                string printerShortName = string.Empty;
                printerDataReader = CommonDAL.GetPrinterShortName(db, labelParam.PrinterID);
                if (printerDataReader.Read())
                {
                    printerShortName = Common.GetSafeString(printerDataReader, "FPRINTERSHORTNAME").ToLower();
                }
                printerDataReader.Close();


                targetFileName = DateTime.Now.ToString("ddMMhhmmssffff") + "_" + labelParam.UserID + "_Raw_";
                targetFile = ConfigurationManager.AppSettings["BarCodeLabelLocation"] + targetFileName + printerShortName + ".txt";

                using (FileStream fs = new FileStream(targetFile, FileMode.Create, FileAccess.Write))
                {
                    using (StreamWriter sw = new StreamWriter(fs))
                    {
                        //CR00089 -add hazard desc for RAW type
                        sw.WriteLine(labelParam.MaterialNumber + "|" + materialDesc + "|" + labelParam.BatchNumber + "|" + labelParam.Qty + "|" + labelParam.UoM + "|" + hazardDesc + "|" + labelParam.NumberOfCopies);
                        //CR00089 - End

                        sw.Close();
                    }
                    fs.Close();
                }

                return true;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while printing raw material label", "iPAS_PreWeighService"
                                    , System.Reflection.MethodBase.GetCurrentMethod().Name
                                    , "Mat Num: " + labelParam.MaterialNumber + ";Batch:" + labelParam.BatchNumber + ";Qty: " + labelParam.Qty
                                        + ";UoM:" + labelParam.UoM + ";Printer:" + labelParam.PrinterID + ";UserID:" + labelParam.UserID);

                throw new FaultException(ex.Message);
            }
            finally
            {
                if (materialDataReader != null && !materialDataReader.IsClosed)
                    materialDataReader.Close();

                if (printerDataReader != null && !printerDataReader.IsClosed)
                    printerDataReader.Close();
            }
        }
        //EF00051- End
        #endregion

        #region ReplenishPackagingMaterail
        public List<PackagingMaterialInfo> GetPackagingMaterialForReplenishment(BasicParam basicParam, PackagingMaterialFilter filterInfo)
        {
            IDataReader packagingMaterialPickQtyDataReader = null;
            try
            {
                int currentDate = 0;
                int currentTime = 0;

                int currentShiftStartTime = 0;
                int currentShiftEndTime = 0;
                int currentShiftStartDate = 0;
                int currentShiftEndDate = 0;

                int currentShiftNum = 0;

                int previousShiftStartTime = 0;
                int previousShiftEndTime = 0;
                int previousShiftStartDate = 0;
                int previousShiftEndDate = 0;

                int nextShiftStartTime = 0;
                int nextShiftEndTime = 0;
                int nextShiftStartDate = 0;
                int nextShiftEndDate = 0;

                string currentShiftStartDateTimeString = string.Empty;
                string currentShiftEndDateTimeString = string.Empty;

                string prevShiftStartDateTimeString = string.Empty;
                string prevShiftEndDateTimeString = string.Empty;

                string nextShiftStartDateTimeString = string.Empty;
                string nextShiftEndDateTimeString = string.Empty;

                OrderPLineSettings plineSetting = null;
                PackagingMaterialInfo packagingMaterialInfo = null;
                PlantSettings plantSetting = new PlantSettings();
                List<PackagingMaterialInfo> packagingMaterialInfoList = new List<PackagingMaterialInfo>();

                int shiftNum = 1;// parameter the get current shift number

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, basicParam.SiteID, ref currentDate, ref currentTime);

                plineSetting = Common.GetProductionLineSettings(db, filterInfo.ProductionLinesID, basicParam.SiteID);

                //if data to be display shift vise than getting shift info
                List<ShiftInfo> shiftList = new List<ShiftInfo>();
                int shiftLength = 0;
                if (filterInfo.ReplenishDisplayType == ReplenishDisplayType.ByShift)
                {
                    shiftList = GetProductionLineShifts(db, basicParam, plineSetting.PLineID, ref shiftLength);
                    foreach (ShiftInfo currentShift in shiftList)
                    {
                        //checking if current time lies between particular shift start and end time if yes than consider that shift start and end time or else check for next shift
                        //if current shift is 1st shift than we won't take previous shift data...
                        bool isCurrentShift = Common.CheckForCurrentShift(currentTime, currentShift.ShiftStartTime, currentShift.ShiftEndTime);
                        if (isCurrentShift)
                        {
                            currentShiftStartDate = currentDate;
                            currentShiftStartTime = currentShift.ShiftStartTime;

                            string shiftEndDateTime = Common.GetConvertedDateByAddingMinutes(currentShiftStartDate, currentShiftStartTime, (shiftLength * 60), "yyyyMMdd HHmmss");
                            Common.GetDateAndTime(shiftEndDateTime, "yyyyMMdd HHmmss", ref currentShiftEndDate, ref currentShiftEndTime);

                            //Previous shift
                            previousShiftEndDate = currentShiftStartDate;
                            previousShiftEndTime = currentShiftStartTime;

                            string prevShiftStartDateTime = Common.GetConvertedDateByAddingMinutes(previousShiftEndDate, previousShiftEndTime, -(shiftLength * 60), "yyyyMMdd HHmmss");
                            Common.GetDateAndTime(prevShiftStartDateTime, "yyyyMMdd HHmmss", ref previousShiftStartDate, ref previousShiftStartTime);

                            //Next Shift
                            nextShiftStartDate = currentShiftEndDate;
                            nextShiftStartTime = currentShiftEndTime;

                            string nextShiftEndDateTime = Common.GetConvertedDateByAddingMinutes(nextShiftStartDate, nextShiftStartTime, (shiftLength * 60), "yyyyMMdd HHmmss");
                            Common.GetDateAndTime(nextShiftEndDateTime, "yyyyMMdd HHmmss", ref nextShiftEndDate, ref nextShiftEndTime);

                            currentShiftNum = shiftNum;
                            break;
                        }

                        shiftNum++;
                    }

                    currentShiftStartDateTimeString = string.Concat(currentShiftStartDate, currentShiftStartTime.ToString().PadLeft(6, '0'));
                    currentShiftEndDateTimeString = string.Concat(currentShiftEndDate, currentShiftEndTime.ToString().PadLeft(6, '0'));

                    prevShiftStartDateTimeString = string.Concat(previousShiftStartDate, previousShiftStartTime.ToString().PadLeft(6, '0'));
                    prevShiftEndDateTimeString = string.Concat(previousShiftEndDate, previousShiftEndTime.ToString().PadLeft(6, '0'));

                    nextShiftStartDateTimeString = string.Concat(nextShiftStartDate, nextShiftStartTime.ToString().PadLeft(6, '0'));
                    nextShiftEndDateTimeString = string.Concat(nextShiftEndDate, nextShiftEndTime.ToString().PadLeft(6, '0'));
                }


                DataTable packagingMaterialTable = PreweighDAL.GetPackagingMaterialForReplenishment(db, basicParam.SiteID, basicParam.UserID, basicParam.AccessLevelID
                    , filterInfo.ProductionLinesID, filterInfo.ProcessOrderNum, currentDate, currentShiftStartDateTimeString, currentShiftEndDateTimeString, prevShiftStartDateTimeString, prevShiftEndDateTimeString);

                //if packagingMaterialTable row count is zero and it has to be display shift vise than we will bring next shift material which is to be replenish..
                //if my current shift is last shift for the day than we will bring next day first shift material which is to be replenish..
                if (filterInfo.ReplenishDisplayType == ReplenishDisplayType.ByShift)
                {
                    //if material count is zero than bring next shift material
                    if (packagingMaterialTable.Rows.Count == 0)
                    {
                        packagingMaterialTable = PreweighDAL.GetPackagingMaterialForReplenishment(db, basicParam.SiteID, basicParam.UserID, basicParam.AccessLevelID
                            , filterInfo.ProductionLinesID, filterInfo.ProcessOrderNum, currentDate, nextShiftStartDateTimeString, nextShiftEndDateTimeString, string.Empty, string.Empty);
                    }
                }

                if (packagingMaterialTable.Rows.Count > 0)
                {
                    List<iPAS_PalletInfo.AvailableBinInfo> availableBins = null;
                    //for displaying replenish material for PO no need to consider availableQtyInSupplyArea
                    if (filterInfo.ProcessOrderNum.Trim().Length == 0)
                    {
                        //Get plant setting
                        plantSetting = Common.GetPlantSettings(db, basicParam.SiteID);
                        iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(basicParam.LanguageCode);

                        string plantCode = packagingMaterialTable.Rows[0]["FWERKS"].ToString().Trim();

                        List<iPASRFSAP.MaterialBinInfo> materialList = new List<iPASRFSAP.MaterialBinInfo>();

                        foreach (DataRow dr in packagingMaterialTable.Rows)
                        {
                            iPASRFSAP.MaterialBinInfo materialInfo = new iPASRFSAP.MaterialBinInfo();
                            materialInfo.MaterialNumber = dr["FMATNR"].ToString().Trim();
                            materialInfo.Plant = dr["FWERKS"].ToString().Trim();
                            materialInfo.WareHouseNumber = plantSetting.WarehouseNumber;

                            materialList.Add(materialInfo);
                        }

                        availableBins = iPAS_PalletInfo.SAPBinBatchInfoBLL.GetAvailableBinListForMultipleMaterials(db, basicParam.SiteID, sapBapiClass, false, materialList, false);
                    }

                    foreach (DataRow dr in packagingMaterialTable.Rows)
                    {
                        decimal requiredQty = 0;
                        decimal availableQtyInSupplyArea = 0;

                        decimal.TryParse(dr["FQTY"].ToString().Trim(), out requiredQty);

                        //if displaying replenish material for PO than required qty of the packaging materia is calculated as total required qty for LINEITEM - total LINEITEM qty already in  staging area
                        //if displaying replenish material only than required qty of the packaging material is calculated as total required qty for all scheduled PO of the day minus total qty already available in production area
                        if (filterInfo.ProcessOrderNum.Trim().Length == 0)
                        {
                            List<iPAS_PalletInfo.AvailableBinInfo> supplyBinList = availableBins.FindAll(a => a.BinName == plineSetting.SupplyBin && a.StorageType == plineSetting.SupplyArea && a.StorageLocation == dr["FLGORT"].ToString().Trim() && a.MaterialNumber == dr["FMATNR"].ToString().Trim().PadLeft(18, '0'));

                            foreach (iPAS_PalletInfo.AvailableBinInfo qtyRow in supplyBinList)
                            {
                                decimal quantity = 0;
                                decimal.TryParse(qtyRow.Quantity.ToString(), out quantity);

                                availableQtyInSupplyArea = availableQtyInSupplyArea + quantity;
                            }
                        }
                        else
                        {
                            //calculate total qty already picked for material from staging table
                            string materialNum = dr["FMATNR"].ToString().Trim();
                            packagingMaterialPickQtyDataReader = PreweighDAL.GetPackagingMaterialPickQty(db, filterInfo.ProcessOrderNum, materialNum);

                            if (packagingMaterialPickQtyDataReader.Read())
                            {
                                availableQtyInSupplyArea = Common.GetSafeDecimal(packagingMaterialPickQtyDataReader, "FPICKEDQTY");
                            }
                            packagingMaterialPickQtyDataReader.Close();
                        }

                        requiredQty = requiredQty - availableQtyInSupplyArea;

                        if (requiredQty > 0)
                        {
                            packagingMaterialInfo = new PackagingMaterialInfo();
                            packagingMaterialInfo.Material = dr["FMATNR"].ToString().Trim();
                            packagingMaterialInfo.MaterialDesc = dr["FIDHDESC"].ToString().Trim();
                            packagingMaterialInfo.IsBatchManaged = dr["FISBATCHMANAGED"].ToString().Trim() == "Y" ? true : false;
                            packagingMaterialInfo.RequiredQty = requiredQty;
                            packagingMaterialInfo.Unit = dr["FUOM"].ToString().Trim();
                            packagingMaterialInfo.RequiredQtyWithUOM = packagingMaterialInfo.RequiredQty + " " + packagingMaterialInfo.Unit;
                            packagingMaterialInfo.PlantCode = dr["FWERKS"].ToString().Trim();
                            packagingMaterialInfo.StorageLocation = dr["FLGORT"].ToString().Trim();

                            packagingMaterialInfoList.Add(packagingMaterialInfo);
                        }
                    }
                }

                return packagingMaterialInfoList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "ManufactureService", "Error while fetching packaging materials for replenishment", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicParam.SiteID + ";User ID: " + basicParam.UserID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (packagingMaterialPickQtyDataReader != null && !packagingMaterialPickQtyDataReader.IsClosed)
                {
                    packagingMaterialPickQtyDataReader.Close();
                }
            }
        }

        public List<PackagingPOBasicInfo> GetPackagingPOForReplenishment(BasicParam basicParam, string productionLineID)
        {
            PackagingPOBasicInfo processOrderInfo = null;
            IDataReader dataReaderPO = null;

            try
            {
                int currentDate = 0;
                int currentTime = 0;

                List<PackagingPOBasicInfo> packagingPOInfoList = new List<PackagingPOBasicInfo>();

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                Common.GetCurrentSiteDateTime(db, basicParam.SiteID, ref currentDate, ref currentTime);

                int nextDayDate = Common.GetConvertedDateByAddingDays(currentDate, 1);
                PlantSettings plantSetting = Common.GetPlantSettings(db, basicParam.SiteID);

                dataReaderPO = PreweighDAL.GetPackagingPOForReplenishment(db, basicParam.SiteID, basicParam.UserID, basicParam.AccessLevelID, productionLineID, string.Empty, currentDate, nextDayDate, plantSetting.ShowNextDaysOrders);

                int processOrderCount = 0;

                while (dataReaderPO.Read())
                {
                    if (plantSetting.MaxOrdersToShowForPick == 0 || processOrderCount < plantSetting.MaxOrdersToShowForPick)
                    {
                        processOrderInfo = new PackagingPOBasicInfo();

                        processOrderInfo.ProcessOrderNumber = Common.GetSafeString(dataReaderPO, "FAUFNR");
                        processOrderInfo.MaterialNumber = Common.GetSafeString(dataReaderPO, "FMATNR");
                        processOrderInfo.MaterialDescription = Common.GetSafeString(dataReaderPO, "FIDHDESC");
                        processOrderInfo.ResourceName = Common.GetSafeString(dataReaderPO, "FRESOURCECODE");

                        packagingPOInfoList.Add(processOrderInfo);
                        processOrderCount++;
                    }
                }

                dataReaderPO.Close();

                return packagingPOInfoList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "ManufactureService", "Error while fetching packaging PO for replenishment", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicParam.SiteID + ";User ID: " + basicParam.UserID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPO != null && !dataReaderPO.IsClosed)
                    dataReaderPO.Close();
            }
        }

        public PackagingMaterialInfo CheckPackagingMaterialExists(BasicParam basicParam, string materialNumber)
        {
            IDataReader packagingMaterialReader = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                PackagingMaterialInfo materialInfo = null;

                packagingMaterialReader = PreweighDAL.CheckPackagingMaterialExists(db, basicParam.SiteID, materialNumber);
                if (packagingMaterialReader.Read())
                {
                    materialInfo = new PackagingMaterialInfo();
                    materialInfo.Material = Common.GetSafeString(packagingMaterialReader, "FIDHID");
                    materialInfo.MaterialDesc = Common.GetSafeString(packagingMaterialReader, "FIDHDESC");
                    materialInfo.IsBatchManaged = Common.GetSafeString(packagingMaterialReader, "FISBATCHMANAGED") == "Y" ? true : false;

                    materialInfo.RequiredQty = 0;
                    materialInfo.Unit = string.Empty;
                    materialInfo.RequiredQtyWithUOM = string.Empty;
                }
                packagingMaterialReader.Close();

                return materialInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "ManufactureService", "Error while validating packaging material", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicParam.SiteID + "; UserID: " + basicParam.UserID + ";Material Num: " + materialNumber);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (packagingMaterialReader != null && !packagingMaterialReader.IsClosed)
                    packagingMaterialReader.Close();
            }
        }

        public PackagingPOBasicInfo CheckPackagingPOForReplenishment(BasicParam basicParam, string productionLineID, string processOrderNum)
        {
            IDataReader dataReaderPO = null;
            try
            {
                PackagingPOBasicInfo processOrderInfo = null;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                PlantSettings plantSetting = Common.GetPlantSettings(db, basicParam.SiteID);

                dataReaderPO = PreweighDAL.GetPackagingPOForReplenishment(db, basicParam.SiteID, basicParam.UserID, basicParam.AccessLevelID, productionLineID, processOrderNum, 0, 0, false);

                if (dataReaderPO.Read())
                {
                    processOrderInfo = new PackagingPOBasicInfo();

                    processOrderInfo.ProcessOrderNumber = Common.GetSafeString(dataReaderPO, "FAUFNR");
                    processOrderInfo.MaterialNumber = Common.GetSafeString(dataReaderPO, "FMATNR");
                    processOrderInfo.MaterialDescription = Common.GetSafeString(dataReaderPO, "FIDHDESC");
                    processOrderInfo.ResourceName = Common.GetSafeString(dataReaderPO, "FRESOURCECODE");
                }
                dataReaderPO.Close();

                return processOrderInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "ManufactureService", "Error while checking packaging PO for replenishment exist", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicParam.SiteID + ";User ID: " + basicParam.UserID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPO != null && !dataReaderPO.IsClosed)
                    dataReaderPO.Close();
            }

        }

        private List<ShiftInfo> GetProductionLineShifts(Database db, BasicParam basicParam, int productionLineID, ref int shiftLength)
        {
            IDataReader shiftDataReader = null;
            try
            {
                shiftDataReader = ManufactureDAL.GetProductionLineShiftInfo(db, basicParam.SiteID, productionLineID);

                List<ShiftInfo> shiftList = new List<ShiftInfo>();

                int noOfShifts = 0;
                int shiftStartTime = 0;

                if (shiftDataReader.Read())
                {
                    noOfShifts = Common.GetSafeInt32(shiftDataReader, "FNUMSHIFTS");
                    shiftStartTime = Common.GetSafeInt32(shiftDataReader, "FSHIFTSTARTTIME");
                    shiftLength = Common.GetSafeInt32(shiftDataReader, "FSHIFTLENGTH");
                }
                shiftDataReader.Close();

                if (noOfShifts > 0)
                {
                    for (int i = 0; i < noOfShifts; i++)
                    {
                        ShiftInfo shiftInfo = new ShiftInfo();
                        //shiftInfo.ShiftName = "Shift" + (i + 1).ToString();

                        if (i == 0)
                            shiftInfo.ShiftStartTime = shiftStartTime;
                        else
                            shiftInfo.ShiftStartTime = shiftList[i - 1].ShiftEndTime;

                        shiftInfo.ShiftEndTime = Common.GetConvertedTimeByAddingHours(shiftInfo.ShiftStartTime, shiftLength);

                        shiftList.Add(shiftInfo);
                    }
                }

                return shiftList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching shift information", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Site ID: " + basicParam.SiteID + ";PLine ID: " + productionLineID + "; User ID: " + basicParam.UserID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (shiftDataReader != null && !shiftDataReader.IsClosed)
                    shiftDataReader.Close();
            }
        }

        #endregion

        #region ManufacturePreweigh
        public ProcessOrderBOMInfo GetProcessOrderBOMInfoForPreweigh(int siteID, int userID, string processOrderNumber, int lineItemNumber)
        {

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                //Get plant setting
                PlantSettings plantSetting = Common.GetPlantSettings(db, siteID);

                if (plantSetting.BatchDeterminationLogic == PlantBatchLogic.TRBased)
                {
                    return FillProcessOrderBOMInfo(db, siteID, userID, processOrderNumber, "SINGLE_LINE", lineItemNumber);
                }
                else
                {
                    return FillProcessOrderBOMInfo(db, siteID, userID, processOrderNumber, lineItemNumber, false);
                }
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting preweigh required materials", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
        }

        private ProcessOrderBOMInfo FillProcessOrderBOMInfo(Database db, int siteID, int userID, string processOrderNumber, int lineItemNumber, bool isAdddition)
        {
            ProcessOrderBOMInfo processOrderBOMInfo = new ProcessOrderBOMInfo();
            List<StageProcessOrderBOM> bomInfoList = new List<StageProcessOrderBOM>();
            IDataReader dataReaderBomInfo = null;

            IDataReader infoReader = null;

            try
            {
                string preWeighNotes = string.Empty;
                StageProcessOrderBOM bomInfo;

                //isAdddition will be passed true,when we want to get the list of all addition materials required
                if (isAdddition)
                {
                    bool showAllAddition = true;

                    dataReaderBomInfo = PreweighDAL.GetPOPhaseAdditions(db, siteID, processOrderNumber, showAllAddition, userID);
                }
                else
                {
                    dataReaderBomInfo = PreweighDAL.GetPOBOMInfoForPreweigh(db, siteID, processOrderNumber, lineItemNumber, userID);
                }

                OrderPLineSettings plineSetting = Common.GetProductionLineSettings(db, siteID, processOrderNumber);
                PlantSettings plantSetting = Common.GetPlantSettings(db, siteID);
                SAPStatus sapAvailabilityStatus = Common.GetSAPAvailabilityStatus(plantSetting.SapAvailabilityStatus, plineSetting.SAPStatus);
                string additionalComment = string.Empty;
                iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

                while (dataReaderBomInfo.Read())
                {
                    bomInfo = new StageProcessOrderBOM();

                    bomInfo.LineItemNumber = Common.GetSafeInt32(dataReaderBomInfo, "FLINEITEM");
                    bomInfo.POSNR = Common.GetSafeString(dataReaderBomInfo, "FPOSNR");
                    bomInfo.VORNR = Common.GetSafeString(dataReaderBomInfo, "FVORNR");
                    bomInfo.Plant = Common.GetSafeString(dataReaderBomInfo, "FWERKS");
                    bomInfo.MaterialNum = Common.GetSafeString(dataReaderBomInfo, "FIDHID");
                    bomInfo.MaterialDesc = Common.GetSafeString(dataReaderBomInfo, "FIDHDESC");
                    bomInfo.BatchNumber = Common.GetSafeString(dataReaderBomInfo, "FCHARG");

                    bomInfo.StorageLocation = Common.GetSafeString(dataReaderBomInfo, "FLGORT");

                    if (Common.GetSafeString(dataReaderBomInfo, "FISBATCHMANAGED") == "Y")
                    {
                        bomInfo.IsBatchManaged = true;
                    }

                    if (Common.GetSafeString(dataReaderBomInfo, "FSTORAGEBIN") == "Y")
                    {
                        bomInfo.IsWarehouseManaged = true;
                    }

                    bomInfo.UOM = Common.GetSafeString(dataReaderBomInfo, "FUOM");

                    /* CR 2150 - 2016-June-20 - Sushin - Concentration based Staging Changes. Get the adjusted quantity for material based on concentration - Start  */
                    decimal totalReqQty = Common.GetSafeDecimal(dataReaderBomInfo, "FQTY");
                    decimal alreadyKittedQty = Common.GetSafeDecimal(dataReaderBomInfo, "FKITTEDQTY");

                    decimal alreadyMixedQty = Common.GetSafeDecimal(dataReaderBomInfo, "FMIXQTY");
                    string movInd = Common.GetSafeString(dataReaderBomInfo, "FMOVIND");
                    bool isAddition = Common.GetSafeString(dataReaderBomInfo, "FISADDITION") == "Y" ? true : false;
                    int concentrationConfigVersionID = Common.GetSafeInt32(dataReaderBomInfo, "FCONCENTRATIONCONFIGVERSION");

                    totalReqQty = Common.GetAdjustedReqQtyForLineItemBasedOnConcentration(db, sapBapiClass, siteID, plantSetting, plineSetting, processOrderNumber, bomInfo.LineItemNumber
                        , bomInfo.VORNR, bomInfo.POSNR, bomInfo.MaterialNum, bomInfo.Plant, bomInfo.StorageLocation, movInd, totalReqQty, alreadyMixedQty, bomInfo.UOM
                        , sapAvailabilityStatus, isAddition, string.Empty, "M", false, ref concentrationConfigVersionID, ref additionalComment);

                    decimal reqQtyToPick = totalReqQty - alreadyMixedQty;

                    bomInfo.Qty = reqQtyToPick;
                    /* CR 2150 - 2016-June-20 - Sushin - Concentration based Staging Changes - End  */

                    int ppeConfirmedUser = Common.GetSafeInt32(dataReaderBomInfo, "FPPECONFIRMUSER");
                    if (ppeConfirmedUser == 0)
                        bomInfo.IsPPEConfirmed = false;
                    else
                        bomInfo.IsPPEConfirmed = true;

                    if (isAdddition == false)
                    {
                        //Calculate the Min and Max Tolerance value for required qty
                        decimal qtyMaxDifference = 0;
                        decimal toleranceValue = (decimal)Common.GetTolerenceValue((double)totalReqQty, plineSetting.ToleranceID, ref qtyMaxDifference);
                        bomInfo.MaxTolerance = reqQtyToPick + toleranceValue;
                        bomInfo.MaxTolerance = Math.Round(bomInfo.MaxTolerance, 3);

                        bomInfo.MinTolerance = (reqQtyToPick - toleranceValue) < 0 ? 0 : (reqQtyToPick - toleranceValue);
                        bomInfo.MinTolerance = Math.Round(bomInfo.MinTolerance, 3);

                        //Check whether the material allows kitting of more quantity or not.
                        bool canKitQtyFromSupplyArea = Common.GetMoreQuantityKittingAllowedStatus(db, siteID, bomInfo.MaterialNum, plineSetting, plantSetting);

                        if (canKitQtyFromSupplyArea)
                        {
                            //Update reserved quantity info for line item if exists.
                            List<ReservedQtyInfo> reservedQtyInfoList = GetReservedQtyInfoForLineItem(db, siteID, processOrderNumber, lineItemNumber, plineSetting.SupplyBin);
                            if (reservedQtyInfoList.Count > 0)
                                processOrderBOMInfo.ReservedQtyInfoList = reservedQtyInfoList;

                            //If reserved quantity info does not exists and line item is addition, then reserve part bag quantity for the line item if available in PSA
                            if (Common.GetSafeString(dataReaderBomInfo, "FISADDITION").ToString().Trim() == "Y" && processOrderBOMInfo.ReservedQtyInfoList.Count == 0)
                            {
                                decimal alreadyReservedQty = Common.GetSafeDecimal(dataReaderBomInfo, "FRESERVEDQTY");


                                decimal pendingQtyToKit = totalReqQty - (alreadyKittedQty + alreadyReservedQty);
                                if (pendingQtyToKit > 0)
                                {
                                    PackSizeInfo stgAreaPackSizeInfo = Common.GetStagingAreaPackSizeForMaterial(db, siteID, bomInfo.MaterialNum, plineSetting);

                                    if (stgAreaPackSizeInfo.PackSize > 0)
                                    {
                                        //iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

                                        decimal convertedPackSize = stgAreaPackSizeInfo.PackSize;
                                        if (stgAreaPackSizeInfo.Unit.Trim().ToUpper() != bomInfo.UOM.Trim().ToUpper())
                                            convertedPackSize = sapBapiClass.UnitConversion(bomInfo.MaterialNum, stgAreaPackSizeInfo.Unit, bomInfo.UOM, stgAreaPackSizeInfo.PackSize);

                                        decimal reqPartBagQty = reqQtyToPick;
                                        if (convertedPackSize > 0)
                                        {
                                            reqPartBagQty = pendingQtyToKit % convertedPackSize;
                                        }

                                        POMaterialReqQtyInfo materialReqQtyInfo = new POMaterialReqQtyInfo();
                                        materialReqQtyInfo.ProcessOrder = processOrderNumber;
                                        materialReqQtyInfo.LineItem = lineItemNumber;
                                        materialReqQtyInfo.TotalReqQty = totalReqQty;
                                        materialReqQtyInfo.TotalPickQty = alreadyKittedQty + alreadyReservedQty;
                                        materialReqQtyInfo.PendingKitQty = pendingQtyToKit;
                                        materialReqQtyInfo.RequiredPreweighBagQty = reqPartBagQty;
                                        materialReqQtyInfo.Unit = bomInfo.UOM;

                                        if (concentrationConfigVersionID > 0)
                                        {
                                            if (pendingQtyToKit < convertedPackSize)
                                            {
                                                ConcentrationRateInfo concRateInfo = Common.GetStdConcentrationRateInfoForMaterial(db, siteID, bomInfo.MaterialNum, concentrationConfigVersionID);
                                                StagingService.KitPartBagQuantityFromSupplyAreaForConcentratedMaterial(db, sapBapiClass, siteID, bomInfo.Plant, userID, plineSetting, true, bomInfo.MaterialNum, bomInfo.BatchNumber, ref materialReqQtyInfo, false, concRateInfo.ConcentrationRate, concRateInfo.QualityMethodName);
                                            }
                                        }
                                        else
                                        {
                                            //Reserve part bag quantity if available in PSA
                                            StagingService.KitPartBagQuantityFromSupplyArea(db, sapBapiClass, siteID, userID, plineSetting, true, bomInfo.MaterialNum, bomInfo.BatchNumber, ref materialReqQtyInfo, true);
                                        }

                                        //Update reserved quantity info for line item if exists.
                                        reservedQtyInfoList = GetReservedQtyInfoForLineItem(db, siteID, processOrderNumber, lineItemNumber, plineSetting.SupplyBin);
                                        if (reservedQtyInfoList.Count > 0)
                                            processOrderBOMInfo.ReservedQtyInfoList = reservedQtyInfoList;
                                    }
                                }
                            }

                            //Now add to list the non reserved batches
                            List<ReservedQtyInfo> nonReservedQtyInfoList = GetNonReservedQtyInfoForMaterial(db, siteID, bomInfo.MaterialNum, plineSetting.SupplyBin);
                            processOrderBOMInfo.ReservedQtyInfoList.AddRange(nonReservedQtyInfoList);
                        }

                        #region GHSLabelInfo

                        if (bomInfo.MaterialNum.Length > 0)
                        {
                            //Check whether the material exists in Label_GHS info, if it is there then fetch PPE code and hazard desc based on GHS HCode 
                            //MaterialGHSInfo materialGHSInfo = StagingService.GetGHSHandlingInfo(db, siteID, bomInfo.MaterialNum, true);
                            //bomInfo.GHSInfo = materialGHSInfo;
                            bomInfo.GHSInfo = iPAS_PalletInfo.PalletInfoBAL.GetMaterialGHSInfo(db, siteID, bomInfo.MaterialNum, true, false, true, false);
                        }

                        #endregion
                    }

                    bomInfoList.Add(bomInfo);
                }
                dataReaderBomInfo.Close();

                infoReader = PreweighDAL.GetPreweighNotesForProcessOrder(db, siteID, processOrderNumber);
                if (infoReader.Read())
                {
                    preWeighNotes = Common.GetSafeString(infoReader, "FPREWEIGHNOTES");
                }
                infoReader.Close();

                processOrderBOMInfo.ProcessOrderNumber = processOrderNumber;
                processOrderBOMInfo.PreweighNotes = preWeighNotes.Trim();
                processOrderBOMInfo.ProcessOrderBOMList = bomInfoList;
                processOrderBOMInfo.ProductionLineID = plineSetting.PLineID;

                return processOrderBOMInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching BOM info", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Orders: " + processOrderNumber + "; UserID: " + userID + "; SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderBomInfo != null && !dataReaderBomInfo.IsClosed)
                    dataReaderBomInfo.Close();

                if (infoReader != null && !infoReader.IsClosed)
                    infoReader.Close();
            }
        }

        private List<ReservedQtyInfo> GetReservedQtyInfoForLineItem(Database db, int siteID, string processOrderNumber, int lineItemNumber, string plineSupplyBin)
        {
            IDataReader infoReader = null;
            try
            {
                List<ReservedQtyInfo> reservedQtyInfoList = new List<ReservedQtyInfo>();
                infoReader = ManufactureDAL.GetReservedQtyInfoForPOLineItem(db, siteID, processOrderNumber, lineItemNumber);
                while (infoReader.Read())
                {
                    ReservedQtyInfo reservedQtyInfo = new ReservedQtyInfo();

                    reservedQtyInfo.ProcessOrder = Common.GetSafeString(infoReader, "FAUFNR");
                    reservedQtyInfo.Batch = Common.GetSafeString(infoReader, "FBATCH");
                    reservedQtyInfo.Quantity = Common.GetSafeDecimal(infoReader, "FRESERVEDQTY");
                    reservedQtyInfo.Unit = Common.GetSafeString(infoReader, "FUNIT");
                    reservedQtyInfo.QuantityWithUnit = reservedQtyInfo.Quantity.ToString().Trim() + " " + reservedQtyInfo.Unit;
                    reservedQtyInfo.SupplyBin = Common.GetSafeString(infoReader, "FSUPPLYBIN");
                    reservedQtyInfo.IsReservedPOQty = true;

                    if (reservedQtyInfo.SupplyBin == plineSupplyBin)
                    {
                        reservedQtyInfo.IsPOSupplyArea = true;
                    }

                    reservedQtyInfoList.Add(reservedQtyInfo);
                }
                infoReader.Close();

                return reservedQtyInfoList;
            }
            catch
            {
                throw;
            }
            finally
            {
                if (infoReader != null && !infoReader.IsClosed)
                    infoReader.Close();
            }
        }

        private List<ReservedQtyInfo> GetNonReservedQtyInfoForMaterial(Database db, int siteID, string materialNumber, string plineSupplyBin)
        {
            IDataReader infoReader = null;
            try
            {
                List<ReservedQtyInfo> reservedQtyInfoList = new List<ReservedQtyInfo>();
                infoReader = ManufactureDAL.GetNonReservedQtyInfoForMaterial(db, siteID, materialNumber, plineSupplyBin);
                while (infoReader.Read())
                {
                    decimal availableQty = Common.GetSafeDecimal(infoReader, "FRESERVEDQTY");

                    if (availableQty > 0)
                    {
                        ReservedQtyInfo reservedQtyInfo = new ReservedQtyInfo();

                        reservedQtyInfo.ProcessOrder = Common.GetSafeString(infoReader, "FAUFNR");
                        reservedQtyInfo.Batch = Common.GetSafeString(infoReader, "FBATCH");
                        reservedQtyInfo.Quantity = Common.GetSafeDecimal(infoReader, "FRESERVEDQTY");
                        reservedQtyInfo.Unit = Common.GetSafeString(infoReader, "FUNIT");
                        reservedQtyInfo.QuantityWithUnit = reservedQtyInfo.Quantity.ToString().Trim() + " " + reservedQtyInfo.Unit;
                        reservedQtyInfo.SupplyBin = Common.GetSafeString(infoReader, "FSUPPLYBIN");
                        reservedQtyInfo.IsReservedPOQty = false;
                        reservedQtyInfo.IsPOSupplyArea = true;

                        reservedQtyInfoList.Add(reservedQtyInfo);
                    }
                }
                infoReader.Close();

                return reservedQtyInfoList;
            }
            catch
            {
                throw;
            }
            finally
            {
                if (infoReader != null && !infoReader.IsClosed)
                    infoReader.Close();
            }
        }

        public AvailableBatchBinInfo GetAvailableBatchBinInfo(BasicParam basicInfo, StockFilterAdvance filterInfo)
        {
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                return GetAvailableBatchBinInfo(db, basicInfo, filterInfo);
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting available bins from SAP", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicInfo.SiteID);
                throw new FaultException(ex.Message);
            }

        }

        public static AvailableBatchBinInfo GetAvailableBatchBinInfo(Database db, BasicParam basicInfo, StockFilterAdvance filterInfo)
        {
            PlantSettings plantSetting = new PlantSettings();
            AvailableBatchBinInfo batchBinInfo = new AvailableBatchBinInfo();
            OrderPLineSettings plineSettings = new OrderPLineSettings();
            IDataReader dataReaderShelfLife = null;

            try
            {
                plantSetting = Common.GetPlantSettings(db, basicInfo.SiteID);

                if (plantSetting.WarehouseNumber.Trim().Length > 0)
                {
                    batchBinInfo.SapCurrentStatus = plantSetting.SapAvailabilityStatus;

                    string bapiMessage = string.Empty;
                    DataTable availableBinTable = new DataTable();

                    List<iPAS_PalletInfo.AvailableBinInfo> availableBinBatchInfoList = new List<iPAS_PalletInfo.AvailableBinInfo>();

                    List<iPAS_PalletInfo.AvailableBinInfo> availableWarehouseBinBatchInfoList = new List<iPAS_PalletInfo.AvailableBinInfo>();

                    if (plantSetting.SapAvailabilityStatus != SAPStatus.Down)
                    {
                        iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);


                        //This returns including intrim bins
                        List<iPAS_PalletInfo.AvailableBinInfo> availableBinInfoList = iPAS_PalletInfo.SAPBinBatchInfoBLL.GetAvailableBinListForBatch(db, basicInfo.SiteID, sapBapiClass, filterInfo.PlantCode
                                            , plantSetting.WarehouseNumber, filterInfo.MaterialNumber, filterInfo.StorageLocation, filterInfo.Batch, filterInfo.RequiredUOM, filterInfo.BinLocation, filterInfo.ClubSameBatch, filterInfo.IncludeQStock);

                        DataTable supplyAreaBinTable = new DataTable();
                        DataTable stagingAreaBinTable = new DataTable();

                        if (availableBinInfoList != null)
                        {
                            supplyAreaBinTable = StagingDAL.GetAllSupplyAreaForSite(db, basicInfo.SiteID);
                            stagingAreaBinTable = StagingDAL.GetAllStagingAreaForSite(db, basicInfo.SiteID);

                            //Get orders production line information
                            string processOrder = "'" + filterInfo.OrderNumber + "'";
                            plineSettings = Common.GetProductionLineSettings(db, basicInfo.SiteID, processOrder);

                            dataReaderShelfLife = StagingDAL.GetMaterialShelfLifeAndMovementIndicator(db, filterInfo.MaterialNumber, basicInfo.SiteID);
                            if (dataReaderShelfLife.Read())
                            {
                                //If material's movement indicator is B that means supply bin for that materials is Bulk supply area
                                string movementInd = Common.GetSafeString(dataReaderShelfLife, "FMOVIND");
                                if (movementInd == "B")
                                {
                                    plineSettings.SupplyBin = plineSettings.SupplyBulkBin;
                                    plineSettings.SupplyBulkArea = plineSettings.SupplyArea;
                                }
                            }
                            dataReaderShelfLife.Close();

                            if ((plineSettings.StagingBin == plineSettings.SupplyBin || plineSettings.StagingBin.Length == 0) && filterInfo.IncludeWarehouseBins == false)
                            {
                                filterInfo.IncludeWarehouseBins = true;
                            }

                            foreach (iPAS_PalletInfo.AvailableBinInfo binInfo in availableBinInfoList)
                            {
                                bool isSupplyAreaBin = false;
                                bool isStagingAreaBin = false;

                                DataRow[] supplyAreaBin = supplyAreaBinTable.Select(" FSTAGINGBIN= '" + binInfo.BinName.ToString().Trim().ToUpper() + "'");
                                if (supplyAreaBin.Length > 0)
                                {
                                    isSupplyAreaBin = true;
                                    binInfo.IsSupplyBin = true;
                                }

                                DataRow[] stagingAreaBin = stagingAreaBinTable.Select(" FSTAGINGBIN= '" + binInfo.BinName.ToString().Trim().ToUpper() + "'");
                                if (stagingAreaBin.Length > 0)
                                {
                                    isStagingAreaBin = true;
                                }

                                //If no stock in supply area or staging area then to consider warehouse bin
                                if (filterInfo.IncludeWarehouseBinsIfStockNotFound && isSupplyAreaBin == false && isStagingAreaBin == false)
                                {
                                    availableWarehouseBinBatchInfoList.Add(binInfo);
                                }

                                if (filterInfo.IncludeSupplyAreaBins == false && filterInfo.IncludeStagingAreaBins == false && filterInfo.IncludeWarehouseBins)
                                {
                                    if (isSupplyAreaBin == false && isStagingAreaBin == false)
                                    {
                                        availableBinBatchInfoList.Add(binInfo);
                                    }
                                }
                                else if (filterInfo.IncludeSupplyAreaBins == false && filterInfo.IncludeStagingAreaBins && filterInfo.IncludeWarehouseBins == false)
                                {
                                    if (plineSettings.StagingBin.Trim() == binInfo.BinName.ToString().Trim().ToUpper())
                                    {
                                        availableBinBatchInfoList.Add(binInfo);
                                    }
                                }
                                else if (filterInfo.IncludeSupplyAreaBins == false && filterInfo.IncludeStagingAreaBins && filterInfo.IncludeWarehouseBins)
                                {
                                    if (isSupplyAreaBin == false)
                                    {
                                        if (isStagingAreaBin == false || (isStagingAreaBin == true && plineSettings.StagingBin.Trim() == binInfo.BinName.ToString().Trim().ToUpper()))
                                        {
                                            availableBinBatchInfoList.Add(binInfo);
                                        }
                                    }
                                }
                                else if (filterInfo.IncludeSupplyAreaBins && filterInfo.IncludeStagingAreaBins == false && filterInfo.IncludeWarehouseBins == false)
                                {
                                    if (plineSettings.SupplyBin.Trim() == binInfo.BinName.ToString().Trim().ToUpper())
                                    {
                                        availableBinBatchInfoList.Add(binInfo);
                                    }
                                }
                                else if (filterInfo.IncludeSupplyAreaBins && filterInfo.IncludeStagingAreaBins == false && filterInfo.IncludeWarehouseBins)
                                {
                                    if (isStagingAreaBin == false)
                                    {
                                        if (isSupplyAreaBin == false || (isSupplyAreaBin == true && plineSettings.SupplyBin.Trim() == binInfo.BinName.ToString().Trim().ToUpper()))
                                        {
                                            availableBinBatchInfoList.Add(binInfo);
                                        }
                                    }
                                }
                                else if (filterInfo.IncludeSupplyAreaBins && filterInfo.IncludeStagingAreaBins && filterInfo.IncludeWarehouseBins == false)
                                {
                                    if ((plineSettings.SupplyBin.Trim() == binInfo.BinName.ToString().Trim().ToUpper()) || (plineSettings.StagingBin.Trim() == binInfo.BinName.ToString().Trim().ToUpper()))
                                    {
                                        availableBinBatchInfoList.Add(binInfo);
                                    }
                                }
                                else if (filterInfo.IncludeSupplyAreaBins && filterInfo.IncludeStagingAreaBins && filterInfo.IncludeWarehouseBins)
                                {
                                    availableBinBatchInfoList.Add(binInfo);
                                }
                            }

                            //This applies only when (IncludeStagingAreaBins=true OR IncludeSupplyAreaBins=true) and IncludeWarehouseBins=false but IncludeWarehouseBinsIfStockNotFound=true
                            if (availableBinBatchInfoList.Count == 0 && filterInfo.IncludeWarehouseBins == false && filterInfo.IncludeWarehouseBinsIfStockNotFound)
                            {
                                if (availableWarehouseBinBatchInfoList.Count > 0)
                                {
                                    availableBinBatchInfoList = availableWarehouseBinBatchInfoList;
                                }
                            }
                        }
                    }

                    batchBinInfo.AvailableBinInfo = availableBinBatchInfoList;
                    return batchBinInfo;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting available bins from SAP", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicInfo.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderShelfLife != null && !dataReaderShelfLife.IsClosed)
                    dataReaderShelfLife.Close();
            }
        }

        public ProcessOrderBOMInfo GetProcessOrderPhaseAdditions(int siteID, int userID, string processOrderNumber, bool showAllAdditions)
        {
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                PlantSettings plantSetting = new PlantSettings();

                //Get plant setting
                plantSetting = Common.GetPlantSettings(db, siteID);

                int lineItemNumber = 0;
                if (showAllAdditions == true)
                    lineItemNumber = 1;

                if (plantSetting.BatchDeterminationLogic == PlantBatchLogic.TRBased)
                    return FillProcessOrderBOMInfo(db, siteID, userID, processOrderNumber, "ADDITION", lineItemNumber);
                else
                    return FillProcessOrderBOMInfo(db, siteID, userID, processOrderNumber, lineItemNumber, true);
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting addition materials", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
        }

        public AvailableBatchBinInfo GetManufacturePreweighBinLocations(BasicParam basicInfo, POItemFilter filterInfo, StockFilterAdvance advanceFilterInfo)
        {
            //PREWEIGH DURING MANUFACTURE - WITHOUT TR
            IDataReader dataReaderPendingQty = null;

            string plantCode = string.Empty;
            decimal requiredQty = 0;
            decimal totalPreweighedQty = 0;
            string storageLocation = string.Empty;
            bool isBatchManaged = false;

            AvailableBatchBinInfo binInfo = new AvailableBatchBinInfo();

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                /* CR 2150 - 2016-June-20 - Sushin - Concentration based Staging Changes. Get the adjusted quantity for material based on concentration - Start  */
                //Get plant setting
                PlantSettings plantSetting = Common.GetPlantSettings(db, basicInfo.SiteID);
                OrderPLineSettings plineSetting = Common.GetProductionLineSettings(db, basicInfo.SiteID, advanceFilterInfo.OrderNumber);
                SAPStatus sapAvailabilityStatus = Common.GetSAPAvailabilityStatus(plantSetting.SapAvailabilityStatus, plineSetting.SAPStatus);
                iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);
                string additionalComment = string.Empty;

                dataReaderPendingQty = PreweighDAL.GetPreweighRequiredQtyForLineItem(db, advanceFilterInfo.OrderNumber, basicInfo.SiteID, filterInfo.Posnr, filterInfo.Vornr, advanceFilterInfo.MaterialNumber);
                if (dataReaderPendingQty.Read())
                {
                    requiredQty = Common.GetSafeDecimal(dataReaderPendingQty, "FQTY");
                    totalPreweighedQty = Common.GetSafeDecimal(dataReaderPendingQty, "FKITTEDQTY");
                    storageLocation = Common.GetSafeString(dataReaderPendingQty, "FLGORT");
                    plantCode = Common.GetSafeString(dataReaderPendingQty, "FWERKS");

                    if (Common.GetSafeString(dataReaderPendingQty, "FISBATCHMANAGED") == "Y")
                        isBatchManaged = true;

                    int lineItemNumber = Common.GetSafeInt32(dataReaderPendingQty, "FLINEITEM");
                    string posnr = Common.GetSafeString(dataReaderPendingQty, "FPOSNR");
                    string phaseNumber = Common.GetSafeString(dataReaderPendingQty, "FVORNR");
                    string materialNumber = Common.GetSafeString(dataReaderPendingQty, "FMATNR");
                    string unit = Common.GetSafeString(dataReaderPendingQty, "FUOM");
                    string movInd = Common.GetSafeString(dataReaderPendingQty, "FMOVIND");
                    bool isAddition = Common.GetSafeString(dataReaderPendingQty, "FISADDITION") == "Y" ? true : false;
                    int concentrationConfigVersionID = Common.GetSafeInt32(dataReaderPendingQty, "FCONCENTRATIONCONFIGVERSION");
                    dataReaderPendingQty.Close();

                    requiredQty = Common.GetAdjustedReqQtyForLineItemBasedOnConcentration(db, sapBapiClass, basicInfo.SiteID, plantSetting, plineSetting, advanceFilterInfo.OrderNumber
                        , lineItemNumber, phaseNumber, posnr, materialNumber, plantCode, storageLocation, movInd, requiredQty, totalPreweighedQty, unit, sapAvailabilityStatus
                        , isAddition, string.Empty, "S", false, ref concentrationConfigVersionID, ref additionalComment);
                }
                else
                {
                    dataReaderPendingQty.Close();
                }

                /* CR 2150 - 2016-June-20 - Sushin - Concentration based Staging Changes - End  */

                decimal pendingQty = requiredQty - totalPreweighedQty;
                if (pendingQty <= 0)
                {
                    return null;           //return NULL - preweigh is completed
                }

                advanceFilterInfo.IncludeWarehouseBinsIfStockNotFound = true;           //If stock not found in staging area then show warehouse bins
                binInfo = GetAvailableBatchBinInfo(db, basicInfo, advanceFilterInfo);
                binInfo.QtyPending = pendingQty;

                return binInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting available bins from SAP", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicInfo.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPendingQty != null && !dataReaderPendingQty.IsClosed)
                    dataReaderPendingQty.Close();
            }
        }

        public BinQtyInfo GetBinQuantity(BasicParam basicInfo, StockFilter filterInfo)
        {
            try
            {
                BinQtyInfo qtyInfo = new BinQtyInfo();
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                PlantSettings plantSetting = Common.GetPlantSettings(db, basicInfo.SiteID);


                qtyInfo.SapCurrentStatus = plantSetting.SapAvailabilityStatus;
                if (plantSetting.SapAvailabilityStatus != SAPStatus.Down)
                {
                    iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(basicInfo.LanguageCode);

                    qtyInfo.BinInfo = iPAS_PalletInfo.SAPBinBatchInfoBLL.GetBinQuantity(db, basicInfo.SiteID, sapBapiClass, filterInfo.PlantCode, plantSetting.WarehouseNumber
                        , filterInfo.MaterialNumber, filterInfo.Batch, filterInfo.BinLocation, filterInfo.StorageLocation, filterInfo.RequiredUOM, filterInfo.IncludeQStock);
                }

                return qtyInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "OrderInfoService", "Error while getting bin qty from SAP", "iPAS_GRService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicInfo.SiteID);
                throw new FaultException(ex.Message);
            }
        }

        /* CR 2150 - 2016-June-20 - Sushin - Concentration based Staging Changes. New method to get the pending quantity(kitting/mixing) based on concentration - Start  */
        public QuantityToleranceInfo GetPendingQtyForLineItemBasedOnConcentration(BasicParam basicParam, string processOrder, int lineItemNumber, string batchNumber, bool isKitting)
        {
            IDataReader dataReaderBomInfo = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                //Get plant setting
                PlantSettings plantSetting = Common.GetPlantSettings(db, basicParam.SiteID);
                OrderPLineSettings plineSetting = Common.GetProductionLineSettings(db, basicParam.SiteID, processOrder);
                SAPStatus sapAvailabilityStatus = Common.GetSAPAvailabilityStatus(plantSetting.SapAvailabilityStatus, plineSetting.SAPStatus);
                iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);
                string additionalComment = string.Empty;
                QuantityToleranceInfo qtyToleranceInfo = new QuantityToleranceInfo();

                dataReaderBomInfo = PreweighDAL.GetPOBOMInfoForPreweigh(db, basicParam.SiteID, processOrder, lineItemNumber, basicParam.UserID);
                if (dataReaderBomInfo.Read())
                {
                    decimal totalReqQty = Common.GetSafeDecimal(dataReaderBomInfo, "FQTY");
                    decimal alreadyKittedQty = Common.GetSafeDecimal(dataReaderBomInfo, "FKITTEDQTY");
                    decimal alreadyMixedQty = Common.GetSafeDecimal(dataReaderBomInfo, "FMIXQTY");

                    string mode = isKitting == true ? "S" : "M";
                    decimal alreadyKitOrMixQty = isKitting == true ? alreadyKittedQty : alreadyMixedQty;

                    string posnr = Common.GetSafeString(dataReaderBomInfo, "FPOSNR");
                    string phaseNumber = Common.GetSafeString(dataReaderBomInfo, "FVORNR");
                    string plantCode = Common.GetSafeString(dataReaderBomInfo, "FWERKS");
                    string materialNumber = Common.GetSafeString(dataReaderBomInfo, "FIDHID");
                    string storageLocation = Common.GetSafeString(dataReaderBomInfo, "FLGORT");
                    string unit = Common.GetSafeString(dataReaderBomInfo, "FUOM");
                    string movInd = Common.GetSafeString(dataReaderBomInfo, "FMOVIND");
                    bool isAddition = Common.GetSafeString(dataReaderBomInfo, "FISADDITION") == "Y" ? true : false;
                    int concentrationConfigVersionID = Common.GetSafeInt32(dataReaderBomInfo, "FCONCENTRATIONCONFIGVERSION");
                    dataReaderBomInfo.Close();

                    totalReqQty = Common.GetAdjustedReqQtyForLineItemBasedOnConcentration(db, sapBapiClass, basicParam.SiteID, plantSetting, plineSetting, processOrder, lineItemNumber, phaseNumber, posnr, materialNumber, plantCode, storageLocation, movInd, totalReqQty
                        , alreadyKitOrMixQty, unit, sapAvailabilityStatus, isAddition, batchNumber, mode, true, ref concentrationConfigVersionID, ref additionalComment);
                    decimal pendigQty = totalReqQty - alreadyKitOrMixQty;

                    qtyToleranceInfo.TotalReqQty = totalReqQty;
                    qtyToleranceInfo.PendingQty = pendigQty;

                    //Calculate the Min and Max Tolerance value for required qty
                    decimal qtyMaxDifference = 0;
                    decimal toleranceValue = (decimal)Common.GetTolerenceValue((double)totalReqQty, plineSetting.ToleranceID, ref qtyMaxDifference);
                    qtyToleranceInfo.MaxTolerance = pendigQty + toleranceValue;
                    qtyToleranceInfo.MaxTolerance = Math.Round(qtyToleranceInfo.MaxTolerance, 3);

                    qtyToleranceInfo.MinTolerance = (pendigQty - toleranceValue) < 0 ? 0 : (pendigQty - toleranceValue);
                    qtyToleranceInfo.MinTolerance = Math.Round(qtyToleranceInfo.MinTolerance, 3);
                }
                dataReaderBomInfo.Close();

                return qtyToleranceInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting peding kitting/mixing required qty for concentrated material", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicParam.SiteID.ToString().Trim() + ";PO: " + processOrder.Trim() + ";Line Item: " + lineItemNumber.ToString().Trim() + ";Batch: " + batchNumber.Trim());
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderBomInfo != null && !dataReaderBomInfo.IsClosed)
                    dataReaderBomInfo.Close();
            }
        }
        /* CR 2150 - 2016-June-20 - Sushin - Concentration based Staging Changes - End  */

        #endregion

        #region Manufacture - Packaging Pick

        public AvailableBatchBinInfo GetPackagingMaterialLocation(BasicParam basicInfo, PackageMaterialBinFilter filterInfo)
        {
            IDataReader dataReaderPendingQty = null;
            IDataReader dataReaderProcessOrder = null;
            IDataReader dataReaderShelfLife = null;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                string plantCode = string.Empty;

                //Returns available bin batches based on filter condition
                AvailableBatchBinInfo allBatchBinInfo = GetAvailableBatchBinInfo(db, basicInfo, filterInfo);

                //Exclude stock issue bins
                AvailableBatchBinInfo batchBinInfo = ExcludeErrorLogBins(db, basicInfo.SiteID, allBatchBinInfo);

                //sort it so that consignment stock goes down after sort
                AvailableBatchBinInfo sortBinBatch = new AvailableBatchBinInfo();
                sortBinBatch.SapCurrentStatus = allBatchBinInfo.SapCurrentStatus;

                if (batchBinInfo.AvailableBinInfo.Count > 0)
                {
                    foreach (iPAS_PalletInfo.AvailableBinInfo binBatchInfo in batchBinInfo.AvailableBinInfo)
                    {
                        if (binBatchInfo.StockType.Length == 0)
                        {
                            sortBinBatch.AvailableBinInfo.Add(binBatchInfo);
                        }
                    }

                    foreach (iPAS_PalletInfo.AvailableBinInfo binBatchInfo in batchBinInfo.AvailableBinInfo)
                    {
                        if (binBatchInfo.StockType.Length > 0)
                        {
                            sortBinBatch.AvailableBinInfo.Add(binBatchInfo);
                        }
                    }
                }

                if (filterInfo.FilterType == PackageMaterialBinFilterType.Replenishment)
                {
                    return sortBinBatch;
                }
                else
                {
                    decimal requiredQty = 0;
                    decimal totalConsumedQty = 0;
                    string materialNumber = string.Empty;
                    string materialType = string.Empty;
                    ProcessOrderType processOrderFillingType = ProcessOrderType.Filling;

                    dataReaderPendingQty = PreweighDAL.GetRequiredPackagingQtyForLineItem(db, basicInfo.SiteID, filterInfo.OrderNumber, filterInfo.LineItemNumber);
                    if (dataReaderPendingQty.Read())
                    {
                        requiredQty = Common.GetSafeDecimal(dataReaderPendingQty, "FQTY");
                        totalConsumedQty = Common.GetSafeDecimal(dataReaderPendingQty, "FCONSUMEDQTY");
                        plantCode = Common.GetSafeString(dataReaderPendingQty, "FWERKS");
                        materialNumber = Common.GetSafeString(dataReaderPendingQty, "FIDHID");
                        materialType = Common.GetSafeString(dataReaderPendingQty, "FTYPE");
                    }
                    dataReaderPendingQty.Close();

                    string processOrderList = "'" + filterInfo.OrderNumber + "'";
                    OrderPLineSettings plineSetting = Common.GetProductionLineSettings(db, basicInfo.SiteID, processOrderList);

                    dataReaderShelfLife = StagingDAL.GetMaterialShelfLifeAndMovementIndicator(db, filterInfo.MaterialNumber, basicInfo.SiteID);
                    if (dataReaderShelfLife.Read())
                    {
                        //If material's movement indicator is B that means supply bin for that materials is Bulk supply area
                        string movementInd = Common.GetSafeString(dataReaderShelfLife, "FMOVIND");
                        if (movementInd == "B")
                        {
                            plineSetting.SupplyBin = plineSetting.SupplyBulkBin;
                            plineSetting.SupplyBulkArea = plineSetting.SupplyArea;
                        }
                    }
                    dataReaderShelfLife.Close();

                    //if not packaging material and process order is of type in-direct filling without mixer then RM materials will be staged. Hence 
                    //only staged batch & their location has to be shown. T01F with SOP and no bulk link - > these types of orders will staged first
                    if (materialType.Trim() != "P")
                    {
                        dataReaderProcessOrder = ManufactureDAL.GetFillingProcessOrderInfo(db, basicInfo.SiteID, filterInfo.OrderNumber);
                        if (dataReaderProcessOrder.Read())
                        {
                            string bulkProcessOrder = Common.GetSafeString(dataReaderProcessOrder, "FBULKPO");

                            string poResource = Common.GetSafeString(dataReaderProcessOrder, "FFILLINGCATEGORY");
                            string poOrderType = Common.GetSafeString(dataReaderProcessOrder, "FFILLINGPOORDERTYPE");
                            string reworkResourceFlag = Common.GetSafeString(dataReaderProcessOrder, "FISWORKRESOURCE");

                            ProcessOrderType poType = Common.GetProcessOrderOrderType(poOrderType, poResource, reworkResourceFlag);

                            processOrderFillingType = poType;
                            if (poType == ProcessOrderType.Filling && bulkProcessOrder == filterInfo.OrderNumber)
                            {
                                processOrderFillingType = ProcessOrderType.IndirectFilling;
                            }
                        }
                        dataReaderProcessOrder.Close();

                        if (processOrderFillingType == ProcessOrderType.IndirectFilling)
                        {
                            //Consider only staged batch & their bin
                            DataTable dtKittedBatch = ManufactureDAL.GetKittedBatchInfoForPOLineItem(db, basicInfo.SiteID, filterInfo.OrderNumber, filterInfo.LineItemNumber);
                            if (dtKittedBatch.Rows.Count > 0)
                            {
                                //loop through list and remove batches which are not kitted
                                List<iPAS_PalletInfo.AvailableBinInfo> kittedBatchList = new List<iPAS_PalletInfo.AvailableBinInfo>();

                                //Also consider only supply bin stock
                                List<iPAS_PalletInfo.AvailableBinInfo> supplyBinList = sortBinBatch.AvailableBinInfo.FindAll(a => a.BinName == plineSetting.SupplyBin);

                                foreach (iPAS_PalletInfo.AvailableBinInfo stockInfo in supplyBinList)
                                {
                                    DataRow[] drMatchBatch = dtKittedBatch.Select(" FMATNR = '" + stockInfo.MaterialNumber + "' AND FCHARG='" + stockInfo.BatchNumber + "' ");
                                    if (drMatchBatch.Length > 0)
                                    {
                                        kittedBatchList.Add(stockInfo);
                                    }
                                }

                                sortBinBatch.AvailableBinInfo = kittedBatchList;
                            }
                        }
                    }

                    AvailableBatchBinInfo psaSortedBins = new AvailableBatchBinInfo();

                    if (sortBinBatch.AvailableBinInfo.Count > 0)
                    {
                        //This is show first PSA location packaging material & then rest
                        List<iPAS_PalletInfo.AvailableBinInfo> supplyBinList = sortBinBatch.AvailableBinInfo.FindAll(a => a.BinName == plineSetting.SupplyBin);
                        if (supplyBinList.Count > 0)
                        {
                            supplyBinList = supplyBinList.OrderBy(x => x.ExpiryDate).ToList();
                            psaSortedBins.AvailableBinInfo = supplyBinList;
                        }

                        foreach (iPAS_PalletInfo.AvailableBinInfo binInfo in sortBinBatch.AvailableBinInfo)
                        {
                            if (binInfo.BinName != plineSetting.SupplyBin)
                            {
                                psaSortedBins.AvailableBinInfo.Add(binInfo);
                            }
                        }
                    }

                    psaSortedBins.SapCurrentStatus = sortBinBatch.SapCurrentStatus;
                    psaSortedBins.QtyPending = totalConsumedQty;
                    return psaSortedBins;
                }
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting available bins from SAP", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicInfo.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPendingQty != null && !dataReaderPendingQty.IsClosed)
                    dataReaderPendingQty.Close();

                if (dataReaderProcessOrder != null && !dataReaderProcessOrder.IsClosed)
                    dataReaderProcessOrder.Close();


                if (dataReaderShelfLife != null && !dataReaderShelfLife.IsClosed)
                    dataReaderShelfLife.Close();
            }
        }

        private AvailableBatchBinInfo ExcludeErrorLogBins(Database db, int siteID, AvailableBatchBinInfo batchBinInfo)
        {
            //Exludes batch/bins on which error is reported
            string currentBatch = string.Empty;
            string prevBatch = string.Empty;
            string currentBin = string.Empty;

            DataTable stockErrorTable = new DataTable();
            AvailableBatchBinInfo excludedBatchBinInfo = new AvailableBatchBinInfo();

            foreach (iPAS_PalletInfo.AvailableBinInfo binInfo in batchBinInfo.AvailableBinInfo)
            {
                currentBatch = binInfo.BatchNumber;
                if (currentBatch != prevBatch || prevBatch == string.Empty)
                {
                    //check if any error is logged against the material/batch for this bin
                    stockErrorTable = StagingDAL.GetStockLogErrorInfoForMaterialBatch(db, siteID, binInfo.MaterialNumber, currentBatch);//Get stock error log for the material and batch if exists
                }

                currentBin = binInfo.BinName.ToUpper();

                DataRow[] errorBinRow = null;
                if (stockErrorTable.Rows.Count > 0)
                    errorBinRow = stockErrorTable.Select("FBIN = '" + currentBin + "'");

                //Do not consider bins which already reported stock error for the material and batch.
                if (errorBinRow == null || errorBinRow.Length == 0)
                {
                    excludedBatchBinInfo.AvailableBinInfo.Add(binInfo);
                }

                prevBatch = currentBatch;
            }

            return excludedBatchBinInfo;
        }

        public bool DoReplenishmentOfPackagingMaterial(PackagingMaterialReplenishInfo replenishmentInfo)
        {

            IDataReader warehouseNumberReader = null;
            try
            {
                List<SAPQueueID> sapQueueList = new List<SAPQueueID>();
                PlantSettings plantSetting = new PlantSettings();
                OrderPLineSettings plineSetting = null;

                int currentDate = 0;
                int currentTime = 0;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, replenishmentInfo.SiteID, ref currentDate, ref currentTime);

                string warehouseNumber = string.Empty;
                string plantCode = string.Empty;

                warehouseNumberReader = CommonDAL.GetWareHouseNumberAndPlantCodeForSite(db, replenishmentInfo.SiteID);
                if (warehouseNumberReader.Read())
                {
                    warehouseNumber = Common.GetSafeString(warehouseNumberReader, "FWAREHOUSENUMBER");
                    plantCode = Common.GetSafeString(warehouseNumberReader, "FSAPPLANTCODE");
                }
                warehouseNumberReader.Close();

                plantSetting = Common.GetPlantSettings(db, replenishmentInfo.SiteID);

                if (replenishmentInfo.PlantCode != null && replenishmentInfo.PlantCode.Trim().Length > 0)
                    plantCode = replenishmentInfo.PlantCode;

                plineSetting = Common.GetProductionLineSettings(db, replenishmentInfo.PLineID, replenishmentInfo.SiteID);

                string labelNumber = replenishmentInfo.LabelNumber;

                DbTransaction transaction;
                using (DbConnection connection = db.CreateConnection())
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();
                    try
                    {
                        decimal totalPickedQty = 0;
                        string unit = string.Empty;

                        SAPStatus sapAvailabilityStatus = Common.GetSAPAvailabilityStatus(plantSetting.SapAvailabilityStatus, plineSetting.SAPStatus);
                        bool markForceCompleted = false;
                        if (sapAvailabilityStatus == SAPStatus.Down)
                        {
                            markForceCompleted = true;
                        }


                        foreach (iPAS_PalletInfo.AvailableBinInfo binbatchInfo in replenishmentInfo.PickedBinBatchInfo)
                        {
                            //Insert Bin to Bin info in queue
                            SAPQueueID queueID = new SAPQueueID();

                            queueID.QueueID = CommonDAL.InsertSAPTransactionQueue(db, transaction, replenishmentInfo.SiteID, warehouseNumber
                                , plantCode, "B2B", string.Empty, 0, 0, 0, replenishmentInfo.MaterialNumber
                                , binbatchInfo.BatchNumber, replenishmentInfo.IsBatchManaged, binbatchInfo.StorageLocation, string.Empty
                                , binbatchInfo.Quantity, binbatchInfo.UOM, binbatchInfo.BinName, binbatchInfo.StorageType
                                , plineSetting.SupplyBin, plineSetting.SupplyArea, binbatchInfo.VendorNumber
                                , binbatchInfo.StockType, currentDate, currentTime, replenishmentInfo.UserID, 'N', 0, markForceCompleted
                                , (char)sapAvailabilityStatus, 0, 'A', 'N', string.Empty, string.Empty, string.Empty, 0, 0);

                            sapQueueList.Add(queueID);

                            totalPickedQty = totalPickedQty + binbatchInfo.Quantity;
                            unit = binbatchInfo.UOM;
                        }

                        if (replenishmentInfo.PrintRequest != null && replenishmentInfo.PrintRequest.NumberOfLabels == 0)
                        {
                            StagingDAL.UpdateCurrentBinForPallet(db, transaction, replenishmentInfo.SiteID, replenishmentInfo.LabelNumber, plineSetting.SupplyBin);
                        }
                        //else
                        //{
                        //    //Create new label
                        //    printNewLabel = true;
                        //    labelNumber = StagingDAL.GetNextPalletLabelNum(db, replenishmentInfo.SiteID);
                        //    StagingDAL.CreateNewPalletForPartialTransfer(db, transaction, replenishmentInfo.SiteID, replenishmentInfo.LabelNumber, labelNumber, totalPickedQty, unit, plineSetting.SupplyBin, currentDate, 'B');
                        //}

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        connection.Close();
                    }
                }

                //if (printNewLabel)
                //{
                //    //Print new label
                //    StagingService.PrintLabelsForPallet printLabel = new StagingService.PrintLabelsForPallet(StagingService.PrintSingleLabel);
                //    AsyncCallback cb = new AsyncCallback(Send);
                //    IAsyncResult ar = printLabel.BeginInvoke(db, replenishmentInfo.SiteID, replenishmentInfo.UserID, labelNumber, replenishmentInfo.PrintRequest, cb, null);
                //}

                //if (sapQueueList.Count > 0)
                //{
                //    Common.PerformSAPQueueOperation order = new Common.PerformSAPQueueOperation(Common.ProcessSAPQueueOperation);
                //    AsyncCallback cb = new AsyncCallback(Send);
                //    IAsyncResult ar = order.BeginInvoke(replenishmentInfo.SiteID, sapQueueList, cb, null);
                //}

                return true;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "ManufactureService", "Error while doing replenishment of packaging material", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + replenishmentInfo.SiteID + "; UserID: " + replenishmentInfo.UserID + ";Material Num: " + replenishmentInfo.MaterialNumber);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (warehouseNumberReader != null && !warehouseNumberReader.IsClosed)
                    warehouseNumberReader.Close();
            }
        }

        public int DoReplenishmentOfProcessOrder(PackagingPOReplenishInfo replenishmentInfo)
        {
            IDataReader dataReaderCompleteCheck = null;
            IDataReader dataReaderHeaderInfo = null;

            try
            {
                List<SAPQueueID> sapQueueList = new List<SAPQueueID>();
                PlantSettings plantSetting = new PlantSettings();
                OrderPLineSettings plineSetting = null;
                bool markForceCompleted = false;
                DataTable availBinTable = new DataTable();
                decimal availableQty = 0;

                int currentDate = 0;
                int currentTime = 0;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, replenishmentInfo.SiteID, ref currentDate, ref currentTime);

                plantSetting = Common.GetPlantSettings(db, replenishmentInfo.SiteID);

                plineSetting = Common.GetProductionLineSettings(db, replenishmentInfo.PLineID, replenishmentInfo.SiteID);

                SAPStatus sapAvailabilityStatus = Common.GetSAPAvailabilityStatus(plantSetting.SapAvailabilityStatus, plineSetting.SAPStatus);

                if (sapAvailabilityStatus == SAPStatus.Down)
                {
                    markForceCompleted = true;
                    availableQty = replenishmentInfo.PickedBinBatchInfo[0].Quantity;
                }
                else
                {
                    iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(replenishmentInfo.LanguageCode);

                    //iPAS_PalletInfo.AvailableBinInfo S = new iPAS_PalletInfo.AvailableBinInfo();
                    //S.BatchNumber = "0001079772";
                    //S.BinName = "PAK_ACH";
                    //S.Quantity = 2;
                    //S.UOM = "ST";
                    //S.MaterialNumber = "000000000001251892";
                    //S.StorageType = "PAK";

                    //replenishmentInfo.PickedBinBatchInfo.Add(S);

                    availBinTable = sapBapiClass.GetBinQuantityIncludingIntrimBins(replenishmentInfo.MaterialNumber, replenishmentInfo.PlantCode, replenishmentInfo.PickedBinBatchInfo[0].BinName
                        , replenishmentInfo.PickedBinBatchInfo[0].BatchNumber, plantSetting.WarehouseNumber);


                    for (int row = 0; row < availBinTable.Rows.Count; row++)
                    {
                        string binName = availBinTable.Rows[row]["LGPLA"].ToString().Trim().ToUpper();
                        string batch = availBinTable.Rows[row]["CHARG"].ToString().Trim().ToUpper();
                        string materialNum = availBinTable.Rows[row]["MATNR"].ToString().Trim().PadLeft(18, '0');
                        string bestQ = availBinTable.Rows[row]["BESTQ"].ToString().Trim();
                        string storageType = availBinTable.Rows[row]["LGTYP"].ToString().Trim();

                        if (bestQ == string.Empty && storageType.Trim().ToUpper() == replenishmentInfo.PickedBinBatchInfo[0].StorageType && binName.Trim().ToUpper() == replenishmentInfo.PickedBinBatchInfo[0].BinName.Trim().ToUpper() && batch.Trim().ToUpper() == replenishmentInfo.PickedBinBatchInfo[0].BatchNumber.Trim().ToUpper() && materialNum == replenishmentInfo.PickedBinBatchInfo[0].MaterialNumber.Trim().PadLeft(18, '0'))
                        {
                            availableQty = availableQty + Convert.ToDecimal(availBinTable.Rows[row]["VERME"].ToString());
                        }
                    }

                    //PENDING TO DO

                    //DataRow[] drFilter = dtPendingStagingTransactionQty.Select(" FCHARG ='" + batchNum + "' ");
                    //foreach (DataRow batchRow in drFilter)
                    //{
                    //    string uom = batchRow["FUOM"].ToString();
                    //    decimal usedQty = Convert.ToDecimal(batchRow["FQTY"].ToString());
                    //    if (uom.ToUpper() != kitItemInfo.Unit.ToUpper())
                    //    {
                    //        try
                    //        {
                    //            usedQty = sapBapiClass.UnitConversion(batchRow["FMATNR"].ToString(), uom, kitItemInfo.Unit, usedQty);
                    //        }
                    //        catch
                    //        {
                    //        }
                    //    }
                    //    availableQty = availableQty - usedQty;
                    //}
                }

                if (availableQty < replenishmentInfo.PickedBinBatchInfo[0].Quantity)
                {
                    //Return Error code - Not enough stock
                    return 1;
                }

                DataTable orderItemTable = PreweighDAL.GetStagingRequiredPackagingMaterial(db, replenishmentInfo.SiteID, replenishmentInfo.ProcessOrder, replenishmentInfo.MaterialNumber);
                if (orderItemTable.Rows.Count == 0)
                {
                    //No items to replenish
                    return 2;
                }

                DbTransaction transaction;
                using (DbConnection connection = db.CreateConnection())
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();
                    try
                    {
                        ProcessOrderStatus hdrStatus = ProcessOrderStatus.Not_Started;
                        decimal assignQty = 0;
                        int lineItemNumber = 0;
                        decimal itemQty = 0;
                        decimal itemPickedQty = 0;
                        decimal itemReqQty = 0;
                        string pickStatus = string.Empty;
                        List<OrderPickedItemInfo> orderPickedItemList = new List<OrderPickedItemInfo>();
                        OrderPickedItemInfo orderPickedItem;

                        string pickedUOM = replenishmentInfo.PickedBinBatchInfo[0].UOM;
                        decimal confirmedQty = replenishmentInfo.PickedBinBatchInfo[0].Quantity;


                        for (int i = 0; i < orderItemTable.Rows.Count; i++)
                        {
                            int.TryParse(orderItemTable.Rows[i]["FLINEITEM"].ToString(), out lineItemNumber);
                            decimal.TryParse(orderItemTable.Rows[i]["FQTY"].ToString(), out itemQty);
                            decimal.TryParse(orderItemTable.Rows[i]["FPICKEDQTY"].ToString(), out itemPickedQty);

                            itemReqQty = itemQty - itemPickedQty;

                            //If last line item then assign whole confirmed qty, because it is allowed to pick more
                            if (confirmedQty >= itemReqQty)
                            {
                                if (i == (orderItemTable.Rows.Count - 1))
                                {
                                    assignQty = confirmedQty;
                                    confirmedQty = 0;
                                }
                                else
                                {
                                    assignQty = itemReqQty;
                                    confirmedQty = confirmedQty - itemReqQty;
                                }

                                pickStatus = "C";   //Completed
                            }
                            else
                            {
                                assignQty = confirmedQty;
                                confirmedQty = 0;
                                pickStatus = "S";   //In Progress
                            }


                            StagingService.UpdatePickItemInfoForProcessOrder(db, transaction, replenishmentInfo.ProcessOrder, lineItemNumber, replenishmentInfo.MaterialNumber, replenishmentInfo.PickedBinBatchInfo[0].BatchNumber
                                   , replenishmentInfo.PickedBinBatchInfo[0].BinName, replenishmentInfo.PickedBinBatchInfo[0].StorageType, assignQty, pickedUOM, replenishmentInfo.UserID, replenishmentInfo.PickStartDate
                                   , replenishmentInfo.PickStartTime, currentDate, currentTime, false);


                            dataReaderHeaderInfo = PreweighDAL.CheckHeaderPickStatus(db, transaction, replenishmentInfo.ProcessOrder);

                            if (dataReaderHeaderInfo.Read())
                            {
                                hdrStatus = Common.GetProcessOrderStatus(Common.GetSafeString(dataReaderHeaderInfo, "FHDRSTATUS"));
                            }

                            dataReaderHeaderInfo.Close();

                            if (hdrStatus == ProcessOrderStatus.Not_Started)
                            {
                                StagingDAL.UpdateHeaderPickStatusToStarted(db, transaction, replenishmentInfo.ProcessOrder, currentDate, currentTime, replenishmentInfo.UserID);
                            }

                            StagingDAL.UpdateLineItemStatus(db, transaction, replenishmentInfo.ProcessOrder, lineItemNumber, pickStatus);


                            SAPQueueID queueID = new SAPQueueID();
                            queueID.QueueID = CommonDAL.InsertSAPTransactionQueue(db, transaction, replenishmentInfo.SiteID, plantSetting.WarehouseNumber
                                   , replenishmentInfo.PlantCode, "B2B", replenishmentInfo.ProcessOrder, lineItemNumber, 0, 0, replenishmentInfo.MaterialNumber
                                   , replenishmentInfo.PickedBinBatchInfo[0].BatchNumber, replenishmentInfo.IsBatchManaged, replenishmentInfo.PickedBinBatchInfo[0].StorageLocation, string.Empty
                                   , replenishmentInfo.PickedBinBatchInfo[0].Quantity, replenishmentInfo.PickedBinBatchInfo[0].UOM, replenishmentInfo.PickedBinBatchInfo[0].BinName, replenishmentInfo.PickedBinBatchInfo[0].StorageType
                                   , plineSetting.SupplyBin, plineSetting.SupplyArea, replenishmentInfo.PickedBinBatchInfo[0].VendorNumber
                                   , replenishmentInfo.PickedBinBatchInfo[0].StockType, currentDate, currentTime, replenishmentInfo.UserID, 'N', 0
                                   , markForceCompleted, (char)sapAvailabilityStatus, 0, 'A', 'N', string.Empty, string.Empty, string.Empty, 0, 0);


                            CommonDAL.LogProcessTransactionLog(db, transaction, replenishmentInfo.ProcessOrder, ProcessTransactionLog.Pallet_Picked.ToString()
                            , "Pallet (" + replenishmentInfo.LabelNumber + ") Picked For Material (" + lineItemNumber.ToString() + "):" + replenishmentInfo.MaterialNumber + ", Batch: " + replenishmentInfo.PickedBinBatchInfo[0].BatchNumber + ", Bin: " + replenishmentInfo.PickedBinBatchInfo[0].BinName + ", Qty: " + assignQty.ToString().Trim() + ". Moved to supply bin:" + plineSetting.SupplyBin.Trim()
                            , replenishmentInfo.UserID, currentDate, currentTime);

                            if (confirmedQty == 0)
                                break;
                        }


                        bool isComplete = false;
                        dataReaderCompleteCheck = StagingDAL.GetNotPreweighedBOM(db, transaction, replenishmentInfo.SiteID, replenishmentInfo.ProcessOrder, true);
                        if (!dataReaderCompleteCheck.Read())
                        {
                            isComplete = true;
                        }
                        dataReaderCompleteCheck.Close();

                        //Mark process order header status as complete if pre-weigh is completed for all BOM
                        if (isComplete)
                        {
                            //Pre-weigh completed
                            /* If header status is 'P' then update header status  to pre-weigh complete 'C'.
                                * condition added for preweigh done in manufacture */

                            int recordUpdated = StagingDAL.UpdateHeaderPickStatusToCompleted(db, transaction, replenishmentInfo.ProcessOrder, currentDate, currentTime, true);

                            if (recordUpdated > 0)
                            {
                                CommonDAL.LogProcessTransactionLog(db, transaction, replenishmentInfo.ProcessOrder, ProcessTransactionLog.Preweigh_Completed.ToString()
                                , "Staging completed for process order", replenishmentInfo.UserID, currentDate, currentTime);
                            }
                        }

                        if (replenishmentInfo.PrintRequest != null && replenishmentInfo.PrintRequest.NumberOfLabels == 0)
                        {
                            StagingDAL.UpdateCurrentBinForPallet(db, transaction, replenishmentInfo.SiteID, replenishmentInfo.LabelNumber, plineSetting.SupplyBin);
                        }

                        transaction.Commit();
                        return 0;

                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        if (dataReaderCompleteCheck != null && !dataReaderCompleteCheck.IsClosed)
                            dataReaderCompleteCheck.Close();

                        if (dataReaderHeaderInfo != null && !dataReaderHeaderInfo.IsClosed)
                            dataReaderHeaderInfo.Close();

                        connection.Close();
                    }

                }

            }
            catch (Exception ex)
            {
                Common.LogException(ex, "ManufactureService", "Error while doing replenishment of packaging material", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + replenishmentInfo.SiteID + "; UserID: " + replenishmentInfo.UserID + ";Material Num: " + replenishmentInfo.MaterialNumber);
                throw new FaultException(ex.Message);
            }
        }

        public bool DoPreweighForPackagingMaterial(PreweighInfo preweighInfo)
        {
            IDataReader dataReaderPOLineInfo = null;
            //IDataReader dataReaderStagingInfo = null;

            int lineItemNumber = 0;
            bool isExistStageInfo = false;
            string uom = string.Empty;
            PlantSettings plantSetting = new PlantSettings();
            List<SAPQueueID> sapQueueList = new List<SAPQueueID>();

            try
            {
                int currentdate = 0;
                int currentTime = 0;
                decimal totalReqQty = 0;
                decimal totalPreweighedQty = 0;
                decimal totalConsumedQty = 0;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                Common.GetCurrentSiteDateTime(db, preweighInfo.SiteID, ref currentdate, ref currentTime);

                SAPTransactionQueueItemBasicInfo itemInfoForBintoBin = new SAPTransactionQueueItemBasicInfo();

                //Get plant setting
                plantSetting = Common.GetPlantSettings(db, preweighInfo.SiteID);

                System.Data.Common.DbTransaction transaction;
                using (System.Data.Common.DbConnection connection = db.CreateConnection())
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();
                    try
                    {

                        dataReaderPOLineInfo = PreweighDAL.GetProcessOrderLineItemInfo(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, preweighInfo.SiteID);

                        if (dataReaderPOLineInfo.Read())
                        {
                            totalReqQty = Common.GetSafeDecimal(dataReaderPOLineInfo, "FQTY");
                            totalPreweighedQty = Common.GetSafeDecimal(dataReaderPOLineInfo, "FPICKEDQTY");
                            totalConsumedQty = Common.GetSafeDecimal(dataReaderPOLineInfo, "FCONSUMEDQTY");

                            lineItemNumber = Common.GetSafeInt32(dataReaderPOLineInfo, "FLINEITEM");
                            uom = Common.GetSafeString(dataReaderPOLineInfo, "FUOM");

                            //Assign item info
                            itemInfoForBintoBin.LineItemNumber = lineItemNumber;
                            itemInfoForBintoBin.Material = Common.GetSafeString(dataReaderPOLineInfo, "FMATNR");
                            itemInfoForBintoBin.ReservationNumber = Common.GetSafeInt32(dataReaderPOLineInfo, "FRSNUM");

                            //for manually added additions & balance MES keeps reservation item number > 9000 but reservation number as zero;do not pass MES generated number
                            if (itemInfoForBintoBin.ReservationNumber > 0)
                                itemInfoForBintoBin.ReservationItemNumber = Common.GetSafeInt32(dataReaderPOLineInfo, "FRSPOS");
                            else
                                itemInfoForBintoBin.ReservationItemNumber = 0;

                            itemInfoForBintoBin.StorageLocation = Common.GetSafeString(dataReaderPOLineInfo, "FLGORT");
                            itemInfoForBintoBin.IsBatchManaged = Common.GetSafeString(dataReaderPOLineInfo, "FISBATCHMANAGED") == "Y" ? true : false;
                            itemInfoForBintoBin.MovementIndication = Common.GetSafeString(dataReaderPOLineInfo, "FMOVIND");
                            itemInfoForBintoBin.PlantCode = Common.GetSafeString(dataReaderPOLineInfo, "FWERKS");
                        }
                        dataReaderPOLineInfo.Close();

                        //Move material to supply area
                        OrderPLineSettings plineSettings = new OrderPLineSettings();

                        plineSettings = Common.GetProductionLineSettings(db, preweighInfo.SiteID, preweighInfo.ProcessOrder);
                        if (itemInfoForBintoBin.MovementIndication == "B")
                        {
                            itemInfoForBintoBin.ToBinLocation = plineSettings.SupplyBulkBin;
                            itemInfoForBintoBin.ToBinType = plineSettings.SupplyBulkArea;
                        }
                        else
                        {
                            itemInfoForBintoBin.ToBinLocation = plineSettings.SupplyBin;
                            itemInfoForBintoBin.ToBinType = plineSettings.SupplyArea;
                        }

                        #region StockAdjustment
                        if (preweighInfo.Bin == itemInfoForBintoBin.ToBinLocation && preweighInfo.StorageType == itemInfoForBintoBin.ToBinType)
                        {
                            //This means stock is taken from supply bin. If reservation was made for that IDH then do PSA stock adjustment
                            //Check is there any reservation for this lineitem in LDB1_PO_KITITEMINFO table
                            DataTable dtCheckReservation = ManufactureDAL.CheckReservationExistsForLineItem(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber);
                            if (dtCheckReservation.Rows.Count > 0)
                            {
                                decimal mixedQty = 0;
                                decimal kitQty = 0;

                                DataTable dtKitQty = ManufactureDAL.GetKitAndReservedQtyBatchInfo(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, preweighInfo.BatchNumber);

                                if (dtKitQty.Rows.Count > 0)
                                {
                                    decimal.TryParse(dtKitQty.Rows[0]["FKITQTY"].ToString(), out kitQty);
                                }

                                //get already mixed qty for this batch
                                DataTable dtMixedQty = ManufactureDAL.GetConfirmedQtyBatchInfo(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, preweighInfo.BatchNumber);
                                if (dtMixedQty.Rows.Count > 0)
                                {
                                    decimal.TryParse(dtMixedQty.Rows[0]["FMIXQTY"].ToString(), out mixedQty);
                                }

                                //scenario could be out of 50 required qty, 30 is fully kitted and 20 is reserved. upto 30 KG, if same kit batch is picked then no need to
                                //do stock adjustment. Beyond 30 KG anything is picked then do stock adjustment

                                if ((mixedQty + preweighInfo.PreweighedQty) > kitQty)
                                {
                                    decimal stockAdjustmentQty = 0;

                                    //Scenario could be kit qty is 30. First time 25 is confirmed. No stock adjustment done as it is within kit qty. Next time 10 KG is confirmed.
                                    //Now adjustment qty should be (25+10) - 30 = 5 KG
                                    //Next time again 10 KG is confirmed; Now adjustment qty should be KG
                                    if (mixedQty > kitQty)
                                    {
                                        stockAdjustmentQty = preweighInfo.PreweighedQty;
                                    }
                                    else
                                    {
                                        stockAdjustmentQty = ((mixedQty + preweighInfo.PreweighedQty)) - kitQty;
                                    }

                                    decimal adjustmentQty = stockAdjustmentQty;
                                    ManufactureService.AdjustKitItemReservedQtyInfo(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, preweighInfo.BatchNumber, ref adjustmentQty, false);

                                    adjustmentQty = stockAdjustmentQty;
                                    ManufactureService.AdjustConfirmedQtyAgainstReservation(db, transaction, preweighInfo.SiteID, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, preweighInfo.MaterialNumber, preweighInfo.BatchNumber, adjustmentQty, preweighInfo.Uom);

                                }
                            }

                        }

                        #endregion

                        //COMMENTED TO SUPPORT PACKAGING MATERIAL REPLENISHMENT - > UPDATING AGAIN STAGING QTY HERE WILL DOUBLE UP STAGING QTY IF ALREADY STAGED
                        //dataReaderStagingInfo = PreweighDAL.CheckStagingInfoExists(db, transaction, preweighInfo.ProcessOrder, preweighInfo.MaterialNumber, preweighInfo.BatchNumber
                        //        , preweighInfo.Bin, lineItemNumber);


                        //if (dataReaderStagingInfo.Read())
                        //{
                        //    isExistStageInfo = true;
                        //}
                        //dataReaderStagingInfo.Close();


                        //if (isExistStageInfo == true)
                        //{
                        //    PreweighDAL.UpdateStagingInfo(db, transaction, preweighInfo.ProcessOrder, preweighInfo.MaterialNumber
                        //        , preweighInfo.BatchNumber, preweighInfo.Bin, preweighInfo.LineItemNumber, preweighInfo.Picker, qtyToUpdateInStaging, preweighInfo.StorageType);
                        //}
                        //else
                        //{
                        //    PreweighDAL.InsertStagingInfo(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, preweighInfo.MaterialNumber
                        //        , preweighInfo.BatchNumber, preweighInfo.Bin, preweighInfo.PreweighedQty, uom, preweighInfo.Picker, preweighInfo.StorageType);
                        //}


                        if (ManufactureDAL.CheckBatchExistInConfirmBatch(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, preweighInfo.MaterialNumber, preweighInfo.BatchNumber) == true)
                        {
                            ManufactureDAL.UpdateManufactureConfirmQty(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, preweighInfo.MaterialNumber
                                , preweighInfo.BatchNumber, preweighInfo.PreweighedQty, preweighInfo.Picker, currentdate, currentTime);

                        }
                        else
                        {
                            ManufactureDAL.InsertManufactureConfirmBatchQty(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, preweighInfo.MaterialNumber
                                 , preweighInfo.BatchNumber, preweighInfo.PreweighedQty, preweighInfo.Uom, preweighInfo.Picker, currentdate, currentTime);
                        }

                        CommonDAL.LogProcessTransactionLog(db, transaction, preweighInfo.ProcessOrder, ProcessTransactionLog.Confirm_Mix_Qty.ToString(),
                            preweighInfo.PreweighedQty + " " + preweighInfo.Uom + " is confirmed for the material/batch (" + lineItemNumber + "):" + preweighInfo.MaterialNumber + "/" + preweighInfo.BatchNumber, preweighInfo.Picker, currentdate, currentTime);

                        if ((totalConsumedQty + preweighInfo.PreweighedQty) >= totalReqQty)
                            ManufactureDAL.UpdateManufactureLineItemStatus(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, Convert.ToChar(ProcessOrderItemStatus.Packing_Completed));
                        else
                            ManufactureDAL.UpdateManufactureLineItemStatus(db, transaction, preweighInfo.ProcessOrder, preweighInfo.LineItemNumber, Convert.ToChar(ProcessOrderItemStatus.Packing_Started));

                        //Move to PSA area (Only for FIFO setting)

                        //Move material to supply area and then destock material from SAP. Do 261 movement for the material in SAP
                        if (preweighInfo.PreweighedQty > 0)
                        {
                            if (plantSetting.BatchDeterminationLogic == PlantBatchLogic.RealTime)
                            {

                                SAPStatus sapAvailabilityStatus = Common.GetSAPAvailabilityStatus(plantSetting.SapAvailabilityStatus, plineSettings.SAPStatus);
                                bool markForceCompleted = false;

                                itemInfoForBintoBin.OrderNumber = preweighInfo.ProcessOrder;
                                itemInfoForBintoBin.SiteID = preweighInfo.SiteID;
                                itemInfoForBintoBin.UserID = preweighInfo.Picker;
                                itemInfoForBintoBin.FromBinLocation = preweighInfo.Bin;
                                itemInfoForBintoBin.FromBinType = preweighInfo.StorageType;
                                itemInfoForBintoBin.StockType = preweighInfo.StockType;
                                itemInfoForBintoBin.VendorNumber = preweighInfo.VendorNumber;
                                itemInfoForBintoBin.BatchNumber = preweighInfo.BatchNumber;
                                itemInfoForBintoBin.Quantity = preweighInfo.PreweighedQty;
                                itemInfoForBintoBin.Unit = preweighInfo.Uom;
                                itemInfoForBintoBin.MovementType = "B2B";

                                //Don't pass reservation number and reservation item number for raw materils. If we pass reservation number BAPI is not considering the bin location which we passed
                                itemInfoForBintoBin.ReservationNumber = itemInfoForBintoBin.ReservationNumber;
                                itemInfoForBintoBin.ReservationItemNumber = itemInfoForBintoBin.ReservationItemNumber;


                                //Insert Bin to Bin info in queue
                                SAPQueueID queueID = new SAPQueueID();
                                int parentID = 0;
                                if (itemInfoForBintoBin.FromBinLocation != itemInfoForBintoBin.ToBinLocation && itemInfoForBintoBin.FromBinType != itemInfoForBintoBin.ToBinType)
                                {
                                    if (sapAvailabilityStatus == SAPStatus.Down)
                                    {
                                        markForceCompleted = true;
                                    }

                                    queueID.QueueID = CommonDAL.InsertSAPTransactionQueue(db, transaction, preweighInfo.SiteID, plantSetting.WarehouseNumber
                                        , itemInfoForBintoBin.PlantCode, "B2B", preweighInfo.ProcessOrder, itemInfoForBintoBin.LineItemNumber
                                        , itemInfoForBintoBin.ReservationNumber, itemInfoForBintoBin.ReservationItemNumber, itemInfoForBintoBin.Material
                                        , itemInfoForBintoBin.BatchNumber, itemInfoForBintoBin.IsBatchManaged, itemInfoForBintoBin.StorageLocation, string.Empty
                                        , itemInfoForBintoBin.Quantity, itemInfoForBintoBin.Unit, itemInfoForBintoBin.FromBinLocation, itemInfoForBintoBin.FromBinType
                                        , itemInfoForBintoBin.ToBinLocation, itemInfoForBintoBin.ToBinType, itemInfoForBintoBin.VendorNumber
                                        , itemInfoForBintoBin.StockType, currentdate, currentTime, itemInfoForBintoBin.UserID, 'N', 0, markForceCompleted
                                        , (char)sapAvailabilityStatus, 0, 'A', 'N', string.Empty, string.Empty, string.Empty, 0, 0);

                                    sapQueueList.Add(queueID);
                                    parentID = queueID.QueueID;
                                }

                                //Insert 261 info in queue
                                queueID = new SAPQueueID();

                                if (sapAvailabilityStatus != SAPStatus.Active)
                                {
                                    markForceCompleted = true;
                                }

                                if (itemInfoForBintoBin.StockType == "K")
                                {
                                    parentID = CommonDAL.InsertSAPTransactionQueue(db, transaction, preweighInfo.SiteID, plantSetting.WarehouseNumber
                                        , itemInfoForBintoBin.PlantCode, "411", preweighInfo.ProcessOrder, itemInfoForBintoBin.LineItemNumber, itemInfoForBintoBin.ReservationNumber
                                        , itemInfoForBintoBin.ReservationItemNumber, itemInfoForBintoBin.Material, itemInfoForBintoBin.BatchNumber
                                        , itemInfoForBintoBin.IsBatchManaged, itemInfoForBintoBin.StorageLocation, string.Empty, itemInfoForBintoBin.Quantity, itemInfoForBintoBin.Unit, itemInfoForBintoBin.ToBinLocation
                                        , itemInfoForBintoBin.ToBinType, string.Empty, string.Empty, itemInfoForBintoBin.VendorNumber, itemInfoForBintoBin.StockType, currentdate, currentTime
                                        , itemInfoForBintoBin.UserID, 'N', parentID, markForceCompleted, (char)sapAvailabilityStatus, 0, 'A', 'N', string.Empty, string.Empty, string.Empty, 0, 0);



                                    parentID = CommonDAL.InsertSAPTransactionQueue(db, transaction, preweighInfo.SiteID, plantSetting.WarehouseNumber
                                            , itemInfoForBintoBin.PlantCode, "CPC", preweighInfo.ProcessOrder, itemInfoForBintoBin.LineItemNumber, itemInfoForBintoBin.ReservationNumber
                                            , itemInfoForBintoBin.ReservationItemNumber, itemInfoForBintoBin.Material, itemInfoForBintoBin.BatchNumber
                                            , itemInfoForBintoBin.IsBatchManaged, itemInfoForBintoBin.StorageLocation, string.Empty, itemInfoForBintoBin.Quantity, itemInfoForBintoBin.Unit, itemInfoForBintoBin.ToBinLocation
                                            , itemInfoForBintoBin.ToBinType, string.Empty, string.Empty, itemInfoForBintoBin.VendorNumber, itemInfoForBintoBin.StockType, currentdate, currentTime
                                            , itemInfoForBintoBin.UserID, 'N', parentID, markForceCompleted, (char)sapAvailabilityStatus, 0, 'A', 'N', string.Empty, string.Empty, string.Empty, 0, 0);
                                }

                                string milestonePhaseForLineItem = ManufactureDAL.GetMileStonePhaseOfLineItem(db, transaction, preweighInfo.ProcessOrder, itemInfoForBintoBin.LineItemNumber, "F");

                                queueID.QueueID = CommonDAL.InsertSAPTransactionQueue(db, transaction, preweighInfo.SiteID, plantSetting.WarehouseNumber
                                    , itemInfoForBintoBin.PlantCode, "261", preweighInfo.ProcessOrder, itemInfoForBintoBin.LineItemNumber
                                    , itemInfoForBintoBin.ReservationNumber, itemInfoForBintoBin.ReservationItemNumber, itemInfoForBintoBin.Material, itemInfoForBintoBin.BatchNumber, itemInfoForBintoBin.IsBatchManaged, itemInfoForBintoBin.StorageLocation, string.Empty
                                    , itemInfoForBintoBin.Quantity, itemInfoForBintoBin.Unit, itemInfoForBintoBin.ToBinLocation, itemInfoForBintoBin.ToBinType
                                    , string.Empty, string.Empty, itemInfoForBintoBin.VendorNumber, itemInfoForBintoBin.StockType, currentdate, currentTime
                                    , itemInfoForBintoBin.UserID, 'N', parentID, markForceCompleted, (char)sapAvailabilityStatus, 0, 'A', 'N'
                                    , plantSetting.ProcessOrder_BackFlushIndicator, string.Empty, milestonePhaseForLineItem, 0, 0);

                                sapQueueList.Add(queueID);
                            }
                        }

                        CommonDAL.LogProcessTransactionLog(db, transaction, preweighInfo.ProcessOrder, ProcessTransactionLog.Pallet_Picked.ToString()
                           , "Pallet Picked For Material ( " + preweighInfo.LineItemNumber + " ): " + preweighInfo.MaterialNumber + ", Batch: " + preweighInfo.BatchNumber + ", Bin: " + preweighInfo.Bin + " : " + preweighInfo.LabelNumber
                            , preweighInfo.Picker, currentdate, currentTime);


                        transaction.Commit();

                        ////Do bin to bin movement for the material and then do 261 movement for the material
                        //if (plantSetting.BatchDeterminationLogic == PlantBatchLogic.RealTime && preweighInfo.PreweighedQty > 0)
                        //{
                        //    //Do 101 and 261 movement for bulk and filling
                        //    Common.PerformSAPQueueOperation order = new Common.PerformSAPQueueOperation(Common.ProcessSAPQueueOperation);
                        //    AsyncCallback cb = new AsyncCallback(Send);
                        //    IAsyncResult ar = order.BeginInvoke(preweighInfo.SiteID, sapQueueList, cb, null);
                        //}
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        connection.Close();
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while doing preweigh update", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Label Number: " + preweighInfo.LabelNumber + "; UserID: " + preweighInfo.Picker + "; SiteID: " + preweighInfo.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPOLineInfo != null && !dataReaderPOLineInfo.IsClosed)
                    dataReaderPOLineInfo.Close();

                //if (dataReaderStagingInfo != null && !dataReaderStagingInfo.IsClosed)
                //    dataReaderStagingInfo.Close();

            }
        }

        private static bool UpdatePickItemInfoForProcessOrder(Database db, System.Data.Common.DbTransaction transaction, string processOrder, int lineItemNumber, string materialNumber
                                , string batchNumber, string binLocation, string storageType, decimal assignQty, string unit, int userID, int pickStartDate, int pickStartTime, int pickEndDate, int pickEndTime)
        {
            IDataReader infoReader = null;
            try
            {
                infoReader = StagingDAL.CheckStagingInfoExists(db, transaction, processOrder, lineItemNumber, materialNumber, batchNumber, binLocation, storageType);
                if (infoReader.Read())
                {
                    StagingDAL.UpdateStagingInfo(db, transaction, processOrder, lineItemNumber, materialNumber, batchNumber, binLocation, storageType, assignQty, userID
                        , pickStartDate, pickStartTime, pickEndDate, pickEndTime);
                }
                else
                {
                    StagingDAL.InsertStagingInfo(db, transaction, processOrder, lineItemNumber, materialNumber, batchNumber, binLocation, storageType, assignQty
                        , unit, userID, pickStartDate, pickStartTime, pickEndDate, pickEndTime, false);
                }
                infoReader.Close();

                return true;
            }
            catch
            {
                throw;
            }
            finally
            {
                if (infoReader != null && !infoReader.IsClosed)
                    infoReader.Close();
            }
        }

        #endregion

        #region ManufacturePreweigh_Old
        private ProcessOrderBOMInfo FillProcessOrderBOMInfo(Database db, int siteID, int userID, string processOrderNumber, string mode, int lineItemNumber)
        {
            ProcessOrderBOMInfo processOrderBOMInfo = new ProcessOrderBOMInfo();
            List<StageProcessOrderBOM> bomInfoList = new List<StageProcessOrderBOM>();
            IDataReader dataReaderBomInfo = null;
            IDataReader dataReaderPreweighNote = null;
            IDataReader dataReaderPPE = null;
            IDataReader dataReaderPlantSettings = null;
            try
            {
                string preWeighNotes = string.Empty;
                StageProcessOrderBOM bomInfo;

                if (mode == "BY_PO")
                    dataReaderBomInfo = PreweighDAL.GetProcessOrderBOMInfo(db, siteID, processOrderNumber);
                else if (mode == "BY_GROUP")
                    dataReaderBomInfo = PreweighDAL.GetProcessOrdersByGroupItems(db, siteID, processOrderNumber);
                else if (mode == "SINGLE_LINE")
                    dataReaderBomInfo = PreweighDAL.GetProcessOrderBOMInfoForPreweigh(db, siteID, processOrderNumber, lineItemNumber);
                else if (mode == "ADDITION")
                {
                    bool showAllLineItems = false;
                    if (lineItemNumber == 1)
                        showAllLineItems = true;

                    bool batchDeterminationByTRBased = false;
                    dataReaderPlantSettings = CommonDAL.GetPlantSettings(db, siteID);
                    if (dataReaderPlantSettings.Read())
                    {
                        if (Common.GetSafeChar(dataReaderPlantSettings, "FBATCHLOGIC") == (char)PlantBatchLogic.TRBased)
                        {
                            batchDeterminationByTRBased = true;
                        }
                    }
                    dataReaderPlantSettings.Close();


                    dataReaderBomInfo = PreweighDAL.GetProcessOrderPhaseAdditions(db, siteID, processOrderNumber, showAllLineItems, batchDeterminationByTRBased);
                }

                int i = 0;
                while (dataReaderBomInfo.Read())
                {
                    bomInfo = new StageProcessOrderBOM();
                    bomInfo.POSNR = Common.GetSafeString(dataReaderBomInfo, "FPOSNR");
                    bomInfo.VORNR = Common.GetSafeString(dataReaderBomInfo, "FVORNR");
                    bomInfo.Plant = Common.GetSafeString(dataReaderBomInfo, "FWERKS");
                    bomInfo.MaterialNum = Common.GetSafeString(dataReaderBomInfo, "FIDHID");
                    bomInfo.MaterialDesc = Common.GetSafeString(dataReaderBomInfo, "FIDHDESC");
                    bomInfo.BatchNumber = Common.GetSafeString(dataReaderBomInfo, "FCHARG");
                    bomInfo.StorageLocation = Common.GetSafeString(dataReaderBomInfo, "FLGORT");

                    if (Common.GetSafeString(dataReaderBomInfo, "FISBATCHMANAGED") == "Y")
                    {
                        bomInfo.IsBatchManaged = true;
                    }

                    if (Common.GetSafeString(dataReaderBomInfo, "FSTORAGEBIN") == "Y")
                    {
                        bomInfo.IsWarehouseManaged = true;
                    }

                    bomInfo.Qty = Common.GetSafeDecimal(dataReaderBomInfo, "FQTY");
                    bomInfo.UOM = Common.GetSafeString(dataReaderBomInfo, "FUOM");

                    int ppeConfirmedUser = Common.GetSafeInt32(dataReaderBomInfo, "FPPECONFIRM");
                    if (ppeConfirmedUser == 0)
                        bomInfo.IsPPEConfirmed = false;
                    else
                        bomInfo.IsPPEConfirmed = true;

                    bomInfo.PPEList = GetMaterialPPECode(db, siteID, Common.GetSafeString(dataReaderBomInfo, "FDAIN1"), Common.GetSafeString(dataReaderBomInfo, "FDAIN2"), Common.GetSafeString(dataReaderBomInfo, "FDAIN3"));

                    bomInfoList.Add(bomInfo);
                }
                dataReaderBomInfo.Close();

                dataReaderPreweighNote = PreweighDAL.GetPreweighNotesForProcessOrder(db, siteID, processOrderNumber);
                if (dataReaderPreweighNote.Read())
                {
                    preWeighNotes = Common.GetSafeString(dataReaderPreweighNote, "FPREWEIGHNOTES");
                }
                dataReaderPreweighNote.Close();

                processOrderBOMInfo.ProcessOrderNumber = processOrderNumber;
                processOrderBOMInfo.PreweighNotes = preWeighNotes.Trim();
                processOrderBOMInfo.ProcessOrderBOMList = bomInfoList;

                return processOrderBOMInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching BOM info", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Process Orders: " + processOrderNumber + "; UserID: " + userID + "; SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderBomInfo != null && !dataReaderBomInfo.IsClosed)
                    dataReaderBomInfo.Close();

                if (dataReaderPreweighNote != null && !dataReaderPreweighNote.IsClosed)
                    dataReaderPreweighNote.Close();

                if (dataReaderPPE != null && !dataReaderPPE.IsClosed)
                    dataReaderPPE.Close();

                if (dataReaderPlantSettings != null && !dataReaderPlantSettings.IsClosed)
                    dataReaderPlantSettings.Close();
            }
        }



        private DataTable GetAvailableBinBatchInfoForPreweighDuringManufatcure(Database db, iPASRFSAP.BAPIClass sapBapiClass, string materialNumber, bool isBatchManaged
                , string batchNumber, int siteID, DataTable stagingAreaBinTable
                , string plantCodes, string wareHouseNumber, OrderPLineSettings plineSettings)
        {
            // 1. THE BAPI FIRST GETS ALL THE AVAILABLE BATCHES FOR THE MATERIAL. 
            // 2. SORTS THEM BASED ON EXPIRY DATE ASC
            // 3. FOR NON-KANBAN - AVOIDS ALL THE BATCHES THAT ARE SITTING IN STAGING AREA; avoids all the bins of the batches for which stock error log exists
            // 4. RETURNS FIRST AVAILBLE BATCH ALONG WITH ITS BIN LOCATIONS
            // 4. FOR KANBAN RETURN ALL KANBAN BINS
            string bapiMessage = string.Empty;

            DataTable availableBinTable = new DataTable();
            bapiMessage = sapBapiClass.GetAvailableBinList(materialNumber, plantCodes, string.Empty, batchNumber, wareHouseNumber, ref availableBinTable);

            DataTable availableBinTableForFirstBatch = new DataTable();

            if (bapiMessage == string.Empty && availableBinTable.Rows.Count > 0)
            {
                //sort available bin batch table by expiry date
                DataView availabeBinView = availableBinTable.DefaultView;
                availabeBinView.Sort = "VFDAT ASC,CHARG ASC";
                DataTable sortedBinTable = availabeBinView.ToTable();

                availableBinTableForFirstBatch = sortedBinTable.Clone();

                if (plineSettings.EnableKanban)
                {
                    //filter bins that are of type KANBAN storage type
                    DataTable stockErrorTable = new DataTable();
                    foreach (DataRow dr in sortedBinTable.Rows)
                    {
                        if (dr["LGTYP"].ToString().Trim().ToUpper() == plineSettings.KanbanStorageType.Trim().ToUpper() && dr["BESTQ"].ToString().Trim().Length == 0)
                        {
                            decimal availableQty = 0;
                            decimal.TryParse(dr["VERME"].ToString().Trim(), out availableQty);
                            if (availableQty > 0)   //If available qty is greater than zero, then only consider
                            {
                                string currentBin = dr["LGPLA"].ToString().Trim().ToUpper();

                                //check if any error is logged against the material/batch for this bin
                                DataRow[] errorBinRow = null;

                                stockErrorTable = StagingDAL.GetStockLogErrorInfoForMaterialBatch(db, siteID, materialNumber, dr["CHARG"].ToString().Trim());//Get stock error log for the material and batch if exists
                                if (stockErrorTable.Rows.Count > 0)
                                    errorBinRow = stockErrorTable.Select("FBIN = '" + currentBin + "'");

                                //Do not consider bins which already reported stock error for the material and batch.
                                if (errorBinRow == null || errorBinRow.Length == 0)
                                {
                                    availableBinTableForFirstBatch.ImportRow(dr);
                                }
                            }
                        }

                    }
                }
                else
                {
                    string currentBatch = string.Empty;
                    string prevBatch = string.Empty;
                    string currentBin = string.Empty;
                    DataTable stockErrorTable = new DataTable();

                    if (!isBatchManaged)
                        stockErrorTable = StagingDAL.GetStockLogErrorInfoForMaterialBatch(db, siteID, materialNumber, string.Empty);

                    foreach (DataRow dr in sortedBinTable.Rows)
                    {
                        if (dr["BESTQ"].ToString().Trim().Length == 0 && dr["LGTYP"].ToString().Trim().ToUpper() != plineSettings.KanbanStorageType.Trim().ToUpper())
                        {
                            currentBin = dr["LGPLA"].ToString().Trim().ToUpper();

                            //Discard record if it is in staging area
                            DataRow[] stagingAreaBinRow = stagingAreaBinTable.Select(" FSTAGINGAREA= '" + dr["LGTYP"].ToString().Trim().ToUpper() + "' AND FSTAGINGBIN = '" + currentBin + "'");

                            //Do not consider records which are having staging area bin locations.
                            if (stagingAreaBinRow.Length == 0)
                            {
                                decimal availableQty = 0;
                                decimal.TryParse(dr["VERME"].ToString().Trim(), out availableQty);
                                if (availableQty > 0)   //If available qty is greater than zero, then only consider
                                {
                                    if (isBatchManaged)
                                    {
                                        currentBatch = dr["CHARG"].ToString().Trim();
                                        if (currentBatch != prevBatch)
                                        {
                                            if (availableBinTableForFirstBatch.Rows.Count > 0)
                                                break;

                                            //check if any error is logged against the material/batch for this bin
                                            stockErrorTable = StagingDAL.GetStockLogErrorInfoForMaterialBatch(db, siteID, materialNumber, currentBatch);//Get stock error log for the material and batch if exists
                                        }
                                    }

                                    DataRow[] errorBinRow = null;
                                    if (stockErrorTable.Rows.Count > 0)
                                        errorBinRow = stockErrorTable.Select("FBIN = '" + currentBin + "'");

                                    //Do not consider bins which already reported stock error for the material and batch.
                                    if (errorBinRow == null || errorBinRow.Length == 0)
                                    {
                                        availableBinTableForFirstBatch.ImportRow(dr);
                                    }

                                    prevBatch = currentBatch;
                                }
                            }
                        }
                    }
                }
            }

            return availableBinTableForFirstBatch;
        }

        private static string DoBinToBinMovement(iPASRFSAP.BAPIClass sapBapiClass, string materialNumber, string plantCode, string warehouseNumber, string storageLocation
           , string batchNumber, decimal qty, string uom, string storageType, string sourceBin, string targetStorageType, string targetBin, string stockType
           , string vendorNumber, bool isBatchManaged, string userName)
        {
            try
            {
                //Do bin to bin transfer for material from picked bin location to staging area
                iPASRFSAP.LabelInfo labelInfo = new iPASRFSAP.LabelInfo();
                labelInfo.MaterialNumber = materialNumber.Trim().PadLeft(18, '0');
                labelInfo.Plant = plantCode.Trim();
                labelInfo.WareHouseNumber = warehouseNumber;
                labelInfo.StorageLocation = storageLocation.Trim();
                labelInfo.BatchNumber = batchNumber.Trim().ToUpper();
                labelInfo.Quantity = qty;
                labelInfo.Unit = uom.Trim();
                labelInfo.StorageType = storageType;
                labelInfo.CurrentBin = sourceBin;

                labelInfo.TargetStorageType = targetStorageType;
                labelInfo.BinLocation = targetBin;
                labelInfo.StockTypeFlag = stockType;
                labelInfo.VendorNumber = vendorNumber;
                labelInfo.IsBatchManaged = isBatchManaged;

                string transferOrderNumber = string.Empty;
                if (targetStorageType.Trim().Length > 0)
                {

                    List<iPASRFSAP.LabelInfo> labelInfoList = new List<iPASRFSAP.LabelInfo>();
                    labelInfoList.Add(labelInfo);

                    transferOrderNumber = sapBapiClass.MassConfirmBinTransfer(labelInfoList, userName);
                }
                else
                {
                    labelInfo.OrderType = "D";
                    sapBapiClass.ConfirmBinToBinMovement(labelInfo, userName);
                }

                return transferOrderNumber;
            }
            catch
            {
                throw;
            }
        }

        public BomInfo GetAvailableBinBatchForPackageMaterial(AvailablePackageBinFilter filterInfo)
        {
            IDataReader dataReaderWareHouse = null;
            IDataReader dataReaderPendingQty = null;
            List<AvailableBinBatchInfo> availableBinBatchInfoList = new List<AvailableBinBatchInfo>();
            BomInfo bomInfo = null;
            string warehouseNumber = string.Empty;
            decimal requiredQty = 0;
            decimal totalConsumedQty = 0;
            string bapiMessage = string.Empty;
            DataTable availableBinTable = new DataTable();
            AvailableBinBatchInfo availableBinBatchInfo;
            decimal quantity = 0;
            string plantCode = string.Empty;
            string materialNum = string.Empty;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderPendingQty = PreweighDAL.GetRequiredPackagingQtyForLineItem(db, filterInfo.ProcessOrder, filterInfo.LineItemNumber);
                if (dataReaderPendingQty.Read())
                {
                    requiredQty = Common.GetSafeDecimal(dataReaderPendingQty, "FQTY");
                    totalConsumedQty = Common.GetSafeDecimal(dataReaderPendingQty, "FCONSUMEDQTY");
                }
                dataReaderPendingQty.Close();

                decimal pendingQty = requiredQty - totalConsumedQty;

                dataReaderWareHouse = CommonDAL.GetWarehouseNumber(db, filterInfo.SiteID);
                if (dataReaderWareHouse.Read())
                {
                    warehouseNumber = Common.GetSafeString(dataReaderWareHouse, "FWAREHOUSENUMBER");
                }
                dataReaderWareHouse.Close();

                if (warehouseNumber.Trim().Length > 0)
                {
                    bomInfo = new BomInfo();

                    DataTable dtBatchlist = PreweighDAL.GetPickBatchBinInfoForLineItem(db, filterInfo.ProcessOrder, filterInfo.LineItemNumber);
                    if (dtBatchlist.Rows.Count > 0)
                    {
                        plantCode = dtBatchlist.Rows[0]["FWERKS"].ToString();
                        materialNum = dtBatchlist.Rows[0]["FMATNR"].ToString();
                    }

                    //Get pallets that are in staging area. This is required to mark in available list to indicate that they are in staging area
                    DataTable dtStagingPallet = PreweighDAL.GetPalletInStagingArea(db, filterInfo.SiteID, filterInfo.ProcessOrder, materialNum, string.Empty);

                    // Copy distinct values from col1 to a different datatable
                    DataTable distinctBatch = dtBatchlist.DefaultView.ToTable(true, "FCHARG");

                    iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

                    //loop through each distinct batch numbers proposed by SAP & get list of available batches for that

                    List<iPASRFSAP.MaterialBinInfo> materialList = new List<iPASRFSAP.MaterialBinInfo>();
                    for (int iRow = 0; iRow < distinctBatch.Rows.Count; iRow++)
                    {
                        iPASRFSAP.MaterialBinInfo materialInfo = new iPASRFSAP.MaterialBinInfo();
                        materialInfo.BatchNumber = distinctBatch.Rows[iRow]["FCHARG"].ToString();
                        materialInfo.MaterialNumber = materialNum;
                        materialInfo.Plant = plantCode;
                        materialInfo.WareHouseNumber = warehouseNumber;

                        materialList.Add(materialInfo);
                    }

                    if (distinctBatch.Rows.Count == 0)
                    {
                        iPASRFSAP.MaterialBinInfo materialInfo = new iPASRFSAP.MaterialBinInfo();
                        materialInfo.MaterialNumber = materialNum;
                        materialInfo.Plant = plantCode;
                        materialInfo.WareHouseNumber = warehouseNumber;

                        materialList.Add(materialInfo);
                    }

                    sapBapiClass.GetAvailableBinListForMultipleMaterials(true, materialList, ref availableBinTable);
                    //bapiMessage = sapBapiClass.GetAvailableBinList(materialNum, plantCode, string.Empty, distinctBatch.Rows[iRow]["FCHARG"].ToString(), warehouseNumber
                    //            , ref availableBinTable);

                    if (availableBinTable.Rows.Count > 0)
                    {
                        foreach (DataRow dr in availableBinTable.Rows)
                        {
                            if (dr["BESTQ"].ToString() == string.Empty)
                            {
                                availableBinBatchInfo = new AvailableBinBatchInfo();

                                availableBinBatchInfo.BatchNum = dr["CHARG"].ToString();
                                availableBinBatchInfo.BinLocation = dr["LGPLA"].ToString();
                                decimal.TryParse(dr["GESME"].ToString(), out quantity);
                                availableBinBatchInfo.Quantity = quantity;
                                availableBinBatchInfo.UOM = dr["MEINS"].ToString();
                                availableBinBatchInfo.StorageType = dr["LGTYP"].ToString();

                                DataRow[] drPalletFound = dtStagingPallet.Select(" FBINLOCATION ='" + availableBinBatchInfo.BinLocation + "' AND FCHARG ='" + availableBinBatchInfo.BatchNum + "'");
                                if (drPalletFound.Length > 0)
                                {
                                    availableBinBatchInfo.IsPalletInStagingArea = true;
                                }

                                DataRow[] drBinFound = dtBatchlist.Select(" FBINLOCATION ='" + availableBinBatchInfo.BinLocation + "' AND FCHARG ='" + availableBinBatchInfo.BatchNum + "'");
                                if (drBinFound.Length > 0)
                                {
                                    availableBinBatchInfo.IsSAP_Proposed = true;

                                    if (drBinFound[0]["FPICKEDQTY"].ToString() != "0")
                                    {
                                        availableBinBatchInfo.IsAlreadyPicked = true;
                                    }
                                }

                                availableBinBatchInfoList.Add(availableBinBatchInfo);
                            }
                        }
                    }

                    bomInfo.BatchBinInfo = availableBinBatchInfoList;
                    bomInfo.QtyPending = totalConsumedQty;

                    return bomInfo;
                }
                else
                {
                    throw new FaultException("Warehouse number not set for the plant.");
                }
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting available bins from SAP", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + filterInfo.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderWareHouse != null && !dataReaderWareHouse.IsClosed)
                    dataReaderWareHouse.Close();

                if (dataReaderPendingQty != null && !dataReaderPendingQty.IsClosed)
                    dataReaderPendingQty.Close();
            }
        }

        public BomInfo GetProposedBatchForPackageMaterial(AvailablePackageBinFilter filterInfo)
        {
            IDataReader dataReaderWareHouse = null;
            IDataReader dataReaderPendingQty = null;
            IDataReader plineSettingsReader = null;

            List<AvailableBinBatchInfo> availableBinBatchInfoList = new List<AvailableBinBatchInfo>();
            BomInfo bomInfo = null;

            string warehouseNumber = string.Empty;
            decimal requiredQty = 0;
            decimal totalConsumedQty = 0;
            string bapiMessage = string.Empty;
            DataTable availableBinTable = new DataTable();

            string plantCode = string.Empty;
            string materialNumber = string.Empty;
            string storageLocation = string.Empty;
            bool isBatchManaged = false;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                dataReaderPendingQty = PreweighDAL.GetRequiredPackagingQtyForLineItem(db, filterInfo.SiteID, filterInfo.ProcessOrder, filterInfo.LineItemNumber);
                if (dataReaderPendingQty.Read())
                {
                    requiredQty = Common.GetSafeDecimal(dataReaderPendingQty, "FQTY");
                    totalConsumedQty = Common.GetSafeDecimal(dataReaderPendingQty, "FCONSUMEDQTY");
                    plantCode = Common.GetSafeString(dataReaderPendingQty, "FWERKS");
                    materialNumber = Common.GetSafeString(dataReaderPendingQty, "FIDHID");
                    isBatchManaged = Common.GetSafeString(dataReaderPendingQty, "FISBATCHMANAGED") == "Y" ? true : false;
                    storageLocation = Common.GetSafeString(dataReaderPendingQty, "FLGORT");
                }
                dataReaderPendingQty.Close();

                decimal pendingQty = requiredQty - totalConsumedQty;

                dataReaderWareHouse = CommonDAL.GetWarehouseNumber(db, filterInfo.SiteID);
                if (dataReaderWareHouse.Read())
                {
                    warehouseNumber = Common.GetSafeString(dataReaderWareHouse, "FWAREHOUSENUMBER");
                }
                dataReaderWareHouse.Close();

                if (warehouseNumber.Trim().Length > 0)
                {
                    bomInfo = new BomInfo();

                    string orderList = "'" + filterInfo.ProcessOrder.Trim().PadLeft(12, '0') + "'";
                    OrderPLineSettings plineSettings = new OrderPLineSettings();

                    //Get orders production line information
                    plineSettingsReader = StagingDAL.GetProcessOrdersPLineInfo(db, filterInfo.SiteID, orderList, false);
                    if (plineSettingsReader.Read())
                    {
                        plineSettings.PLineID = Common.GetSafeInt32(plineSettingsReader, "FPLINEID");
                        plineSettings.StagingArea = Common.GetSafeString(plineSettingsReader, "FSTAGINGAREA");
                        plineSettings.StagingBin = Common.GetSafeString(plineSettingsReader, "FSTAGINGBIN");
                        plineSettings.SupplyArea = Common.GetSafeString(plineSettingsReader, "FSUPPLYAREA");
                        plineSettings.SupplyBin = Common.GetSafeString(plineSettingsReader, "FSUPPLYBIN");
                        plineSettings.EnableKanban = false; // Common.GetSafeString(plineSettingsReader, "FENABLEKANBAN") == "Y" ? true : false;
                        plineSettings.KanbanStorageType = Common.GetSafeString(plineSettingsReader, "FKANBANSTORAGETYPE");
                    }
                    plineSettingsReader.Close();

                    //Get all staging area locations for the site
                    DataTable stagingAreaBinTable = StagingDAL.GetAllStagingAreaForSite(db, filterInfo.SiteID);

                    iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

                    //Get first available batch(for batch managed)/all available batches for the material along with bin location
                    DataTable availableBinBatchTable = GetAvailableBinBatchInfoForPreweighDuringManufatcure(db, sapBapiClass, materialNumber, isBatchManaged, string.Empty, filterInfo.SiteID, stagingAreaBinTable, plantCode, warehouseNumber, plineSettings);

                    if (availableBinBatchTable != null && availableBinBatchTable.Rows.Count > 0)
                    {
                        //Get already picked batch/bin info for material for the selected process orders
                        DataTable pickedBinBatchTable = PreweighDAL.GetAlreadyPickedBinBatchInfoForMaterial(db, filterInfo.ProcessOrder, materialNumber);
                        decimal batchQty = 0;
                        string binQtyUnit = string.Empty;

                        //loop through table to populate available bin list.
                        DataRow[] drAvailableBatches = availableBinBatchTable.Select(" 1 = 1", " SOBKZ ASC, VERME ASC");        //consider consignment last
                        foreach (DataRow batchRow in drAvailableBatches)
                        {
                            bool isValid = false;
                            decimal binQty = 0;
                            decimal.TryParse(batchRow["VERME"].ToString().Trim(), out binQty);

                            if (batchRow["MATNR"].ToString().Trim().PadLeft(18, '0') == materialNumber.Trim().PadLeft(18, '0') && binQty > 0
                                    && batchRow["LGORT"].ToString().Trim().ToUpper() == storageLocation.Trim().ToUpper() && batchRow["BESTQ"].ToString().Trim().Length == 0)
                            {
                                isValid = true;
                            }

                            if (isValid)
                            {
                                batchQty = batchQty + binQty;
                                binQtyUnit = batchRow["MEINS"].ToString().Trim();

                                string expiryDate = string.Empty;
                                string expDate = batchRow["VFDAT"].ToString();

                                if (expDate.Trim().Length > 0)
                                {
                                    expiryDate = expDate.Substring(6);
                                    expiryDate = expiryDate + "-" + expDate.Substring(4, 2);
                                    expiryDate = expiryDate + "-" + expDate.Substring(0, 4);
                                }
                                else
                                {
                                    expiryDate = string.Empty;
                                }

                                AvailableBinBatchInfo binBatchInfo = new AvailableBinBatchInfo();
                                binBatchInfo.BatchNum = batchRow["CHARG"].ToString().Trim();
                                binBatchInfo.BinLocation = batchRow["LGPLA"].ToString().Trim();
                                binBatchInfo.StorageType = batchRow["LGTYP"].ToString().Trim();
                                binBatchInfo.Quantity = binQty;
                                binBatchInfo.UOM = binQtyUnit;
                                binBatchInfo.ExpiryDate = expiryDate;
                                binBatchInfo.StockType = batchRow["SOBKZ"].ToString();
                                binBatchInfo.VendorNumber = batchRow["SONUM"].ToString();

                                //Checks whether picking is already done from this bin location
                                DataRow[] drBinFound = pickedBinBatchTable.Select(" FBINLOCATION ='" + binBatchInfo.BinLocation + "'");
                                if (drBinFound != null && drBinFound.Length > 0)
                                {
                                    binBatchInfo.IsAlreadyPicked = true;
                                }
                                else
                                {
                                    binBatchInfo.IsAlreadyPicked = false;
                                }

                                //binInfoList.Add(binInfo);
                                availableBinBatchInfoList.Add(binBatchInfo);
                            }
                        }
                    }

                    bomInfo.BatchBinInfo = availableBinBatchInfoList;
                    bomInfo.QtyPending = totalConsumedQty;

                    return bomInfo;
                }
                else
                {
                    throw new FaultException("Warehouse number not set for the plant.");
                }
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while getting available bins from SAP", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + filterInfo.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderWareHouse != null && !dataReaderWareHouse.IsClosed)
                    dataReaderWareHouse.Close();

                if (dataReaderPendingQty != null && !dataReaderPendingQty.IsClosed)
                    dataReaderPendingQty.Close();

                if (plineSettingsReader != null && !plineSettingsReader.IsClosed)
                    plineSettingsReader.Close();
            }
        }



        //public bool DoPreweighForPackagingMaterial(PreweighInfo preweighInfo)
        //{
        //    Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
        //    System.Data.Common.DbTransaction transaction;
        //    using (System.Data.Common.DbConnection connection = db.CreateConnection())
        //    {
        //        connection.Open();
        //        transaction = connection.BeginTransaction();
        //        try
        //        {
        //            DoPreweighForPackagingMaterial(db, transaction, preweighInfo);
        //            transaction.Commit();

        //            return true;
        //        }
        //        catch (Exception ex)
        //        {
        //            Common.LogException(ex, "PreWeighService", "Error while doing preweigh update", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Label Number: " + preweighInfo.LabelNumber + "; UserID: " + preweighInfo.Picker + "; SiteID: " + preweighInfo.SiteID);
        //            transaction.Rollback();
        //            throw new FaultException(ex.Message);
        //        }
        //    }
        //}


        #endregion

        public iPAS_PalletInfo.PalletInfoComplete GetPreweighLabelInfoForReturnToWarehouse(int siteID, string preweighLabel)
        {
            IDataReader dataReaderPreweighLabel = null;
            iPAS_PalletInfo.PalletInfoComplete preweighLabelInfo = new iPAS_PalletInfo.PalletInfoComplete();
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                preweighLabelInfo = iPAS_PalletInfo.PalletInfoBAL.GetPalletInfoForLabel(db, siteID, preweighLabel, 0, 0);

                dataReaderPreweighLabel = PreweighDAL.GetPreweighLabelDetailsForBinToBin(db, siteID, preweighLabel);
                if (dataReaderPreweighLabel.Read())
                {
                    preweighLabelInfo.SourceBinLocation = Common.GetSafeString(dataReaderPreweighLabel, "FBINLOCATION");
                }

                dataReaderPreweighLabel.Close();

                return preweighLabelInfo;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while fetching preweigh label info for bin to bin", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Preweigh Label: " + preweighLabel + "; SiteID: " + siteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderPreweighLabel != null && !dataReaderPreweighLabel.IsClosed)
                    dataReaderPreweighLabel.Close();
            }
        }

        #region ConsignmentToOwnStock
        private bool MoveConsignmentStockToOwnStock(Database db, int currentDate, PreweighInfo preweighInfo)
        {
            IDataReader dataReaderWarehouse = null;
            IDataReader dataReaderNonConfirmed = null;
            try
            {
                DataTable lineItemInfoTable = PreweighDAL.GetProcessOrderLineItemInfoForMovement(db, preweighInfo.ProcessOrder, preweighInfo.Posnr, preweighInfo.Vornr, preweighInfo.MaterialNumber);
                if (lineItemInfoTable.Rows.Count > 0)
                {
                    decimal nonConfirmedQty = 0;
                    string wareHouseNumber = string.Empty;
                    string userName = CommonDAL.GetUserName(db, preweighInfo.Picker);

                    string storageLocation = lineItemInfoTable.Rows[0]["FLGORT"].ToString();
                    string plantCode = lineItemInfoTable.Rows[0]["FWERKS"].ToString();
                    int lineItemNumber = 0;

                    Int32.TryParse(lineItemInfoTable.Rows[0]["FLINEITEM"].ToString(), out lineItemNumber);
                    preweighInfo.LineItemNumber = lineItemNumber;

                    dataReaderWarehouse = CommonDAL.GetWarehouseNumber(db, preweighInfo.SiteID);
                    if (dataReaderWarehouse.Read())
                    {
                        wareHouseNumber = Common.GetSafeString(dataReaderWarehouse, "FWAREHOUSENUMBER");
                    }
                    dataReaderWarehouse.Close();

                    iPASRFSAP.MoveStockInfo moveStockInfo = new iPASRFSAP.MoveStockInfo();
                    moveStockInfo.CurrentDate = currentDate;
                    moveStockInfo.UserName = userName;
                    moveStockInfo.Plant = plantCode;
                    moveStockInfo.WarehouseNumber = wareHouseNumber;

                    iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

                    decimal nonConfirmedBinQty = 0;
                    decimal convertedNonConfirmedBinQty = 0;
                    string nonConfirmedBinQtyUOM = string.Empty;

                    #region GettingNonConfirmedQty
                    dataReaderNonConfirmed = PreweighDAL.GetNonConfirmedBinBatchQty(db, preweighInfo.MaterialNumber, preweighInfo.BatchNumber, preweighInfo.Bin);
                    while (dataReaderNonConfirmed.Read())
                    {
                        nonConfirmedBinQty = Common.GetSafeDecimal(dataReaderNonConfirmed, "FNONCONFIRMEDQTY");
                        nonConfirmedBinQtyUOM = Common.GetSafeString(dataReaderNonConfirmed, "FUOM");

                        if (preweighInfo.Uom.Trim().ToUpper() != nonConfirmedBinQtyUOM.Trim().ToUpper())
                            convertedNonConfirmedBinQty = sapBapiClass.UnitConversion(preweighInfo.MaterialNumber, nonConfirmedBinQtyUOM, preweighInfo.Uom, nonConfirmedBinQty);
                        else
                            convertedNonConfirmedBinQty = nonConfirmedBinQty;

                        nonConfirmedQty = nonConfirmedQty + convertedNonConfirmedBinQty;
                    }
                    dataReaderNonConfirmed.Close();

                    #endregion

                    DataTable availableBinTable = new DataTable();
                    decimal qtyAvailable = 0;
                    decimal availableConsignmentQty = 0;

                    availableBinTable = sapBapiClass.GetBinQuantity(preweighInfo.MaterialNumber, plantCode, preweighInfo.Bin, preweighInfo.BatchNumber, wareHouseNumber);
                    if (availableBinTable.Rows.Count > 0)
                    {
                        /* Check for own stock*/
                        DataRow[] ownStockAvail = availableBinTable.Select(" BESTQ='' AND LGORT='" + storageLocation + "' AND CHARG='" + preweighInfo.BatchNumber.Trim().ToUpper() + "' AND LGTYP='" + preweighInfo.StorageType
                                                                                 + "' AND LGPLA='" + preweighInfo.Bin.Trim().ToUpper() + "' AND SOBKZ='' ");
                        foreach (DataRow dr in ownStockAvail)
                        {
                            qtyAvailable = qtyAvailable + GetQtyAvailable(sapBapiClass, dr, preweighInfo.MaterialNumber, preweighInfo.Uom);
                            break;
                        }

                        if (qtyAvailable > nonConfirmedBinQty)
                        {
                            /* if available qty greater than  nonconfirmed qty then get exact available qty */
                            qtyAvailable = qtyAvailable - nonConfirmedBinQty;
                        }
                        else
                            qtyAvailable = 0;

                        if (qtyAvailable >= preweighInfo.PreweighedQty)
                        {
                            /* If qty available in own stock then should not do any movement*/
                            return true;
                        }
                        else
                        {
                            /* If qty is not available in own stock then check for consignment stock */

                            DataRow[] consignmentStockAvail = availableBinTable.Select(" BESTQ='' AND LGORT='" + storageLocation + "' AND CHARG='" + preweighInfo.BatchNumber.ToUpper()
                                                                                            + "' AND LGTYP='" + preweighInfo.StorageType
                                                                                            + "' AND LGPLA='" + preweighInfo.Bin.Trim().ToUpper() + "' AND SOBKZ = 'K' ");

                            if (consignmentStockAvail.Length > 0)
                            {
                                decimal remainQty = preweighInfo.PreweighedQty - qtyAvailable; //get remaning qty from consignment stock
                                availableConsignmentQty = availableConsignmentQty + GetQtyAvailable(sapBapiClass, consignmentStockAvail[0], preweighInfo.MaterialNumber, preweighInfo.Uom);
                                if (availableConsignmentQty >= remainQty)
                                {
                                    iPASRFSAP.OwnStockInfo ownStock = new iPASRFSAP.OwnStockInfo();
                                    ownStock.BatchNumber = consignmentStockAvail[0]["CHARG"].ToString().Trim();
                                    ownStock.MaterialNumber = consignmentStockAvail[0]["MATNR"].ToString().Trim();
                                    ownStock.Qty = remainQty;
                                    ownStock.SpecialStockIndicator = "K";
                                    ownStock.StorageLocation = consignmentStockAvail[0]["LGORT"].ToString().Trim();
                                    ownStock.Unit = preweighInfo.Uom;
                                    ownStock.VendorNumber = consignmentStockAvail[0]["SONUM"].ToString().TrimStart('0');
                                    ownStock.StorageType = consignmentStockAvail[0]["LGTYP"].ToString();
                                    moveStockInfo.MoveStockList.Add(ownStock);
                                }
                                else
                                {
                                    // return false;
                                    throw new FaultException("Picked qty is more than available qty in SAP.");
                                }
                            }

                        }
                    }

                    if (moveStockInfo.MoveStockList.Count > 0)
                    {
                        /* Check 411 movement is completed for material batch and bin, but posting change is pending, then do  posting change for that much qty.
                         * and do 411 movement for remaining qty.  */
                        DataTable stockInfoTable = PreweighDAL.GetStockMoveInfo(db, preweighInfo.SiteID, preweighInfo.MaterialNumber, preweighInfo.BatchNumber, preweighInfo.Bin);
                        foreach (DataRow itemRow in stockInfoTable.Rows)
                        {
                            decimal movedQty = 0;
                            decimal.TryParse(itemRow["FMOVEQTY"].ToString(), out movedQty);
                            if (movedQty < moveStockInfo.MoveStockList[0].Qty)
                            {
                                moveStockInfo.MoveStockList[0].Qty = moveStockInfo.MoveStockList[0].Qty - movedQty;
                            }
                            else
                                moveStockInfo.MoveStockList[0].Qty = 0;
                        }

                        if (moveStockInfo.MoveStockList[0].Qty > 0)
                        {
                            /* cancel existing TO for line item else 411 movement may throw error because of qty nonavailable */
                            foreach (DataRow dataRow in lineItemInfoTable.Rows)
                            {
                                string transferOrderNum = dataRow["FTANUM"].ToString();
                                string transferOrderLineItem = dataRow["FTAPOS"].ToString();
                                if (transferOrderLineItem.Trim().PadLeft(4, '0') != "0000")
                                {
                                    sapBapiClass.CancelSingleTO(wareHouseNumber, transferOrderNum, transferOrderLineItem, userName);
                                }
                            }
                        }

                        if (moveStockInfo.MoveStockList[0].Qty > 0)
                        {
                            /* Do for 411 movement for remaing qty */
                            string movMaterialDocNum = string.Empty;
                            string movMaterialDocYear = string.Empty;

                            /* first do 411 movement for moving consignment stock to own stock */
                            //sapBapiClass.MoveConsignmentStockToOwnStock(moveStockInfo, ref movMaterialDocNum, ref movMaterialDocYear);

                            DataTable errorTable = new DataTable();

                            /* first do 411 movement for moving consignment stock to own stock */
                            sapBapiClass.MoveConsignmentStockToOwnStock(moveStockInfo, ref movMaterialDocNum, ref movMaterialDocYear, ref errorTable);

                            if (errorTable.Rows.Count > 0)
                            {
                                DataRow[] errorRows = errorTable.Select(" TYPE='E' ");
                                if (errorRows.Length > 0)
                                {
                                    throw new FaultException(errorTable.Rows[0]["MESSAGE"].ToString().Trim());
                                }
                            }


                            DataRow newRow = stockInfoTable.NewRow();
                            newRow["FMATNR"] = preweighInfo.MaterialNumber;
                            newRow["FCHARG"] = preweighInfo.BatchNumber;
                            newRow["FBINLOCATION"] = preweighInfo.Bin;
                            newRow["FLGORT"] = storageLocation;
                            newRow["FSTORAGETYPE"] = preweighInfo.StorageType;
                            newRow["FVENDORNUM"] = moveStockInfo.MoveStockList[0].VendorNumber;
                            newRow["FMOVEQTY"] = moveStockInfo.MoveStockList[0].Qty;
                            newRow["FMOVEMATDOCNUM"] = movMaterialDocNum;
                            newRow["FMOVEMATDOCYEAR"] = movMaterialDocYear;
                            stockInfoTable.Rows.Add(newRow);
                        }

                        foreach (DataRow itemRow in stockInfoTable.Rows)
                        {
                            if (itemRow["FPOSTINGNUM"].ToString().Trim().Length == 0)
                            {
                                /* If posting number doesnot exist get posting number for matrial doc num */
                                DataTable postingTable = sapBapiClass.GetPostChangeNumber(wareHouseNumber, itemRow["FMOVEMATDOCNUM"].ToString());
                                if (postingTable.Rows.Count > 0)
                                {
                                    itemRow["FPOSTINGNUM"] = postingTable.Rows[0]["UBNUM"].ToString();
                                    stockInfoTable.AcceptChanges();
                                    PreweighDAL.InsertMovementInfo(db, preweighInfo.SiteID, preweighInfo.MaterialNumber, preweighInfo.BatchNumber, preweighInfo.Bin, storageLocation
                                                                    , preweighInfo.StorageType, moveStockInfo.MoveStockList[0].VendorNumber, moveStockInfo.MoveStockList[0].Qty
                                                                    , itemRow["FMOVEMATDOCNUM"].ToString(), itemRow["FMOVEMATDOCYEAR"].ToString(), itemRow["FPOSTINGNUM"].ToString());
                                }
                            }

                            decimal remainQty = 0;
                            decimal.TryParse(itemRow["FMOVEQTY"].ToString(), out remainQty);
                            iPASRFSAP.OwnStockInfo ownStock = new iPASRFSAP.OwnStockInfo();
                            ownStock.BatchNumber = itemRow["FCHARG"].ToString().Trim();
                            ownStock.MaterialNumber = itemRow["FMATNR"].ToString().Trim();
                            ownStock.Qty = remainQty;
                            ownStock.SpecialStockIndicator = "K";
                            ownStock.StorageLocation = itemRow["FLGORT"].ToString().Trim();
                            ownStock.Unit = preweighInfo.Uom;
                            ownStock.VendorNumber = itemRow["FVENDORNUM"].ToString().TrimStart('0');
                            ownStock.StorageType = itemRow["FSTORAGETYPE"].ToString();
                            iPASRFSAP.StockBinInfo stockBinInfo = new iPASRFSAP.StockBinInfo();
                            stockBinInfo.BinLocation = itemRow["FBINLOCATION"].ToString().Trim();
                            stockBinInfo.Quantity = remainQty;
                            stockBinInfo.StorageType = itemRow["FSTORAGETYPE"].ToString();
                            ownStock.BinList.Add(stockBinInfo);
                            moveStockInfo.MoveStockList.Add(ownStock);

                            DataTable quantTable = sapBapiClass.GetBinQuantNumber(ownStock, plantCode, wareHouseNumber);
                            if (quantTable.Rows.Count > 0)
                            {
                                /* Do posting for moved item */
                                string transferNum = string.Empty;
                                string message = sapBapiClass.DoPostingChangeForStock(wareHouseNumber, itemRow["FPOSTINGNUM"].ToString(), userName, quantTable.Rows[0]["QUANT"].ToString(), ownStock.BinList, ref transferNum);
                                if (transferNum.TrimStart('0').Length > 0 || message == "TP_COMPLETED")
                                {
                                    PreweighDAL.RemoveStockMovementInfo(db, preweighInfo.SiteID, preweighInfo.MaterialNumber, preweighInfo.BatchNumber, preweighInfo.Bin, itemRow["FPOSTINGNUM"].ToString());
                                    return true;
                                }
                                else if (message.Length > 0)
                                {
                                    throw new FaultException("Exception in stock movement please try again. " + message);
                                }
                            }
                            else
                            {
                                throw new FaultException("Not able to do movement for own stock. Please check qty in sap for selected bin.");
                            }

                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while moving consignment stock to ownstock", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name
                                    , "SiteID: " + preweighInfo.SiteID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderWarehouse != null && !dataReaderWarehouse.IsClosed)
                    dataReaderWarehouse.Close();

                if (dataReaderNonConfirmed != null && !dataReaderNonConfirmed.IsClosed)
                    dataReaderNonConfirmed.Close();
            }
        }

        private decimal GetQtyAvailable(iPASRFSAP.BAPIClass sapBapiClass, DataRow dataRow, string materialNumber, string unit)
        {
            try
            {
                decimal verme = 0;
                decimal convertedQunatity = 0;

                decimal quantity = 0;
                decimal.TryParse(dataRow["VERME"].ToString(), out verme);
                decimal.TryParse(dataRow["GESME"].ToString(), out quantity); //VERME IS REPLACED WITH GESME. AS TO IS ALREADY DONE, VERME WILL BE ZERO, IF GESME IS ASSIGNED to TO
                string binQtyUnit = dataRow["MEINS"].ToString().Trim();

                if (unit.Trim().ToUpper() != binQtyUnit.Trim().ToUpper())
                    convertedQunatity = sapBapiClass.UnitConversion(materialNumber, binQtyUnit, unit, quantity);
                else
                    convertedQunatity = quantity;

                return convertedQunatity;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreWeighService", "Error while coverting unit", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "Material: " + materialNumber);
                return 0;
            }
        }

        private decimal GetMaterialBatchBinNonConfirmedQty(iPASRFSAP.BAPIClass sapBapiClass, Database db, string materialNumber, string batchNumber, string binLocation, string unit)
        {
            DataTable dtNonConfirmedBatchQty = PreweighDAL.GetNonConfirmedMaterialBatchQty(db, materialNumber, batchNumber);
            DataRow[] drConfirmedQty = dtNonConfirmedBatchQty.Select(" FBINLOCATION ='" + binLocation + "'");

            decimal nonConfirmedQty = 0;
            decimal nonConfirmedBinQty = 0;
            decimal convertedNonConfirmedQty = 0;
            string nonConfirmedQtyUOM = string.Empty;

            foreach (DataRow row in drConfirmedQty)
            {
                nonConfirmedBinQty = Convert.ToDecimal(row["FNONCONFIRMEDQTY"].ToString().Trim());
                nonConfirmedQtyUOM = row["FUOM"].ToString().Trim();

                if (unit != nonConfirmedQtyUOM.Trim().ToUpper())
                    convertedNonConfirmedQty = sapBapiClass.UnitConversion(materialNumber, nonConfirmedQtyUOM, unit, nonConfirmedBinQty);
                else
                    convertedNonConfirmedQty = nonConfirmedBinQty;

                nonConfirmedQty = nonConfirmedQty + convertedNonConfirmedQty;
            }

            return nonConfirmedQty;
        }
        #endregion

        #region CustomPOGrouping

        #region Get methods for loading Orders

        public CustomPOGroupList GetStagingProcessOrders(CustomPOGroupFilter filter)
        {
            try
            {
                int displayPOCount = 0;
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                CustomPOGroupList sortedCustomPOGroupList = new CustomPOGroupList();
                List<CustomPOGroupInfoList> customPOGroupList = new List<CustomPOGroupInfoList>();
                CustomPOGroupInfoList customPOGroupInfoList = null;

                int currentDate = 0;
                int currentTime = 0;

                Common.GetCurrentSiteDateTime(db, filter.SiteID, ref currentDate, ref currentTime);

                if (filter.StartDate == 0)
                {
                    filter.StartDate = currentDate;
                }

                if (filter.EndDate == 0)
                {
                    DateTime date;
                    DateTime.TryParseExact(filter.StartDate.ToString(), "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out date);

                    date = date.AddDays(1);
                    filter.EndDate = Convert.ToInt32(date.ToString("yyyyMMdd"));
                }

                if (filter.StagingArea == null || filter.StagingArea.Trim().Length == 0)
                    return sortedCustomPOGroupList;

                DataTable dtStagingProcessOrders = PreweighDAL.GetStagingProcessOrders(db, filter.SiteID, filter.UserID, filter.AccessLevelID, filter.StagingArea
                    , filter.StartDate, filter.EndDate, currentDate, filter.PageIndex, filter.PageSize);

                if (dtStagingProcessOrders.Rows.Count > 0)
                    sortedCustomPOGroupList.TotalCount = Convert.ToInt32(dtStagingProcessOrders.Rows[0]["FCOUNT"].ToString());

                sortedCustomPOGroupList.currentDate = currentDate;
                sortedCustomPOGroupList.Startdate = filter.StartDate;
                sortedCustomPOGroupList.Enddate = filter.EndDate;

                //Show already grouped orders at the top
                DataTable distinctGroupID = dtStagingProcessOrders.DefaultView.ToTable(true, "FCUSTOMPICKGROUPID"); //Getting distinct GroupID's only.
                DataView dataview = new DataView(distinctGroupID);
                dataview.Sort = "FCUSTOMPICKGROUPID DESC";
                distinctGroupID = dataview.ToTable();

                foreach (DataRow drow in distinctGroupID.Rows)
                {
                    /* CR 1323-OM Load Process Orders on Scroll -Start*/
                    /* Below Now we are using filter.PageSize(dynamically) , before it was hardcoded */
                    if (displayPOCount <= filter.PageSize)
                    {
                        int groupID = Convert.ToInt32(drow["FCUSTOMPICKGROUPID"].ToString());

                        DataRow[] datarows = dtStagingProcessOrders.Select("FCUSTOMPICKGROUPID=" + groupID.ToString()); // returns the orders corresponding to groupID

                        if (groupID > 0)
                        {
                            /* For groupID > 0, Only grouped process orders will come here */
                            customPOGroupInfoList = new CustomPOGroupInfoList();
                            List<CustomPOGroupInfo> customPOGroupInfo = new List<CustomPOGroupInfo>();

                            DataTable groupedOrders = PreweighDAL.GetCustomGroupedOrders(db, filter.SiteID, groupID, true);

                            if (groupedOrders.Rows.Count > 0)
                            {
                                customPOGroupInfoList.ProcessOrderStatus = Common.GetProcessOrderStatus(datarows[0]["FHDRSTATUS"].ToString());
                                foreach (DataRow distinctGroupIDRows in groupedOrders.Rows)
                                {
                                    customPOGroupInfo.Add(GetProcessOrderInfoToList(distinctGroupIDRows));
                                    ProcessOrderStatus hdrStatus = Common.GetProcessOrderStatus(distinctGroupIDRows["FHDRSTATUS"].ToString());

                                    if (hdrStatus != ProcessOrderStatus.Not_Started)
                                    {
                                        if (customPOGroupInfoList.ProcessOrderStatus != ProcessOrderStatus.Staging_InProgress && hdrStatus == ProcessOrderStatus.Staging_InProgress)
                                        {
                                            customPOGroupInfoList.ProcessOrderStatus = hdrStatus;
                                        }
                                    }
                                }
                                displayPOCount += groupedOrders.Rows.Count;
                            }

                            customPOGroupInfoList.CustomPOGroupID = groupID;
                            customPOGroupInfoList.POGroupInfoList = customPOGroupInfo;
                            customPOGroupInfoList.PickerInfoList = GetAssignedPickerForGroup(db, filter.SiteID, groupID);

                            customPOGroupList.Add(customPOGroupInfoList);
                        }
                        else
                        {
                            /* All un-grouped process orders will come */
                            foreach (DataRow distinctGroupIDRows in datarows)
                            {
                                if (displayPOCount <= filter.PageSize) /* This condition is to limit the number of PO's with groupID=0 (i.e un-grouped orders)*/
                                {
                                    displayPOCount++;

                                    //Check whether staging is required for the PO. There should be atleast one item for staging
                                    if (PreweighDAL.GetStagingRequiredMaterialsForPO(db, filter.SiteID, distinctGroupIDRows["FAUFNR"].ToString()) == 0)
                                    {
                                        continue;
                                    }

                                    customPOGroupInfoList = new CustomPOGroupInfoList();
                                    customPOGroupInfoList.ProcessOrderStatus = Common.GetProcessOrderStatus(distinctGroupIDRows["FHDRSTATUS"].ToString());
                                    customPOGroupInfoList.POGroupInfoList.Add(GetProcessOrderInfoToList(distinctGroupIDRows));
                                    customPOGroupList.Add(customPOGroupInfoList);

                                }
                                else
                                    break;
                            }
                        }
                    }
                    else
                        break;
                }

                /*Sort by GroupID, to show latest group on top*/
                sortedCustomPOGroupList.POGroupList.AddRange(customPOGroupList.OrderByDescending(O => O.CustomPOGroupID).ToList());

                /* CR 1323-OM Load Process Orders on Scroll -Start*/
                sortedCustomPOGroupList.LastIndex = displayPOCount + filter.PageIndex;
                /* CR 1323-OM Load Process Orders on Scroll -End*/

                return sortedCustomPOGroupList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Error while fetching staging process orders list", "iPAS_PreWeighService",
                      System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + filter.SiteID + " ,UserID:" + filter.UserID);
                throw new FaultException(ex.Message);
            }
        }

        private CustomPOGroupInfo GetProcessOrderInfoToList(DataRow distinctGroupIDRows)
        {
            decimal quantity = 0;
            int rmShortageCount = 0;

            CustomPOGroupInfo customPOGroupInfo = new CustomPOGroupInfo();
            customPOGroupInfo.ProcessOrderNumber = distinctGroupIDRows["FAUFNR"].ToString();
            customPOGroupInfo.BatchNumber = distinctGroupIDRows["FCHARG"].ToString();
            customPOGroupInfo.MaterialNumber = distinctGroupIDRows["FMATNR"].ToString();
            customPOGroupInfo.MaterialDescription = distinctGroupIDRows["FIDHDESC"].ToString();
            customPOGroupInfo.ScheduledDate = Int32.Parse(distinctGroupIDRows["FSTARTDATE"].ToString());
            customPOGroupInfo.ResourceName = distinctGroupIDRows["FCATEGORY"].ToString();
            decimal.TryParse(distinctGroupIDRows["FTOTALQTY"].ToString(), out quantity);
            customPOGroupInfo.Quantity = quantity;

            customPOGroupInfo.UOM = distinctGroupIDRows["FMEINSPO"].ToString();

            if (distinctGroupIDRows["FISWORKRESOURCE"].ToString() == "Y")
                customPOGroupInfo.POType = ProcessOrderType.Repack;
            else
            {
                string orderType = distinctGroupIDRows["FPOORDERTYPE"].ToString();
                customPOGroupInfo.POType = Common.GetProcessOrderOrderType(orderType, customPOGroupInfo.ResourceName);
            }

            int.TryParse(distinctGroupIDRows["FHASRMSHORTAGE"].ToString(), out rmShortageCount);
            if (rmShortageCount > 0)
            {
                customPOGroupInfo.HasRMShortage = true;
            }
            return customPOGroupInfo;
        }

        private List<CustomPOGroupPickerInfo> GetAssignedPickerForGroup(Database db, int siteID, int groupID)
        {
            /* This method is to get the list of pickers to corresponding group*/
            IDataReader datareaderPickerInfo = null;
            try
            {
                List<CustomPOGroupPickerInfo> customGroupList = new List<CustomPOGroupPickerInfo>();
                CustomPOGroupPickerInfo poGroupPickerInfo = null;

                datareaderPickerInfo = PreweighDAL.GetAssignedPickerForGroup(db, siteID, groupID);
                while (datareaderPickerInfo.Read())
                {
                    poGroupPickerInfo = new CustomPOGroupPickerInfo();
                    poGroupPickerInfo.PickerID = Common.GetSafeInt32(datareaderPickerInfo, "FUSERID");
                    poGroupPickerInfo.PickerName = Common.GetSafeString(datareaderPickerInfo, "FUSERNAME");
                    customGroupList.Add(poGroupPickerInfo);
                }
                datareaderPickerInfo.Close();

                return customGroupList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Error while fetching picker list for process order group", "iPAS_PreWeighService",
                       System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + siteID + " ,POGroupID:" + groupID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (datareaderPickerInfo != null && !datareaderPickerInfo.IsClosed)
                    datareaderPickerInfo.Close();
            }
        }

        #endregion

        #region Group and Assign methods

        public List<CustomPOGroupPickerInfo> GetPickerInfo(BasicParam basicParam, PickerInfoFilter filter)
        {
            /*Getting Pickers list, who have acces to all the grouping orders productionline */
            IDataReader datareaderPickerInfo = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                List<CustomPOGroupPickerInfo> pickerInfoList = new List<CustomPOGroupPickerInfo>();
                CustomPOGroupPickerInfo pickerInfo = null;

                string resources = "'" + string.Join("','", filter.ResourceList.ToArray().Distinct()) + "'";
                int resourceCount = filter.ResourceList.ToArray().Distinct().Count();

                datareaderPickerInfo = PreweighDAL.GetPickerInfo(db, basicParam.SiteID, resources, resourceCount);
                while (datareaderPickerInfo.Read())
                {
                    pickerInfo = new CustomPOGroupPickerInfo();
                    pickerInfo.PickerID = Common.GetSafeInt32(datareaderPickerInfo, "FUSERID");
                    pickerInfo.PickerName = Common.GetSafeString(datareaderPickerInfo, "FUSERNAME");
                    pickerInfoList.Add(pickerInfo);
                }
                datareaderPickerInfo.Close();
                return pickerInfoList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Error while fetching picker info", "iPAS_PreWeighService",
                      System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicParam.SiteID + " ,UserID:" + basicParam.UserID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (datareaderPickerInfo != null && !datareaderPickerInfo.IsClosed)
                    datareaderPickerInfo.Close();
            }

        }

        public PickerAssignedInfo GroupAndAssignPOtoPickers(GroupAndAssignCustomPO groupAndAssignCustomPO)
        {
            try
            {
                int maxPOtoGroup = 0;
                int maxPOtoAssignForPicker = 0;
                int poAssignedToPicker = 0;
                int nextPOGroupID = 0;

                PickerAssignedInfo pickerAssignedInfo = new PickerAssignedInfo();
                CustomPOGroupPickerInfo pickerPOInfo = null;

                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                maxPOtoAssignForPicker = PreweighDAL.GetSiteMaximumOrdersToGroup(db, groupAndAssignCustomPO.SiteID); //Maximum site orders allowed to assign for single picker

                /* Below foreach loop is to check, whether any picker is exceeding maximum orders allowed */
                foreach (CustomPOGroupPickerInfo PickerInfo in groupAndAssignCustomPO.PickerInfoList)
                {
                    DataTable dtpickerAssignedOrders = PreweighDAL.GetActiveAssignedOrderForPicker(db, PickerInfo.PickerID); //Picker assigned order list

                    List<string> assignedpoList = dtpickerAssignedOrders.Rows.OfType<DataRow>().Select(dr => dr.Field<string>(0)).ToList();
                    /* Below List: Concate assinged order list(assignedpoList) and newly assigned order list(groupAndAssignCustomPO) to get distinct order list(distinctPOList) */
                    List<string> distinctPOList = assignedpoList.Concat(groupAndAssignCustomPO.POList).Distinct().ToList();

                    if (distinctPOList.Count > maxPOtoAssignForPicker)
                    {
                        pickerPOInfo = new CustomPOGroupPickerInfo();
                        pickerPOInfo.PickerName = PickerInfo.PickerName;
                        pickerPOInfo.PickerPOCount = poAssignedToPicker;
                        pickerAssignedInfo.PickerInfoList.Add(pickerPOInfo);
                    }
                }

                if (pickerAssignedInfo.PickerInfoList.Count > 0)
                {
                    pickerAssignedInfo.MaxPOAllowedToPicker = maxPOtoAssignForPicker;
                    return pickerAssignedInfo; /*Returns the list for pickers, Exceeding maximum orders allowed to assign */
                }

                DbTransaction transaction = null;
                using (DbConnection connection = db.CreateConnection())
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();
                    try
                    {
                        /*  groupAndAssignCustomPO.CustomPickGroupID > 0 is Re-Assign function */
                        if (groupAndAssignCustomPO.CustomPickGroupID > 0)
                        {
                            foreach (string processOrder in groupAndAssignCustomPO.POList)
                            {
                                PreweighDAL.DeletePickerOrders(db, transaction, processOrder);
                                PreweighDAL.AssignOrdertoGroup(db, transaction, processOrder, groupAndAssignCustomPO.CustomPickGroupID);

                                foreach (CustomPOGroupPickerInfo Picker in groupAndAssignCustomPO.PickerInfoList)
                                {
                                    PreweighDAL.AssignOrdertoPicker(db, transaction, processOrder, Picker.PickerID, groupAndAssignCustomPO.UserID);
                                }
                            }
                        }
                        else
                        {
                            maxPOtoGroup = PreweighDAL.GetPlineMaximunOrdersToGroup(db, groupAndAssignCustomPO.SiteID, groupAndAssignCustomPO.StagingArea); //  Maximum order allowed to group for Pline

                            /*In below step, We are checking currently assgined orders with pline max order count*/
                            if (groupAndAssignCustomPO.POList.Count > maxPOtoGroup)
                            {
                                pickerAssignedInfo.MaxPOCountExceeds = true;

                                transaction.Rollback();
                                return pickerAssignedInfo;
                            }

                            nextPOGroupID = PreweighDAL.GetNextGroupID(db);
                            foreach (string processOrder in groupAndAssignCustomPO.POList)
                            {
                                PreweighDAL.DeletePickerOrders(db, transaction, processOrder);
                                PreweighDAL.AssignOrdertoGroup(db, transaction, processOrder, nextPOGroupID);

                                if (groupAndAssignCustomPO.PickerInfoList.Count > 0)
                                {
                                    foreach (CustomPOGroupPickerInfo Picker in groupAndAssignCustomPO.PickerInfoList)
                                    {
                                        PreweighDAL.AssignOrdertoPicker(db, transaction, processOrder, Picker.PickerID, groupAndAssignCustomPO.UserID);
                                    }
                                }
                            }
                        }
                        transaction.Commit();

                        pickerAssignedInfo.ReturnStatus = true;
                        return pickerAssignedInfo;
                    }
                    catch
                    {
                        if (transaction != null)
                            transaction.Rollback();

                        throw;
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Error while grouping and assigning process orders", "iPAS_PreWeighService",
                      System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + groupAndAssignCustomPO.SiteID + " ,UserID:" + groupAndAssignCustomPO.UserID);

                throw new FaultException(ex.Message);
            }

        }

        #endregion

        #region Delete single order from Group

        public bool RemovePOFromGroup(BasicParam basicParam, PickerInfoFilter filter)
        {
            IDataReader dataReaderStatus = null;
            string hdrStatus = string.Empty;

            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");
                DbTransaction transaction;

                dataReaderStatus = PreweighDAL.GetProcessOrderHeaderStatus(db, null, filter.ProcessOrder);
                if (dataReaderStatus.Read())
                {
                    hdrStatus = Common.GetSafeString(dataReaderStatus, "FHDRSTATUS");
                }
                dataReaderStatus.Close();

                if (hdrStatus == "N")
                {
                    using (DbConnection connection = db.CreateConnection())
                    {
                        connection.Open();
                        transaction = connection.BeginTransaction();
                        try
                        {
                            PreweighDAL.DeleteOrderFromGroup(db, transaction, filter.ProcessOrder);
                            PreweighDAL.DeletePickerOrders(db, transaction, filter.ProcessOrder);

                            transaction.Commit();
                        }
                        catch
                        {
                            transaction.Rollback();
                            return false;
                        }
                        finally
                        {
                            connection.Close();
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Error while removing process order from group", "iPAS_PreWeighService",
                        System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicParam.SiteID + " ,UserID:" + basicParam.UserID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (dataReaderStatus != null && !dataReaderStatus.IsClosed)
                    dataReaderStatus.Close();
            }
        }

        #endregion

        public List<StagingAreasInfo> GetStagingAreaList(BasicParam basicParam)
        {
            IDataReader datareaderStagingArea = null;
            List<StagingAreasInfo> stagingAreaList = new List<StagingAreasInfo>();
            StagingAreasInfo stagingArea = null;
            try
            {
                Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

                datareaderStagingArea = PreweighDAL.GetStagingAreas(db, basicParam.SiteID, basicParam.UserID, basicParam.AccessLevelID);
                while (datareaderStagingArea.Read())
                {
                    stagingArea = new StagingAreasInfo();
                    stagingArea.StagingAreas = Common.GetSafeString(datareaderStagingArea, "FSTAGINGAREA");
                    stagingAreaList.Add(stagingArea);
                }
                datareaderStagingArea.Close();

                return stagingAreaList;
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "PreweighService", "Error while fetching staging areas", "iPAS_PreWeighService",
                         System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + basicParam.SiteID + " ,UserID:" + basicParam.UserID);
                throw new FaultException(ex.Message);
            }
            finally
            {
                if (datareaderStagingArea != null && !datareaderStagingArea.IsClosed)
                    datareaderStagingArea.Close();
            }
        }

        #endregion

        #region Missing PartList

        public void SyncRMShortageProcessOrders()
        {
            SyncMissingPartsInfo syncDelegate = new SyncMissingPartsInfo(SyncRMShortageProcessOrdersForSite);
            AsyncCallback cb = new AsyncCallback(Send);
            IAsyncResult ar = syncDelegate.BeginInvoke(cb, null);
        }

        private void SyncRMShortageProcessOrdersForSite()
        {
            Database db = DatabaseFactory.CreateDatabase("ApplicationConnection");

            string activeSiteIDs = Common.GetActiveSitesBasedOnModules(db, false, true, false, false, true);
            string[] siteIDCollection = activeSiteIDs.Split(',');


            iPASRFSAP.BAPIClass sapBapiClass = Common.CreateSAPConnection(string.Empty);

            for (int i = 0; i < siteIDCollection.Length; i++)
            {
                int siteID = Convert.ToInt32(siteIDCollection[i].Trim());
                UpdateMissingPartListForSite(siteID, db, sapBapiClass);
            }
        }

        private void UpdateMissingPartListForSite(int siteID, Database db, iPASRFSAP.BAPIClass sapBapiClass)
        {
            IDataReader dataReaderPlantCode = null;
            try
            {
                int createdOn = 0;
                int createdTime = 0;
                List<string> plantCodeList = new List<string>();

                Common.GetCurrentSiteDateTime(db, siteID, ref createdOn, ref createdTime);

                dataReaderPlantCode = CommonDAL.GetWareHouseNumberAndPlantCodeForSite(db, siteID);
                while (dataReaderPlantCode.Read())
                {
                    string useFORBOM = Common.GetSafeString(dataReaderPlantCode, "FUSEFORBOM");
                    if (useFORBOM == "Y")
                    {
                        string plantCode = Common.GetSafeString(dataReaderPlantCode, "FSAPPLANTCODE");
                        plantCodeList.Add(plantCode);
                    }
                }
                dataReaderPlantCode.Close();

                foreach (string plantCode in plantCodeList)
                {

                    DataTable dtMissedMaterialList = sapBapiClass.GetMissingPartList(plantCode);
                    if (dtMissedMaterialList.Rows.Count > 0)
                    {
                        DbTransaction transaction;
                        using (DbConnection connection = db.CreateConnection())
                        {
                            connection.Open();
                            transaction = connection.BeginTransaction();
                            try
                            {
                                PreweighDAL.RemoveAllInfoInMissingPartList(db, transaction, siteID, plantCode);

                                foreach (DataRow row in dtMissedMaterialList.Rows)
                                {
                                    PreweighDAL.InsertMissingPartListInfo(db, transaction, siteID, row["WERKS"].ToString().Trim(), row["MATNR"].ToString().Trim(), Convert.ToInt32(row["RSNUM"].ToString().Trim()),
                                    Convert.ToInt32(row["RSPOS"].ToString().Trim()), row["RSART"].ToString().Trim(), Convert.ToInt32(row["BDTER"].ToString().Trim()),
                                    row["AUFNR"].ToString().Trim(), createdOn);
                                }

                                transaction.Commit();
                            }
                            catch (Exception ex)
                            {
                                transaction.Rollback();

                                Common.LogException(ex, "StagingService", "Error while inserting missing part list info ", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name
                                                     , "SiteID: " + siteID);

                            }
                            finally
                            {
                                connection.Close();
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Common.LogException(ex, "StagingService", "Error while fetching missing part list", "iPAS_PreWeighService", System.Reflection.MethodBase.GetCurrentMethod().Name, "SiteID: " + siteID);
            }
            finally
            {
                if (dataReaderPlantCode != null && !dataReaderPlantCode.IsClosed)
                    dataReaderPlantCode.Close();
            }
        }

        #endregion
    }
}
